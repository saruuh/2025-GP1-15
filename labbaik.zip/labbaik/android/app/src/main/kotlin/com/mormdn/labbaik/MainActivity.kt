package com.mormdn.labbaik

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
