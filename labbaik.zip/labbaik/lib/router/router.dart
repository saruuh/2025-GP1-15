import 'package:flutter/cupertino.dart';
import 'package:go_router/go_router.dart';
import 'package:labbaik/features/ritual_guidance/presentation/hijj/hajj_step_details_screen.dart';
import 'package:labbaik/features/ritual_guidance/presentation/hijj/hijj_journey.dart';
import 'package:labbaik/router/navigation_observer.dart' show GoRouterObserver;

import '../core/widgets/page_not_found_view.dart' show PageNotFoundView;
import '../core/widgets/splash_screen.dart' show SplashScreen;
import '../features/auth/presentation/screens/auth_screen.dart' show AuthScreen;
import '../features/auth/presentation/screens/forgot_password_screen.dart'
    show ForgotPasswordScreen;
import '../features/auth/presentation/screens/reset_password_screen.dart'
    show ResetPasswordScreen;
import '../features/auth/presentation/screens/verify_email.dart'
    show VerifyEmailScreen;
import '../features/auth/presentation/screens/password_change_success_screen.dart'
    show PasswordChangeSuccessScreen;
import '../features/auth/presentation/screens/profile_screen.dart'
    show ProfileScreen;
import '../features/auth/presentation/screens/settings_screen.dart'
    show SettingsScreen;
import '../features/auth/presentation/screens/change_password_screen.dart'
    show ChangePasswordScreen;
import '../features/ritual_guidance/presentation/hijj/hijj_guidance_screen.dart'
    show HijjGuidanceScreen;
import '../features/home/presentation/screens/home.dart' show MainAppScreen;
import '../features/ritual_guidance/presentation/umrah/umrah_guidance_screen.dart'
    show UmrahGuidanceScreen;
import '../features/ritual_guidance/presentation/umrah/umrah_step_details_screen.dart'
    show UmrahStepDetailsScreen;
import '../features/ritual_guidance/presentation/widgets/umrah_sub_step.dart';

class KRouter {
  static final GlobalKey<NavigatorState> navigatorKey =
      GlobalKey<NavigatorState>();
  static NavigatorState get systemOwnerRouterNavigatorState =>
      systemOwnerRouter.configuration.navigatorKey.currentState!;

  ///Navigate back to specific route
  void popUntilPath(BuildContext context, String routePath) {
    while (systemOwnerRouter
            .routerDelegate
            .currentConfiguration
            .matches
            .last
            .matchedLocation !=
        routePath) {
      if (!context.canPop()) {
        return;
      }
      context.pop();
    }
  }

  static final GoRouter systemOwnerRouter = GoRouter(
    navigatorKey: navigatorKey,
    debugLogDiagnostics: true,
    observers: <NavigatorObserver>[GoRouterObserver()],
    initialLocation: SplashScreen.path,
    routes: <RouteBase>[
      GoRoute(
        path: HijjGuidanceScreen.path,
        name: HijjGuidanceScreen.routeName,
        pageBuilder: HijjGuidanceScreen.page,
      ),
      GoRoute(
        path: SplashScreen.path,
        name: SplashScreen.routeName,
        pageBuilder: SplashScreen.page,
      ),
      GoRoute(
        path: AuthScreen.path,
        name: AuthScreen.routeName,
        pageBuilder: AuthScreen.page,
      ),
      GoRoute(
        path: ForgotPasswordScreen.path,
        name: ForgotPasswordScreen.routeName,
        pageBuilder: ForgotPasswordScreen.page,
      ),
      GoRoute(
        path: VerifyEmailScreen.path,
        name: VerifyEmailScreen.routeName,
        pageBuilder: VerifyEmailScreen.page,
      ),
      GoRoute(
        path: ResetPasswordScreen.path,
        name: ResetPasswordScreen.routeName,
        pageBuilder: ResetPasswordScreen.page,
      ),
      GoRoute(
        path: PasswordChangeSuccessScreen.path,
        name: PasswordChangeSuccessScreen.routeName,
        pageBuilder: PasswordChangeSuccessScreen.page,
      ),
      GoRoute(
        path: ProfileScreen.path,
        name: ProfileScreen.routeName,
        pageBuilder: ProfileScreen.page,
      ),
      GoRoute(
        path: SettingsScreen.path,
        name: SettingsScreen.routeName,
        pageBuilder: SettingsScreen.page,
      ),
      GoRoute(
        path: UmrahGuidanceScreen.path,
        name: UmrahGuidanceScreen.routeName,
        pageBuilder: UmrahGuidanceScreen.page,
      ),
      GoRoute(
        path: UmrahStepDetailsScreen.path,
        name: UmrahStepDetailsScreen.routeName,
        pageBuilder: UmrahStepDetailsScreen.page,
      ),
      GoRoute(
        path: MainAppScreen.path,
        name: MainAppScreen.routeName,
        pageBuilder: MainAppScreen.page,
      ),
      GoRoute(
        path: UmrahSubStep.path,
        name: UmrahSubStep.routeName,
        pageBuilder: UmrahSubStep.page,
      ),
      GoRoute(
        path: YourHijjJourneyScreen.path,
        name: YourHijjJourneyScreen.routeName,
        pageBuilder: YourHijjJourneyScreen.page,
      ),
      GoRoute(
        path: HajjStepDetailsScreen.path,
        name: HajjStepDetailsScreen.routeName,
        pageBuilder: HajjStepDetailsScreen.page,
      ),
      GoRoute(
        path: ChangePasswordScreen.path,
        name: ChangePasswordScreen.routeName,
        pageBuilder: ChangePasswordScreen.page,
      ),
    ],
    errorBuilder: PageNotFoundView.widgetBuilder,
    redirect: (context, state) {
      return null;
    },
  );
}
