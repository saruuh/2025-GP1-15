import 'package:dio/dio.dart';

class PrayerTimesService {
  final Dio _dio;
  static const String _baseUrl = 'https://api.aladhan.com/v1';

  PrayerTimesService({required Dio dio}) : _dio = dio;

  /// Fetch prayer times for a specific date and location
  /// [latitude] and [longitude] are required
  /// [date] is optional (YYYY-MM-DD format, defaults to today)
  /// [method] is the calculation method (1-16, default is 4 for Umm al-Qura University, Makkah)
  Future<Map<String, dynamic>> getPrayerTimes({
    required double latitude,
    required double longitude,
    String? date,
    int method = 4, // Umm al-Qura University, Makkah
    int madhab = 1, // 1 = Shafi, 2 = Hanafi
  }) async {
    try {
      final queryParams = <String, dynamic>{
        'latitude': latitude,
        'longitude': longitude,
        'method': method,
        'madhab': madhab,
      };

      if (date != null && date.isNotEmpty) {
        queryParams['date'] = date;
      }

      final response = await _dio.get(
        '$_baseUrl/timings',
        queryParameters: queryParams,
      );

      return response.data;
    } catch (e) {
      throw Exception('Failed to fetch prayer times: $e');
    }
  }

  /// Fetch prayer times by city name
  /// [city] is the name of the city
  /// [country] is the name of the country
  /// [date] is optional
  Future<Map<String, dynamic>> getPrayerTimesByCity({
    required String city,
    String? country,
    String? date,
    int method = 4,
    int madhab = 1,
  }) async {
    try {
      final queryParams = <String, dynamic>{
        'city': city,
        'method': method,
        'madhab': madhab,
      };

      if (country != null && country.isNotEmpty) {
        queryParams['country'] = country;
      }

      if (date != null && date.isNotEmpty) {
        queryParams['date'] = date;
      }

      final response = await _dio.get(
        '$_baseUrl/timingsByCity',
        queryParameters: queryParams,
      );

      return response.data;
    } catch (e) {
      throw Exception('Failed to fetch prayer times: $e');
    }
  }

  /// Get Qibla direction for a location
  Future<Map<String, dynamic>> getQiblaDirection({
    required double latitude,
    required double longitude,
  }) async {
    try {
      final response = await _dio.get('$_baseUrl/qibla/$latitude/$longitude');

      return response.data;
    } catch (e) {
      throw Exception('Failed to fetch Qibla direction: $e');
    }
  }
}
