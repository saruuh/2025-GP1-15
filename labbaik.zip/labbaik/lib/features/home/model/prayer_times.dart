class PrayerTimes {
  final PrayerTimings data;
  final int code;

  PrayerTimes({required this.data, required this.code});

  factory PrayerTimes.fromJson(Map<String, dynamic> json) {
    return PrayerTimes(
      data: PrayerTimings.fromJson(json['data']),
      code: json['code'] ?? 200,
    );
  }
}

class PrayerTimings {
  final Timing timings;
  final Date date;
  final Meta meta;

  PrayerTimings({
    required this.timings,
    required this.date,
    required this.meta,
  });

  factory PrayerTimings.fromJson(Map<String, dynamic> json) {
    return PrayerTimings(
      timings: Timing.fromJson(json['timings']),
      date: Date.fromJson(json['date']),
      meta: Meta.fromJson(json['meta']),
    );
  }
}

class Timing {
  final String fajr;
  final String sunrise;
  final String dhuhr;
  final String asr;
  final String maghrib;
  final String isha;
  final String? imsak;
  final String? midnight;
  final String? sunset;

  Timing({
    required this.fajr,
    required this.sunrise,
    required this.dhuhr,
    required this.asr,
    required this.maghrib,
    required this.isha,
    this.imsak,
    this.midnight,
    this.sunset,
  });

  factory Timing.fromJson(Map<String, dynamic> json) {
    return Timing(
      fajr: _extractTime(json['Fajr']),
      sunrise: _extractTime(json['Sunrise']),
      dhuhr: _extractTime(json['Dhuhr']),
      asr: _extractTime(json['Asr']),
      maghrib: _extractTime(json['Maghrib']),
      isha: _extractTime(json['Isha']),
      imsak: _extractTime(json['Imsak']),
      midnight: _extractTime(json['Midnight']),
      sunset: _extractTime(json['Sunset']),
    );
  }

  static String _extractTime(dynamic timeValue) {
    if (timeValue == null) return '';
    if (timeValue is Map) {
      // If it's a Map, try to find a 'time' or 'value' key
      if (timeValue['time'] != null) {
        return _cleanTimeString(timeValue['time'].toString());
      }
      if (timeValue['value'] != null) {
        return _cleanTimeString(timeValue['value'].toString());
      }
      return '';
    }
    return _cleanTimeString(timeValue.toString());
  }

  static String _cleanTimeString(String timeStr) {
    // Remove timezone info if present (e.g., "04:32 (WEST)" -> "04:32")
    if (timeStr.contains('(')) {
      return timeStr.split('(')[0].trim();
    }
    return timeStr.trim();
  }

  List<PrayerInfo> get prayers => [
    PrayerInfo(name: 'Fajr', time: fajr, arabicName: 'فجر'),
    PrayerInfo(name: 'Sunrise', time: sunrise, arabicName: 'شروق'),
    PrayerInfo(name: 'Dhuhr', time: dhuhr, arabicName: 'ظهر'),
    PrayerInfo(name: 'Asr', time: asr, arabicName: 'عصر'),
    PrayerInfo(name: 'Maghrib', time: maghrib, arabicName: 'مغرب'),
    PrayerInfo(name: 'Isha', time: isha, arabicName: 'عشاء'),
  ];

  String getPrayerTime(String prayerName) {
    switch (prayerName.toLowerCase()) {
      case 'fajr':
        return fajr;
      case 'sunrise':
        return sunrise;
      case 'dhuhr':
        return dhuhr;
      case 'asr':
        return asr;
      case 'maghrib':
        return maghrib;
      case 'isha':
        return isha;
      default:
        return '';
    }
  }
}

class PrayerInfo {
  final String name;
  final String time;
  final String arabicName;

  PrayerInfo({
    required this.name,
    required this.time,
    required this.arabicName,
  });
}

class Date {
  final String readable;
  final String timestamp;
  final HijriDate hijri;
  final GregorianDate gregorian;

  Date({
    required this.readable,
    required this.timestamp,
    required this.hijri,
    required this.gregorian,
  });

  factory Date.fromJson(Map<String, dynamic> json) {
    return Date(
      readable: json['readable']?.toString() ?? '',
      timestamp: json['timestamp']?.toString() ?? '',
      hijri: HijriDate.fromJson(json['hijri']),
      gregorian: GregorianDate.fromJson(json['gregorian']),
    );
  }
}

class HijriDate {
  final String date;
  final String format;
  final String day;
  final HijriWeekday weekday;
  final HijriMonth month;
  final String year;
  final HijriDesignation designation;
  final List<String> holidays;

  HijriDate({
    required this.date,
    required this.format,
    required this.day,
    required this.weekday,
    required this.month,
    required this.year,
    required this.designation,
    required this.holidays,
  });

  factory HijriDate.fromJson(Map<String, dynamic> json) {
    return HijriDate(
      date: json['date']?.toString() ?? '',
      format: json['format']?.toString() ?? '',
      day: json['day']?.toString() ?? '',
      weekday: HijriWeekday.fromJson(json['weekday']),
      month: HijriMonth.fromJson(json['month']),
      year: json['year']?.toString() ?? '',
      designation: HijriDesignation.fromJson(json['designation']),
      holidays: _parseHolidays(json['holidays']),
    );
  }

  static List<String> _parseHolidays(dynamic holidays) {
    if (holidays == null) return [];
    if (holidays is List) {
      return holidays.map((e) => e.toString()).toList();
    }
    return [];
  }
}

class HijriWeekday {
  final String en;
  final String ar;

  HijriWeekday({required this.en, required this.ar});

  factory HijriWeekday.fromJson(Map<String, dynamic> json) {
    return HijriWeekday(
      en: json['en']?.toString() ?? '',
      ar: json['ar']?.toString() ?? '',
    );
  }
}

class HijriMonth {
  final int number;
  final String en;
  final String ar;

  HijriMonth({required this.number, required this.en, required this.ar});

  factory HijriMonth.fromJson(Map<String, dynamic> json) {
    return HijriMonth(
      number: json['number'] is int
          ? json['number']
          : json['number'] is String
          ? int.tryParse(json['number']) ?? 0
          : 0,
      en: json['en']?.toString() ?? '',
      ar: json['ar']?.toString() ?? '',
    );
  }
}

class HijriDesignation {
  final String abbreviated;
  final String expanded;
  final String? abbreviatedEn;
  final String? expandedEn;
  final String? abbreviatedAr;
  final String? expandedAr;

  HijriDesignation({
    required this.abbreviated,
    required this.expanded,
    this.abbreviatedEn,
    this.expandedEn,
    this.abbreviatedAr,
    this.expandedAr,
  });

  factory HijriDesignation.fromJson(Map<String, dynamic> json) {
    return HijriDesignation(
      abbreviated: json['abbreviated']?.toString() ?? '',
      expanded: json['expanded']?.toString() ?? '',
      abbreviatedEn: json['abbreviated_en']?.toString(),
      expandedEn: json['expanded_en']?.toString(),
      abbreviatedAr: json['abbreviated_ar']?.toString(),
      expandedAr: json['expanded_ar']?.toString(),
    );
  }
}

class GregorianDate {
  final String date;
  final String format;
  final String day;
  final HijriWeekday weekday;
  final GregorianMonth month;
  final String year;
  final HijriDesignation designation;

  GregorianDate({
    required this.date,
    required this.format,
    required this.day,
    required this.weekday,
    required this.month,
    required this.year,
    required this.designation,
  });

  factory GregorianDate.fromJson(Map<String, dynamic> json) {
    return GregorianDate(
      date: json['date']?.toString() ?? '',
      format: json['format']?.toString() ?? '',
      day: json['day']?.toString() ?? '',
      weekday: HijriWeekday.fromJson(json['weekday']),
      month: GregorianMonth.fromJson(json['month']),
      year: json['year']?.toString() ?? '',
      designation: HijriDesignation.fromJson(json['designation']),
    );
  }
}

class GregorianMonth {
  final int number;
  final String en;

  GregorianMonth({required this.number, required this.en});

  factory GregorianMonth.fromJson(Map<String, dynamic> json) {
    return GregorianMonth(
      number: json['number'] is int
          ? json['number']
          : json['number'] is String
          ? int.tryParse(json['number']) ?? 0
          : 0,
      en: json['en']?.toString() ?? '',
    );
  }
}

class Meta {
  final double latitude;
  final double longitude;
  final String timezone;
  final String method;
  final int latitudeAdjustmentMethod;
  final String midnightMode;
  final String school;
  final Map<String, dynamic>? offset;

  Meta({
    required this.latitude,
    required this.longitude,
    required this.timezone,
    required this.method,
    required this.latitudeAdjustmentMethod,
    required this.midnightMode,
    required this.school,
    this.offset,
  });

  factory Meta.fromJson(Map<String, dynamic> json) {
    return Meta(
      latitude: json['latitude'] is double
          ? json['latitude']
          : json['latitude'] is int
          ? json['latitude'].toDouble()
          : double.tryParse(json['latitude']?.toString() ?? '0') ?? 0.0,
      longitude: json['longitude'] is double
          ? json['longitude']
          : json['longitude'] is int
          ? json['longitude'].toDouble()
          : double.tryParse(json['longitude']?.toString() ?? '0') ?? 0.0,
      timezone: json['timezone']?.toString() ?? '',
      method: json['method']?.toString() ?? '',
      latitudeAdjustmentMethod: json['latitudeAdjustmentMethod'] is int
          ? json['latitudeAdjustmentMethod']
          : int.tryParse(json['latitudeAdjustmentMethod']?.toString() ?? '0') ??
                0,
      midnightMode: json['midnightMode']?.toString() ?? '',
      school: json['school']?.toString() ?? '',
      offset: json['offset'],
    );
  }
}
