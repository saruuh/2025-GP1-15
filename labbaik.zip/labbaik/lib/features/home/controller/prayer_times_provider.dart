import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:geolocator/geolocator.dart';
import '../model/prayer_times.dart';
import '../service/prayer_times_service.dart';

class PrayerTimesProvider extends ChangeNotifier {
  final PrayerTimesService _service;
  PrayerTimes? _prayerTimes;
  bool _isLoading = false;
  String? _error;
  String? _location;

  PrayerTimes? get prayerTimes => _prayerTimes;
  bool get isLoading => _isLoading;
  String? get error => _error;
  String? get location => _location;

  // Default location (Riyadh, Saudi Arabia)
  double _latitude = 24.7136;
  double _longitude = 46.6753;
  int _method = 4; // Umm al-Qura University, Makkah

  PrayerTimesProvider() : _service = PrayerTimesService(dio: Dio()) {
    // Initialize with default location
    loadPrayerTimes();
  }

  /// Load prayer times with automatic location detection
  Future<void> loadPrayerTimesWithLocation() async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      // Request location permission
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        throw Exception('Location services are disabled.');
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          throw Exception('Location permissions are denied');
        }
      }

      if (permission == LocationPermission.deniedForever) {
        throw Exception(
          'Location permissions are permanently denied, we cannot request permissions.',
        );
      }

      // Get current position
      Position position = await Geolocator.getCurrentPosition();
      _latitude = position.latitude;
      _longitude = position.longitude;

      // Load prayer times with detected location
      await loadPrayerTimes();
    } catch (e) {
      _error = e.toString();
      debugPrint('Error loading location and prayer times: $e');

      // Fallback to default location if location detection fails
      if (_error != null) {
        await loadPrayerTimes();
      }
    }
  }

  Future<void> loadPrayerTimes({
    double? latitude,
    double? longitude,
    String? date,
    int method = 4,
  }) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      // Update location if provided
      if (latitude != null) _latitude = latitude;
      if (longitude != null) _longitude = longitude;
      if (method != 4) _method = method;

      final data = await _service.getPrayerTimes(
        latitude: _latitude,
        longitude: _longitude,
        date: date,
        method: _method,
      );

      // Debug: Print the API response structure
      debugPrint('API Response: $data');

      _prayerTimes = PrayerTimes.fromJson(data);
      _error = null;
    } catch (e, stackTrace) {
      _error = e.toString();
      debugPrint('Error loading prayer times: $e');
      debugPrint('Stack trace: $stackTrace');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> loadPrayerTimesByCity({
    required String city,
    String? country,
    String? date,
    int method = 4,
  }) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      final data = await _service.getPrayerTimesByCity(
        city: city,
        country: country,
        date: date,
        method: method,
      );

      _prayerTimes = PrayerTimes.fromJson(data);

      // Update location string
      _location = country != null ? '$city, $country' : city;
      _error = null;
    } catch (e) {
      _error = e.toString();
      debugPrint('Error loading prayer times by city: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  void updateLocation(String location) {
    _location = location;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
