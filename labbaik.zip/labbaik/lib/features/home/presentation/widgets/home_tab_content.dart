import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:provider/provider.dart';

import '../../../../generated/l10n.dart';
import '../../controller/prayer_times_provider.dart';
import 'date_location_card.dart';
import 'home_shimmer_loading.dart';
import 'prayer_schedule_card.dart';
import 'prayer_times_card.dart';

/// Reusable widget for the Home tab content displaying prayer times
class HomeTabContent extends StatelessWidget {
  const HomeTabContent({super.key});

  @override
  Widget build(BuildContext context) {
    return Consumer<PrayerTimesProvider>(
      builder: (context, provider, child) {
        if (provider.isLoading && provider.prayerTimes == null) {
          return const HomeShimmerLoading();
        }

        if (provider.error != null) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.error_outline,
                  color: Colors.white,
                  size: 50.spMin,
                ),
                16.verticalSpace,
                Text(
                  provider.error!,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16.spMin,
                  ),
                  textAlign: TextAlign.center,
                ),
                16.verticalSpace,
                ElevatedButton(
                  onPressed: () => provider.loadPrayerTimes(),
                  child: Text(S.of(context).retry),
                ),
              ],
            ),
          );
        }

        final prayerTimes = provider.prayerTimes;
        if (prayerTimes == null) {
          return const SizedBox();
        }

        return SingleChildScrollView(
          child: Column(
            children: [
              // Current prayer and remaining time
              PrayerTimesCard(
                timings: prayerTimes.data.timings,
                date: prayerTimes.data.date,
              ),
              20.verticalSpace,
              // Prayer schedule
              PrayerScheduleCard(
                prayers: prayerTimes.data.timings.prayers,
              ),
              20.verticalSpace,
              // Date and location
              DateLocationCard(
                hijriDate: prayerTimes.data.date.hijri,
                location: provider.location ?? 'Riyadh, Saudi Arabia',
              ),
            ],
          ),
        );
      },
    );
  }
}

