import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:labbaik/core/utilities/extensions.dart';
import 'package:labbaik/generated/l10n.dart';

import '../../../../core/utilities/color_util.dart';
import '../../../../core/utilities/path_util.dart';

class CustomBottomNavBar extends StatelessWidget {
  final int currentIndex;
  final Function(int) onTap;

  const CustomBottomNavBar({
    super.key,
    required this.currentIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: context.isDarkTheme ? ColorUtil.black : ColorUtil.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20.r),
          topRight: Radius.circular(20.r),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 10,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 8, vertical: 8).r,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildNavItem(
                context: context,
                title: S.of(context).main,
                scale: 1.1,
                iconPath: PathUtil.home,
                isSelected: currentIndex == 0,
                onTap: () => onTap(0),
              ),
              _buildNavItem(
                context: context,
                title: S.of(context).ritualGuidance,
                scale: 1.1,
                iconPath: PathUtil.booklet,
                isSelected: currentIndex == 1,
                onTap: () => onTap(1),
              ),
              // FAB in the center
              Transform.translate(
                offset: Offset(0, -40.spMin),
                child: _buildFab(),
              ),
              _buildNavItem(
                context: context,
                title: S.of(context).map,
                scale: 1.1,
                iconPath: PathUtil.map,
                isSelected: currentIndex == 3,
                onTap: () => onTap(3),
              ),
              _buildNavItem(
                context: context,
                title: S.of(context).fatwaChatbot,
                scale: 1.1,
                iconPath: PathUtil.chatBot,
                isSelected: currentIndex == 4,
                onTap: () => onTap(4),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFab() {
    return InkWell(
      onTap: () => onTap(2),
      borderRadius: BorderRadius.circular(27.5).r,

      splashColor: ColorUtil.primaryColor.withValues(alpha: 0.2),
      highlightColor: ColorUtil.primaryColor.withValues(alpha: 0.2),
      child: Container(
        width: 70.spMin,
        height: 70.spMin,
        decoration: BoxDecoration(
          color: ColorUtil.primaryColor,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: ColorUtil.primaryColor.withValues(alpha: 0.4),
              blurRadius: 12,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: ClipOval(
          child: Center(
            child: Transform.scale(
              scale: 1.8,
              child: SvgPicture.asset(
                PathUtil.lapscounter,
                fit: BoxFit.cover,
                colorFilter: ColorFilter.mode(ColorUtil.white, BlendMode.srcIn),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem({
    required BuildContext context,
    required String title,
    String? iconPath,
    IconData? icon,
    required bool isSelected,
    required VoidCallback onTap,
    double iconSize = 24,
    double scale = 1.5,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: 40.spMin,
            height: 40.spMin,
            child: Center(
              child: iconPath != null
                  ? ClipOval(
                      child: Center(
                        child: Transform.scale(
                          scale: scale,
                          child: SvgPicture.asset(
                            iconPath,
                            fit: BoxFit.fill,
                            colorFilter: ColorFilter.mode(
                              isSelected
                                  ? ColorUtil.primaryColor
                                  : ColorUtil.grey.withValues(alpha: 0.6),
                              BlendMode.srcIn,
                            ),
                          ),
                        ),
                      ),
                    )
                  : Icon(
                      icon,
                      size: iconSize,
                      color: isSelected
                          ? ColorUtil.primaryColor
                          : ColorUtil.grey.withValues(alpha: 0.6),
                    ),
            ),
          ),
          Text(
            title,
            style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: isSelected
                  ? ColorUtil.primaryColor
                  : ColorUtil.grey.withValues(alpha: 0.6),
            ),
          ),
        ],
      ),
    );
  }
}
