import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import '../../../../core/utilities/color_util.dart';
import '../../../../generated/l10n.dart';

/// Reusable widget for the Map tab content with Google Places API integration
class MapTabContent extends StatefulWidget {
  const MapTabContent({super.key});

  @override
  State<MapTabContent> createState() => _MapTabContentState();
}

class _MapTabContentState extends State<MapTabContent> {
  GoogleMapController? _mapController;
  bool _isMapReady = false;
  String? _selectedCategory;
  final TextEditingController _searchController = TextEditingController();
  Set<Marker> _markers = {};
  bool _isSearching = false;

  // Makkah region coordinates (wider view)
  static const double _makkahLat = 21.4225;
  static const double _makkahLng = 39.8262;

  static const CameraPosition _initialCameraPosition = CameraPosition(
    target: LatLng(_makkahLat, _makkahLng),
    zoom: 13,
  );

  // TODO: Replace with your Google Places API key
  // You can get it from: https://console.cloud.google.com/
  static const String _googleApiKey = 'AIzaSyBpcVxhnVXK_Dt0UdYA6Y_hRgKOFwUyZtI';

  // Map categories to Google Places API (New) types
  // See: https://developers.google.com/maps/documentation/places/web-service/place-types
  final Map<String, String> _categoryToPlaceType = {
    'mosques': 'mosque',
    'ritualSites': 'tourist_attraction',
    'historicSites': 'historical_landmark',
    'museums': 'museum',
    'hotels': 'lodging',
  };

  @override
  void dispose() {
    _mapController?.dispose();
    _searchController.dispose();
    super.dispose();
  }

  void _onMapCreated(GoogleMapController controller) {
    _mapController = controller;
    setState(() {
      _isMapReady = true;
    });
    // Load initial mosques/places when map is ready
    _searchNearbyPlaces('mosque');
  }

  void _onCategorySelected(String category) {
    setState(() {
      // Toggle category selection - if already selected, deselect it
      if (_selectedCategory == category) {
        _selectedCategory = null;
        _markers.clear();
      } else {
        _selectedCategory = category;
        // Search for places in this category
        final placeType = _categoryToPlaceType[category];
        if (placeType != null) {
          _searchNearbyPlaces(placeType);
        }
      }
    });
  }

  Future<void> _searchNearbyPlaces(String placeType) async {
    setState(() {
      _isSearching = true;
    });

    try {
      // New Places API endpoint
      final url = Uri.parse(
        'https://places.googleapis.com/v1/places:searchNearby',
      );

      // Prepare request body for new API
      final requestBody = {
        'includedTypes': [placeType],
        'maxResultCount': 20,
        'locationRestriction': {
          'circle': {
            'center': {'latitude': _makkahLat, 'longitude': _makkahLng},
            'radius': 10000.0, // 10km radius
          },
        },
      };

      debugPrint('Searching nearby places with new API: $url');
      debugPrint('Request body: ${json.encode(requestBody)}');

      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'X-Goog-Api-Key': _googleApiKey,
          'X-Goog-FieldMask':
              'places.displayName,places.formattedAddress,places.location,places.id',
        },
        body: json.encode(requestBody),
      );

      debugPrint('Response status: ${response.statusCode}');
      debugPrint('Response body: ${response.body}');

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final places = data['places'] as List? ?? [];

        debugPrint('Found ${places.length} results');

        if (places.isEmpty) {
          _showErrorSnackBar(
            'No places found nearby. Try a different category or search term.',
          );
        }

        setState(() {
          _markers = places.map<Marker>((place) {
            final location = place['location'];
            final lat = location['latitude'];
            final lng = location['longitude'];
            final name = place['displayName']?['text'] ?? 'Unknown';
            final placeId = place['id'] ?? '';
            final address = place['formattedAddress'] ?? '';

            return Marker(
              markerId: MarkerId(placeId),
              position: LatLng(lat, lng),
              infoWindow: InfoWindow(title: name, snippet: address),
              onTap: () {
                _onMarkerTapped(placeId, name);
              },
            );
          }).toSet();
        });

        // If we have results, move camera to show them
        if (_markers.isNotEmpty && _mapController != null) {
          final firstMarker = _markers.first;
          _mapController!.animateCamera(
            CameraUpdate.newLatLngZoom(firstMarker.position, 14),
          );
        }
      } else {
        debugPrint('HTTP Error: ${response.statusCode}');
        final errorData = json.decode(response.body);
        final errorMessage = errorData['error']?['message'] ?? 'Unknown error';
        _showErrorSnackBar('API Error: $errorMessage');
      }
    } catch (e) {
      debugPrint('Error searching places: $e');
      _showErrorSnackBar('Error searching places. Please try again.');
    } finally {
      setState(() {
        _isSearching = false;
      });
    }
  }

  Future<void> _searchPlacesByQuery(String query) async {
    if (query.isEmpty) {
      setState(() {
        _markers.clear();
      });
      return;
    }

    setState(() {
      _isSearching = true;
    });

    try {
      // New Places API Text Search endpoint
      final url = Uri.parse(
        'https://places.googleapis.com/v1/places:searchText',
      );

      // Prepare request body
      final requestBody = {
        'textQuery': query,
        'locationBias': {
          'circle': {
            'center': {'latitude': _makkahLat, 'longitude': _makkahLng},
            'radius': 15000.0, // 15km radius
          },
        },
        'maxResultCount': 20,
      };

      debugPrint('Searching by query with new API: $url');
      debugPrint('Request body: ${json.encode(requestBody)}');

      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'X-Goog-Api-Key': _googleApiKey,
          'X-Goog-FieldMask':
              'places.displayName,places.formattedAddress,places.location,places.id',
        },
        body: json.encode(requestBody),
      );

      debugPrint('Response status: ${response.statusCode}');
      debugPrint('Response body: ${response.body}');

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        final places = data['places'] as List? ?? [];

        debugPrint('Found ${places.length} results for query: $query');

        if (places.isEmpty) {
          _showErrorSnackBar(
            'No results found for "$query". Try a different search term.',
          );
        }

        setState(() {
          _markers = places.map<Marker>((place) {
            final location = place['location'];
            final lat = location['latitude'];
            final lng = location['longitude'];
            final name = place['displayName']?['text'] ?? 'Unknown';
            final placeId = place['id'] ?? '';
            final address = place['formattedAddress'] ?? '';

            return Marker(
              markerId: MarkerId(placeId),
              position: LatLng(lat, lng),
              infoWindow: InfoWindow(title: name, snippet: address),
              onTap: () {
                _onMarkerTapped(placeId, name);
              },
            );
          }).toSet();
        });

        // Move camera to first result
        if (_markers.isNotEmpty && _mapController != null) {
          final firstMarker = _markers.first;
          _mapController!.animateCamera(
            CameraUpdate.newLatLngZoom(firstMarker.position, 15),
          );
        }
      } else {
        debugPrint('HTTP Error: ${response.statusCode}');
        final errorData = json.decode(response.body);
        final errorMessage = errorData['error']?['message'] ?? 'Unknown error';
        _showErrorSnackBar('API Error: $errorMessage');
      }
    } catch (e) {
      debugPrint('Error searching query: $e');
      _showErrorSnackBar('Error searching. Please try again.');
    } finally {
      setState(() {
        _isSearching = false;
      });
    }
  }

  void _onMarkerTapped(String placeId, String name) {
    debugPrint('Tapped on: $name (ID: $placeId)');
    // You can add more functionality here, like showing details
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        duration: const Duration(seconds: 3),
      ),
    );
  }

  Future<void> _centerMap() async {
    if (_mapController != null) {
      await _mapController!.animateCamera(
        CameraUpdate.newCameraPosition(_initialCameraPosition),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = S.of(context);

    return Stack(
      children: [
        // Full-screen Google Map
        GoogleMap(
          initialCameraPosition: _initialCameraPosition,
          markers: _markers,
          onMapCreated: _onMapCreated,
          mapType: MapType.normal,
          zoomControlsEnabled: false,
          myLocationButtonEnabled: false,
          compassEnabled: false,
          mapToolbarEnabled: false,
        ),

        // Gradient Overlay for top visibility
        Positioned(
          top: 0,
          left: 0,
          right: 0,
          height: 200.h,
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.white.withValues(alpha: 0.9),
                  Colors.white.withValues(alpha: 0.0),
                ],
              ),
            ),
          ),
        ),

        // Loading Indicator
        if (!_isMapReady || _isSearching)
          Center(
            child: Container(
              padding: EdgeInsets.all(16).r,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16).r,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.1),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(
                      Color(0xFFD4AF37),
                    ),
                  ),
                  12.verticalSpace,
                  Text(
                    _isSearching ? s.search : s.loadingMap,
                    style: TextStyle(
                      fontSize: 14.spMin,
                      fontWeight: FontWeight.w500,
                      color: ColorUtil.black,
                    ),
                  ),
                ],
              ),
            ),
          ),

        // Top Content Overlay
        Positioned(
          top: 0,
          left: 0,
          right: 0,
          child: SafeArea(
            bottom: false,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Location Labels
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20).r,
                  child: Row(
                    children: [
                      Icon(
                        Icons.location_on,
                        color: const Color(0xFFD4AF37),
                        size: 20.spMin,
                      ),
                      8.horizontalSpace,
                      Text(
                        s.alMuqayti,
                        style: TextStyle(
                          fontSize: 18.spMin,
                          fontWeight: FontWeight.bold,
                          color: ColorUtil.black,
                        ),
                      ),
                      8.horizontalSpace,
                      Container(
                        width: 4.r,
                        height: 4.r,
                        decoration: const BoxDecoration(
                          color: ColorUtil.grey,
                          shape: BoxShape.circle,
                        ),
                      ),
                      8.horizontalSpace,
                      Text(
                        s.alUsaylah,
                        style: TextStyle(
                          fontSize: 16.spMin,
                          fontWeight: FontWeight.w500,
                          color: ColorUtil.grey,
                        ),
                      ),
                    ],
                  ),
                ),
                16.verticalSpace,

                // Search Bar
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 20).r,
                  child: Container(
                    height: 52.spMin,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16).r,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.08),
                          blurRadius: 12,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: TextField(
                      controller: _searchController,
                      onSubmitted: _searchPlacesByQuery,
                      textInputAction: TextInputAction.search,
                      decoration: InputDecoration(
                        hintText: s.search,
                        hintStyle: TextStyle(
                          fontSize: 15.spMin,
                          color: ColorUtil.grey,
                        ),
                        prefixIcon: Icon(
                          Icons.search_rounded,
                          color: const Color(0xFFD4AF37),
                          size: 24.spMin,
                        ),
                        suffixIcon: _searchController.text.isNotEmpty
                            ? IconButton(
                                icon: const Icon(Icons.clear),
                                onPressed: () {
                                  _searchController.clear();
                                  setState(() {
                                    _markers.clear();
                                  });
                                },
                              )
                            : null,
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: 14,
                        ).r,
                      ),
                    ),
                  ),
                ),
                16.verticalSpace,

                // Category Filter Buttons
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  padding: EdgeInsets.symmetric(horizontal: 20).r,
                  child: Row(
                    children: [
                      _CategoryButton(
                        label: s.mosques,
                        icon: Icons.mosque_outlined,
                        isSelected: _selectedCategory == 'mosques',
                        onTap: () => _onCategorySelected('mosques'),
                      ),
                      12.horizontalSpace,
                      _CategoryButton(
                        label: s.ritualSites,
                        icon: Icons.star_outline_rounded,
                        isSelected: _selectedCategory == 'ritualSites',
                        onTap: () => _onCategorySelected('ritualSites'),
                      ),
                      12.horizontalSpace,
                      _CategoryButton(
                        label: s.historicSites,
                        icon: Icons.landscape_outlined,
                        isSelected: _selectedCategory == 'historicSites',
                        onTap: () => _onCategorySelected('historicSites'),
                      ),
                      12.horizontalSpace,
                      _CategoryButton(
                        label: s.museums,
                        icon: Icons.museum_outlined,
                        isSelected: _selectedCategory == 'museums',
                        onTap: () => _onCategorySelected('museums'),
                      ),
                      12.horizontalSpace,
                      _CategoryButton(
                        label: s.hotels,
                        icon: Icons.hotel_outlined,
                        isSelected: _selectedCategory == 'hotels',
                        onTap: () => _onCategorySelected('hotels'),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),

        // Compass/Navigation Button (Bottom Right)
        Positioned(
          bottom: 100.spMin,
          right: 20.spMin,
          child: SafeArea(
            child: FloatingActionButton(
              onPressed: _centerMap,
              backgroundColor: Colors.white,
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16).r,
              ),
              child: Icon(
                Icons.my_location_rounded,
                color: const Color(0xFFD4AF37),
                size: 28.spMin,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _CategoryButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool isSelected;
  final VoidCallback onTap;

  const _CategoryButton({
    required this.label,
    required this.icon,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12).r,
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFFD4AF37) : Colors.white,
          borderRadius: BorderRadius.circular(24).r,
          boxShadow: [
            if (!isSelected)
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
          ],
          border: isSelected
              ? null
              : Border.all(color: Colors.grey.withValues(alpha: 0.2)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: isSelected ? Colors.white : const Color(0xFF666666),
              size: 20.spMin,
            ),
            8.horizontalSpace,
            Text(
              label,
              style: TextStyle(
                fontSize: 14.spMin,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
                color: isSelected ? Colors.white : const Color(0xFF444444),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
