import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:labbaik/core/utilities/extensions.dart';

import '../../model/prayer_times.dart';
import '../../../../core/utilities/color_util.dart';

class PrayerScheduleCard extends StatelessWidget {
  final List<PrayerInfo> prayers;

  const PrayerScheduleCard({super.key, required this.prayers});

  IconData _getPrayerIcon(String prayerName) {
    switch (prayerName.toLowerCase()) {
      case 'fajr':
      case 'isha':
        return Icons.cloud;
      case 'sunrise':
      case 'dhuhr':
      case 'asr':
      case 'maghrib':
        return Icons.wb_sunny;
      default:
        return Icons.access_time;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16.r),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(color: Colors.white.withOpacity(0.2), width: 1),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: prayers.map((prayer) {
          return Expanded(
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 8.h, horizontal: 4.w),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    _getPrayerIcon(prayer.name),
                    color: ColorUtil.white,
                    size: 20.spMin,
                  ),
                  SizedBox(height: 4.h),
                  Text(
                    _formatPrayerName(
                      context.isArabic ? prayer.arabicName : prayer.name,
                    ),
                    style: TextStyle(
                      color: ColorUtil.white,
                      fontSize: 11.spMin,
                      fontWeight: FontWeight.w500,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 4.h),
                  Text(
                    prayer.time,
                    style: TextStyle(
                      color: ColorUtil.white.withOpacity(0.9),
                      fontSize: 10.spMin,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  String _formatPrayerName(String name) {
    // Format prayer names to be more concise for the horizontal layout
    switch (name.toLowerCase()) {
      case 'sunrise':
        return 'Sun';
      default:
        return name;
    }
  }
}
