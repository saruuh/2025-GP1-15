import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../model/prayer_times.dart';
import '../../../../core/utilities/color_util.dart';

class DateLocationCard extends StatelessWidget {
  final HijriDate hijriDate;
  final String location;

  const DateLocationCard({
    super.key,
    required this.hijriDate,
    required this.location,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
      decoration: BoxDecoration(
        color: const Color(0xFF1E8E3E), // Green color
        borderRadius: BorderRadius.circular(12.r),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          // Date
          Row(
            children: [
              Icon(
                Icons.calendar_today,
                color: ColorUtil.white,
                size: 18.spMin,
              ),
              SizedBox(width: 8.w),
              Text(
                _formatHijriDate(hijriDate),
                style: TextStyle(
                  color: ColorUtil.white,
                  fontSize: 14.spMin,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
          // Location
          Row(
            children: [
              Icon(Icons.location_on, color: ColorUtil.white, size: 18.spMin),
              SizedBox(width: 8.w),
              Text(
                location,
                style: TextStyle(
                  color: ColorUtil.white,
                  fontSize: 14.spMin,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _formatHijriDate(HijriDate hijriDate) {
    return '${hijriDate.day} ${hijriDate.month.ar} ${hijriDate.year}';
  }
}
