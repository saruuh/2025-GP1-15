import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:go_router/go_router.dart';
import 'package:labbaik/core/utilities/extensions.dart';
import 'package:provider/provider.dart';

import '../../../../core/utilities/color_util.dart';
import '../../../../core/utilities/path_util.dart';
import '../../../../core/utilities/auth_error_localizer.dart';
import '../../../../generated/l10n.dart';
import '../../../auth/presentation/screens/auth_screen.dart';
import '../../../auth/presentation/screens/profile_screen.dart';
import '../../../auth/presentation/screens/settings_screen.dart';
import '../../../auth/controller/auth_provider.dart';
import '../../../auth/model/user_model.dart';

class HomeDrawer extends StatelessWidget {
  const HomeDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      child: SafeArea(
        top: false,
        child: Column(
          children: [
            // User Card Header with Gradient
            Selector<AuthProvider, UserModel?>(
              selector: (context, authProvider) => authProvider.currentUser,
              builder: (context, user, _) {
                if (user == null) {
                  return const SizedBox();
                }

                final authProvider = context.read<AuthProvider>();
                final initials = authProvider.getUserInitials();

                return Container(
                  width: double.infinity,
                  padding: EdgeInsets.fromLTRB(
                    24,
                    MediaQuery.of(context).padding.top + 24,
                    24,
                    32,
                  ).r,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        ColorUtil.primaryColor,
                        ColorUtil.primaryW500,
                        ColorUtil.primaryW400,
                      ],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: ColorUtil.primaryColor.withValues(alpha: 0.3),
                        blurRadius: 12,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      // Profile Avatar with shadow
                      Container(
                        width: 90.spMin,
                        height: 90.spMin,
                        decoration: BoxDecoration(
                          color: ColorUtil.white.withValues(alpha: 0.25),
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: ColorUtil.white,
                            width: 3.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withValues(alpha: 0.2),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: user.profilePicture != null
                            ? ClipRRect(
                                borderRadius: BorderRadius.circular(45).r,
                                child: Image.network(
                                  user.profilePicture!,
                                  fit: BoxFit.cover,
                                  errorBuilder: (context, error, stackTrace) =>
                                      _buildInitials(initials),
                                ),
                              )
                            : _buildInitials(initials),
                      ),
                      20.verticalSpace,
                      // User Name
                      Text(
                        user.name,
                        style: TextStyle(
                          color: ColorUtil.white,
                          fontSize: 24.spMin,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.5,
                        ),
                        textAlign: TextAlign.center,
                      ),
                      8.verticalSpace,
                      // User Email
                      Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 6,
                        ).r,
                        decoration: BoxDecoration(
                          color: ColorUtil.white.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(20).r,
                        ),
                        child: Text(
                          user.email,
                          style: TextStyle(
                            color: ColorUtil.white.withValues(alpha: 0.95),
                            fontSize: 13.spMin,
                            fontWeight: FontWeight.w500,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
            // Menu Items Section
            Expanded(
              child: ListView(
                padding: EdgeInsets.symmetric(vertical: 12).r,
                children: [
                  // Account Section
                  _buildSectionHeader(
                    context: context,
                    title: S.of(context).account,
                  ),
                  8.verticalSpace,
                  // Profile Item
                  _buildDrawerItem(
                    context: context,
                    icon: PathUtil.personIcon,
                    title: S.of(context).profile,
                    onTap: () {
                      context.pop();
                      context.push(ProfileScreen.path);
                    },
                  ),
                  4.verticalSpace,
                  // Settings Item
                  _buildDrawerItem(
                    context: context,
                    icon: null,
                    iconData: Icons.settings_outlined,
                    isIcon: true,
                    title: S.of(context).settings,
                    onTap: () {
                      context.pop();
                      context.push(SettingsScreen.path);
                    },
                  ),
                  20.verticalSpace,
                  // Services Section
                  _buildSectionHeader(
                    context: context,
                    title: S.of(context).services,
                  ),
                  8.verticalSpace,
                  // Manage Companions
                  _buildDrawerItem(
                    context: context,
                    icon: PathUtil.manageCompanions,
                    title: S.of(context).manageCompanions,
                    onTap: () {
                      // TODO: Navigate to manage companions
                    },
                  ),
                  4.verticalSpace,
                  // Technical Support
                  _buildDrawerItem(
                    context: context,
                    icon: PathUtil.technicalSupport,
                    title: S.of(context).technicalSupport,
                    onTap: () {
                      // TODO: Open support
                    },
                  ),
                  20.verticalSpace,
                  // App Section
                  _buildSectionHeader(
                    context: context,
                    title: S.of(context).app,
                  ),
                  8.verticalSpace,
                  // Share App
                  _buildDrawerItem(
                    context: context,
                    icon: PathUtil.shareApp,
                    title: S.of(context).shareApp,
                    onTap: () {
                      // TODO: Share app functionality
                    },
                  ),
                  4.verticalSpace,
                  // Rate Us
                  _buildDrawerItem(
                    context: context,
                    icon: PathUtil.rateUs,
                    title: S.of(context).rateUs,
                    onTap: () {
                      // TODO: Open app store rating
                    },
                  ),
                ],
              ),
            ),
            // Logout Button
            Consumer<AuthProvider>(
              builder: (context, authProvider, _) {
                return Padding(
                  padding: EdgeInsets.fromLTRB(16, 8, 16, 24).r,
                  child: Container(
                    decoration: BoxDecoration(
                      color: context.isDarkTheme
                          ? ColorUtil.black
                          : ColorUtil.white,
                      borderRadius: BorderRadius.circular(12).r,
                      boxShadow: [
                        BoxShadow(
                          color: ColorUtil.errorColor.withValues(alpha: 0.2),
                          blurRadius: 8,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: OutlinedButton(
                      onPressed: authProvider.isLoading
                          ? null
                          : () async {
                              context.pop();
                              try {
                                await authProvider.signOut();
                                if (context.mounted) {
                                  context.go(AuthScreen.path);
                                }
                              } catch (e) {
                                if (context.mounted) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                      content: Text(
                                        AuthErrorLocalizer.getLocalizedError(
                                          authProvider.errorMessage,
                                          S.of(context),
                                        ),
                                      ),
                                      backgroundColor: Colors.red,
                                    ),
                                  );
                                }
                              }
                            },
                      style: OutlinedButton.styleFrom(
                        foregroundColor: ColorUtil.errorColor,
                        side: BorderSide(color: ColorUtil.errorColor, width: 2),
                        padding: EdgeInsets.symmetric(vertical: 16).r,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12).r,
                        ),
                        backgroundColor: context.isDarkTheme
                            ? ColorUtil.black
                            : ColorUtil.white,
                      ),
                      child: authProvider.isLoading
                          ? SizedBox(
                              height: 20.spMin,
                              width: 20.spMin,
                              child: CircularProgressIndicator(
                                strokeWidth: 2.5,
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  ColorUtil.errorColor,
                                ),
                              ),
                            )
                          : Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.logout_rounded, size: 20.spMin),
                                10.horizontalSpace,
                                Text(
                                  S.of(context).logout,
                                  style: TextStyle(
                                    fontSize: 16.spMin,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ],
                            ),
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInitials(String initials) {
    return Center(
      child: Text(
        initials.isNotEmpty ? initials : 'U',
        style: TextStyle(
          fontSize: 32.spMin,
          fontWeight: FontWeight.bold,
          color: ColorUtil.white,
        ),
      ),
    );
  }

  Widget _buildSectionHeader({
    required BuildContext context,
    required String title,
  }) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 20, vertical: 8).r,
      child: Text(
        title.toUpperCase(),
        style: TextStyle(
          fontSize: 12.spMin,
          fontWeight: FontWeight.w600,
          color: ColorUtil.primaryColor.withValues(alpha: 0.7),
          letterSpacing: 1.2,
        ),
      ),
    );
  }

  Widget _buildDrawerItem({
    required BuildContext context,
    required String? icon,
    required String title,
    required VoidCallback onTap,
    IconData? iconData,
    bool isSvg = false,
    bool isIcon = false,
  }) {
    if (icon == null && iconData == null) {
      throw Exception(S.of(context).iconAndIconDataCannotBeNull);
    }
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 12, vertical: 2).r,
      decoration: BoxDecoration(
        color: context.isDarkTheme ? ColorUtil.black : ColorUtil.white,
        borderRadius: BorderRadius.circular(12).r,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12).r,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 16).r,
            child: Row(
              children: [
                if (isSvg)
                  Container(
                    width: 40.spMin,
                    height: 40.spMin,
                    padding: EdgeInsets.all(8).r,
                    decoration: BoxDecoration(
                      color: context.isDarkTheme
                          ? ColorUtil.primaryW50
                          : ColorUtil.primaryW50,
                      borderRadius: BorderRadius.circular(10).r,
                    ),
                    child: SvgPicture.asset(
                      icon!,
                      width: 24.spMin,
                      height: 24.spMin,
                      fit: BoxFit.contain,
                      colorFilter: ColorFilter.mode(
                        ColorUtil.primaryColor,
                        BlendMode.srcIn,
                      ),
                    ),
                  )
                else if (isIcon)
                  Container(
                    width: 40.spMin,
                    height: 40.spMin,
                    decoration: BoxDecoration(
                      color: ColorUtil.primaryW50,
                      borderRadius: BorderRadius.circular(10).r,
                    ),
                    child: Icon(
                      iconData!,
                      size: 20.spMin,
                      color: ColorUtil.primaryColor,
                    ),
                  )
                else
                  Container(
                    width: 40.spMin,
                    height: 40.spMin,
                    padding: EdgeInsets.all(6).r,
                    decoration: BoxDecoration(
                      color: ColorUtil.primaryW50,
                      borderRadius: BorderRadius.circular(10).r,
                    ),
                    child: Image.asset(
                      icon!,
                      width: 28.spMin,
                      height: 28.spMin,
                      fit: BoxFit.contain,
                    ),
                  ),
                16.horizontalSpace,
                Expanded(
                  child: Text(
                    title,
                    style: TextStyle(
                      fontSize: 16.spMin,
                      fontWeight: FontWeight.w600,
                      color: ColorUtil.darkGrey,
                      letterSpacing: 0.2,
                    ),
                  ),
                ),
                8.horizontalSpace,
                Icon(
                  Icons.arrow_forward_ios,
                  size: 14.spMin,
                  color: ColorUtil.lightGrey,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
