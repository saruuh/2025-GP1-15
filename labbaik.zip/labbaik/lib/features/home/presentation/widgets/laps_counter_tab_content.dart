import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../core/utilities/color_util.dart';
import '../../../../generated/l10n.dart';

/// Reusable widget for the Laps Counter tab content
class LapsCounterTabContent extends StatefulWidget {
  const LapsCounterTabContent({super.key});

  @override
  State<LapsCounterTabContent> createState() => _LapsCounterTabContentState();
}

class _LapsCounterTabContentState extends State<LapsCounterTabContent> {
  int _lapCount = 0;
  final int _totalLaps = 7;

  void _incrementLap() {
    setState(() {
      if (_lapCount < _totalLaps) {
        _lapCount++;
      }
    });
  }

  void _decrementLap() {
    setState(() {
      if (_lapCount > 0) {
        _lapCount--;
      }
    });
  }

  void _resetLaps() {
    setState(() {
      _lapCount = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    final progress = _totalLaps > 0 ? _lapCount / _totalLaps : 0.0;

    return Center(
      child: SingleChildScrollView(
        padding: EdgeInsets.symmetric(horizontal: 24).r,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            40.verticalSpace,
            // Title
            Text(
              S.of(context).tawaf,
              style: TextStyle(
                fontSize: 28.spMin,
                fontWeight: FontWeight.bold,
                color: ColorUtil.darkGrey,
              ),
            ),
            20.verticalSpace,
            // Progress Card
            Container(
              padding: EdgeInsets.all(24).r,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    ColorUtil.primaryColor.withValues(alpha: 0.1),
                    ColorUtil.accentColor.withValues(alpha: 0.05),
                  ],
                ),
                borderRadius: BorderRadius.circular(20).r,
                border: Border.all(
                  color: ColorUtil.primaryColor.withValues(alpha: 0.2),
                  width: 2,
                ),
              ),
              child: Column(
                children: [
                  // Lap Counter Display
                  Text(
                    '$_lapCount / $_totalLaps',
                    style: TextStyle(
                      fontSize: 64.spMin,
                      fontWeight: FontWeight.bold,
                      color: ColorUtil.primaryColor,
                    ),
                  ),
                  8.verticalSpace,
                  Text(
                    S.of(context).steps,
                    style: TextStyle(fontSize: 18.spMin, color: ColorUtil.grey),
                  ),
                  24.verticalSpace,
                  // Progress Bar
                  Stack(
                    children: [
                      Container(
                        height: 12.spMin,
                        decoration: BoxDecoration(
                          color: ColorUtil.primaryColor.withValues(alpha: 0.1),
                          borderRadius: BorderRadius.circular(6).r,
                        ),
                      ),
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 300),
                        height: 12.spMin,
                        width:
                            MediaQuery.of(context).size.width * 0.7 * progress,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              ColorUtil.primaryColor,
                              ColorUtil.accentColor,
                            ],
                          ),
                          borderRadius: BorderRadius.circular(6).r,
                        ),
                      ),
                    ],
                  ),
                  8.verticalSpace,
                  Text(
                    '${(progress * 100).toInt()}%',
                    style: TextStyle(
                      fontSize: 14.spMin,
                      color: ColorUtil.grey,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
            40.verticalSpace,
            // Control Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Decrement Button
                _buildControlButton(
                  icon: Icons.remove,
                  onPressed: _decrementLap,
                  enabled: _lapCount > 0,
                ),
                24.horizontalSpace,
                // Reset Button
                _buildControlButton(
                  icon: Icons.refresh,
                  onPressed: _resetLaps,
                  enabled: _lapCount > 0,
                ),
                24.horizontalSpace,
                // Increment Button
                _buildControlButton(
                  icon: Icons.add,
                  onPressed: _incrementLap,
                  enabled: _lapCount < _totalLaps,
                ),
              ],
            ),
            40.verticalSpace,
          ],
        ),
      ),
    );
  }

  Widget _buildControlButton({
    required IconData icon,
    required VoidCallback onPressed,
    required bool enabled,
  }) {
    return GestureDetector(
      onTap: enabled ? onPressed : null,
      child: Container(
        width: 56.spMin,
        height: 56.spMin,
        decoration: BoxDecoration(
          color: enabled
              ? ColorUtil.primaryColor
              : ColorUtil.primaryColor.withValues(alpha: 0.3),
          shape: BoxShape.circle,
          boxShadow: enabled
              ? [
                  BoxShadow(
                    color: ColorUtil.primaryColor.withValues(alpha: 0.4),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ]
              : [],
        ),
        child: Icon(icon, color: Colors.white, size: 28.spMin),
      ),
    );
  }
}
