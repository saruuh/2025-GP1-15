import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../../../../generated/l10n.dart' show S;
import '../../model/prayer_times.dart';
import '../../../../core/utilities/color_util.dart';

class PrayerTimesCard extends StatefulWidget {
  final Timing timings;
  final Date date;

  const PrayerTimesCard({super.key, required this.timings, required this.date});

  @override
  State<PrayerTimesCard> createState() => _PrayerTimesCardState();
}

class _PrayerTimesCardState extends State<PrayerTimesCard> {
  late String currentPrayer;
  late DateTime nextPrayerTime;
  String remainingTime = '';

  @override
  void initState() {
    super.initState();
    _calculateCurrentPrayer();
    _startTimer();
  }

  void _calculateCurrentPrayer() {
    final now = DateTime.now();

    // Parse prayer times
    final fajr = _parseTime(widget.timings.fajr);
    final sunrise = _parseTime(widget.timings.sunrise);
    final dhuhr = _parseTime(widget.timings.dhuhr);
    final asr = _parseTime(widget.timings.asr);
    final maghrib = _parseTime(widget.timings.maghrib);
    final isha = _parseTime(widget.timings.isha);

    // Determine next prayer (the one we're counting down to)
    if (now.isBefore(fajr)) {
      currentPrayer = S.current.fajr;
      nextPrayerTime = fajr;
    } else if (now.isBefore(sunrise)) {
      currentPrayer = S.current.sunrise;
      nextPrayerTime = sunrise;
    } else if (now.isBefore(dhuhr)) {
      currentPrayer = S.current.dhuhr;
      nextPrayerTime = dhuhr;
    } else if (now.isBefore(asr)) {
      currentPrayer = S.current.asr;
      nextPrayerTime = asr;
    } else if (now.isBefore(maghrib)) {
      currentPrayer = S.current.maghrib;
      nextPrayerTime = maghrib;
    } else if (now.isBefore(isha)) {
      currentPrayer = S.current.isha;
      nextPrayerTime = isha;
    } else {
      currentPrayer = S.current.fajr;
      // Next prayer is tomorrow's Fajr
      nextPrayerTime = fajr.add(const Duration(days: 1));
    }
  }

  DateTime _parseTime(String timeStr) {
    final parts = timeStr.split(' ');
    final timeOnly = parts[0];
    final components = timeOnly.split(':');
    final hour = int.parse(components[0]);
    final minute = int.parse(components[1]);

    final now = DateTime.now();
    var prayerTime = DateTime(now.year, now.month, now.day, hour, minute);

    // Adjust for AM/PM
    if (parts.length > 1 && parts[1].toUpperCase() == 'PM' && hour != 12) {
      prayerTime = prayerTime.add(const Duration(hours: 12));
    }

    return prayerTime;
  }

  void _startTimer() {
    _updateRemainingTime();
    Future.delayed(const Duration(seconds: 1), () {
      if (mounted) {
        setState(() {
          _updateRemainingTime();
        });
        _startTimer();
      }
    });
  }

  void _updateRemainingTime() {
    final now = DateTime.now();
    final difference = nextPrayerTime.difference(now);

    if (difference.isNegative) {
      // If prayer time has passed, recalculate
      _calculateCurrentPrayer();
      return;
    }

    final hours = difference.inHours;
    final minutes = difference.inMinutes.remainder(60);
    final seconds = difference.inSeconds.remainder(60);

    remainingTime =
        '${hours.toString().padLeft(2, '0')}:'
        '${minutes.toString().padLeft(2, '0')}:'
        '${seconds.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(24.r),
      decoration: BoxDecoration(
        color: ColorUtil.black.withValues(alpha: 0.3),
        borderRadius: BorderRadius.circular(20.r),
        border: Border.all(
          color: ColorUtil.white.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          // Current Prayer Name
          Text(
            currentPrayer,
            style: TextStyle(
              color: ColorUtil.white,
              fontSize: 32.spMin,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 8.h),
          // Status
          Text(
            S.of(context).remaining,
            style: TextStyle(
              color: ColorUtil.white.withValues(alpha: 0.8),
              fontSize: 16.spMin,
            ),
          ),
          SizedBox(height: 16.h),
          // Remaining Time
          Text(
            remainingTime,
            style: TextStyle(
              color: ColorUtil.white,
              fontSize: 48.spMin,
              fontWeight: FontWeight.bold,
              fontFeatures: [const FontFeature.tabularFigures()],
            ),
          ),
        ],
      ),
    );
  }
}
