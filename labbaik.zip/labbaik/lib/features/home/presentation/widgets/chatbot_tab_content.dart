import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:labbaik/core/utilities/extensions.dart';

import '../../../../core/utilities/color_util.dart';
import '../../../../generated/l10n.dart';

/// Reusable widget for the ChatBot tab content
class ChatBotTabContent extends StatefulWidget {
  const ChatBotTabContent({super.key});

  @override
  State<ChatBotTabContent> createState() => _ChatBotTabContentState();
}

class _ChatBotTabContentState extends State<ChatBotTabContent> {
  final TextEditingController _messageController = TextEditingController();
  final List<ChatMessage> _messages = [];
  bool _isTyping = false;

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }

  void _sendMessage(String text) {
    if (text.trim().isEmpty) return;

    setState(() {
      _messages.add(ChatMessage(text: text, isUser: true));
      _messageController.clear();
      _isTyping = true;
    });

    // Simulate bot response
    Future.delayed(const Duration(seconds: 1), () {
      if (mounted) {
        setState(() {
          _isTyping = false;
          _messages.add(
            ChatMessage(text: _getBotResponse(text), isUser: false),
          );
        });
      }
    });
  }

  String _getBotResponse(String userMessage) {
    final lowerMessage = userMessage.toLowerCase();
    if (lowerMessage.contains('hello') || lowerMessage.contains('hi')) {
      return 'Assalamu Alaikum! How can I help you with your Umrah journey?';
    } else if (lowerMessage.contains('ihram') ||
        lowerMessage.contains('ihraam')) {
      return 'Ihram is the sacred state a pilgrim enters before performing Umrah. You need to wear specific garments and follow certain prohibitions. Would you like to know more about the steps?';
    } else if (lowerMessage.contains('tawaf')) {
      return 'Tawaf is the act of circumambulating the Kaaba seven times counterclockwise. It\'s the first ritual after entering Ihram. Each round should start and end at the Black Stone.';
    } else if (lowerMessage.contains('saee') ||
        lowerMessage.contains('sa\'ee')) {
      return 'Sa\'ee is walking between Safa and Marwah seven times. This ritual commemorates Hagar\'s search for water. You start at Safa and end at Marwah.';
    } else if (lowerMessage.contains('tahallul')) {
      return 'Tahallul is the act of cutting or shaving your hair after completing Sa\'ee. This marks the end of Umrah and allows you to exit the state of Ihram.';
    } else {
      return 'I\'m here to help you with your Umrah journey. You can ask me about Ihram, Tawaf, Sa\'ee, Tahallul, or any other questions about the rituals.';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Chat Messages
        Expanded(
          child: _messages.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 80.spMin,
                        height: 80.spMin,
                        decoration: BoxDecoration(
                          color: ColorUtil.primaryColor.withValues(alpha: 0.2),
                          shape: BoxShape.circle,
                        ),
                        child: Icon(
                          Icons.chat_bubble_outline,
                          size: 40.spMin,
                          color: context.isDarkTheme
                              ? Colors.white
                              : Colors.black,
                        ),
                      ),
                      24.verticalSpace,
                      Text(
                        S.of(context).welcomeToLabbaikAssistant,
                        style: TextStyle(
                          fontSize: 20.spMin,
                          fontWeight: FontWeight.bold,
                          color: context.isDarkTheme
                              ? Colors.white
                              : Colors.black,
                        ),
                      ),
                      8.verticalSpace,
                      Text(
                        S.of(context).askMeAnythingAboutUmrah,
                        style: TextStyle(
                          fontSize: 16.spMin,
                          color: context.isDarkTheme
                              ? Colors.white70
                              : Colors.black,
                        ),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  padding: EdgeInsets.all(16).r,
                  itemCount: _messages.length + (_isTyping ? 1 : 0),
                  itemBuilder: (context, index) {
                    if (index == _messages.length) {
                      return _buildTypingIndicator();
                    }
                    return _buildMessageBubble(_messages[index]);
                  },
                ),
        ),
        // Input Area
        Container(
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8).r,
          decoration: BoxDecoration(
            color: Colors.black.withValues(alpha: 0.1),
            border: Border(
              top: BorderSide(
                color: Colors.black.withValues(alpha: 0.2),
                width: 1,
              ),
            ),
          ),
          child: SafeArea(
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(24).r,
                    ),
                    child: TextField(
                      controller: _messageController,
                      style: TextStyle(color: Colors.black, fontSize: 16.spMin),
                      decoration: InputDecoration(
                        hintText: S.of(context).typeYourMessage,
                        hintStyle: TextStyle(fontSize: 16.spMin),
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 12,
                        ).r,
                      ),
                      onSubmitted: _sendMessage,
                    ),
                  ),
                ),
                12.horizontalSpace,
                GestureDetector(
                  onTap: () => _sendMessage(_messageController.text),
                  child: Container(
                    width: 48.spMin,
                    height: 48.spMin,
                    decoration: BoxDecoration(
                      color: ColorUtil.primaryColor,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.send,
                      color: Colors.white,
                      size: 24.spMin,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildMessageBubble(ChatMessage message) {
    return Padding(
      padding: EdgeInsets.only(bottom: 12).r,
      child: Row(
        mainAxisAlignment: message.isUser
            ? MainAxisAlignment.end
            : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (!message.isUser) ...[
            Container(
              width: 32.spMin,
              height: 32.spMin,
              decoration: BoxDecoration(
                color: ColorUtil.primaryColor,
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.smart_toy, color: Colors.white, size: 18.spMin),
            ),
            8.horizontalSpace,
          ],
          Flexible(
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12).r,
              decoration: BoxDecoration(
                color: message.isUser
                    ? ColorUtil.primaryColor
                    : Colors.black.withValues(alpha: 0.2),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(16).r,
                  topRight: Radius.circular(16).r,
                  bottomLeft: message.isUser
                      ? Radius.circular(16).r
                      : Radius.circular(4).r,
                  bottomRight: message.isUser
                      ? Radius.circular(4).r
                      : Radius.circular(16).r,
                ),
              ),
              child: Text(
                message.text,
                style: TextStyle(color: Colors.white, fontSize: 16.spMin),
              ),
            ),
          ),
          if (message.isUser) ...[
            8.horizontalSpace,
            Container(
              width: 32.spMin,
              height: 32.spMin,
              decoration: BoxDecoration(
                color: Colors.black.withValues(alpha: 0.2),
                shape: BoxShape.circle,
              ),
              child: Icon(Icons.person, color: Colors.white, size: 18.spMin),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildTypingIndicator() {
    return Padding(
      padding: EdgeInsets.only(bottom: 12).r,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Container(
            width: 32.spMin,
            height: 32.spMin,
            decoration: BoxDecoration(
              color: ColorUtil.primaryColor,
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.smart_toy, color: Colors.white, size: 18.spMin),
          ),
          8.horizontalSpace,
          Container(
            padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12).r,
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(16).r,
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildDot(0),
                4.horizontalSpace,
                _buildDot(1),
                4.horizontalSpace,
                _buildDot(2),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDot(int index) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 500),
      width: 8.spMin,
      height: 8.spMin,
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.3 + (index * 0.2)),
        shape: BoxShape.circle,
      ),
    );
  }
}

class ChatMessage {
  final String text;
  final bool isUser;

  ChatMessage({required this.text, required this.isUser});
}
