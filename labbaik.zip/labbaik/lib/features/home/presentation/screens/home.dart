import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart' show SvgPicture;
import 'package:go_router/go_router.dart';
import 'package:labbaik/core/utilities/extensions.dart';
import 'package:labbaik/features/ritual_guidance/presentation/ritual_guidance/ritual_guidance_screen.dart';
import 'package:provider/provider.dart';

import '../../../../core/utilities/color_util.dart';
import '../../../../core/utilities/path_util.dart';
import '../../../../core/widgets/custom_transition_page.dart'
    show CustomTransitionPageBuilder;
import '../../controller/prayer_times_provider.dart';
import '../widgets/home_drawer.dart';
import '../widgets/custom_bottom_nav_bar.dart';
import '../widgets/home_tab_content.dart';
import '../widgets/laps_counter_tab_content.dart';
import '../widgets/map_tab_content.dart';
import '../widgets/chatbot_tab_content.dart';

class MainAppScreen extends StatefulWidget {
  static const String path = '/mainApp';
  static const String routeName = 'mainApp';
  final int? index;

  const MainAppScreen({super.key, this.index});

  static CustomTransitionPageBuilder page(
    BuildContext context,
    GoRouterState state,
  ) => CustomTransitionPageBuilder(
    key: state.pageKey,
    page: MainAppScreen(index: state.extra as int?),
    name: routeName,
  );

  static void goHome({required BuildContext context, int? index}) =>
      context.go(path, extra: index);

  @override
  State<MainAppScreen> createState() => _MainAppScreenState();
}

class _MainAppScreenState extends State<MainAppScreen> {
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.index ?? 0;
    // Load prayer times on screen initialization
    Future.microtask(() {
      final provider = context.read<PrayerTimesProvider>();
      if (provider.prayerTimes == null && !provider.isLoading) {
        // Try to load with location detection, fallback to default if it fails
        provider.loadPrayerTimesWithLocation();
      }
    });
  }

  @override
  void didUpdateWidget(MainAppScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.index != null && widget.index != _currentIndex) {
      setState(() {
        _currentIndex = widget.index!;
      });
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    final provider = context.read<PrayerTimesProvider>();
    if (provider.prayerTimes == null && !provider.isLoading) {
      // Try to load with location detection, fallback to default if it fails
      provider.loadPrayerTimesWithLocation();
    }
  }

  void _onNavItemTapped(int index) {
    setState(() {
      _currentIndex = index;
    });
  }

  Widget _getTabContent() {
    switch (_currentIndex) {
      case 0:
        return const HomeTabContent(key: ValueKey('home'));
      case 1:
        return const RitualGuidanceScreen(key: ValueKey('ritual_guidance'));
      case 2:
        return const LapsCounterTabContent(key: ValueKey('laps'));
      case 3:
        return const MapTabContent(key: ValueKey('map'));
      case 4:
        return const ChatBotTabContent(key: ValueKey('chatbot'));
      default:
        return const HomeTabContent(key: ValueKey('home'));
    }
  }

  @override
  Widget build(BuildContext context) {
    final bool isHomeTab = _currentIndex == 0;
    final bool isMapTab = _currentIndex == 3;

    // Map tab should be full screen without header
    if (isMapTab) {
      return Scaffold(
        drawer: const HomeDrawer(),
        bottomNavigationBar: CustomBottomNavBar(
          currentIndex: _currentIndex,
          onTap: _onNavItemTapped,
        ),
        body: _getTabContent(),
      );
    }

    return Scaffold(
      drawer: const HomeDrawer(),
      bottomNavigationBar: CustomBottomNavBar(
        currentIndex: _currentIndex,
        onTap: _onNavItemTapped,
      ),
      body: Container(
        decoration: isHomeTab
            ? BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(PathUtil.homeBg),
                  fit: BoxFit.fill,
                ),
              )
            : null,
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8).r,
          width: double.infinity,
          height: double.infinity,
          color: isHomeTab
              ? ColorUtil.black.withValues(alpha: 0.5)
              : Theme.of(context).scaffoldBackgroundColor,
          child: SafeArea(
            bottom: false,
            child: Column(
              children: [
                // Header with menu and logo
                Builder(
                  builder: (context) => Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      GestureDetector(
                        onTap: () => Scaffold.of(context).openDrawer(),
                        child: Icon(
                          Icons.menu,
                          color: isHomeTab || context.isDarkTheme
                              ? ColorUtil.white
                              : ColorUtil.black,
                          size: 30.spMin,
                        ),
                      ),
                      SvgPicture.asset(
                        isHomeTab ? PathUtil.logoDark : PathUtil.logoLight,
                        width: 40.spMin,
                        height: 40.spMin,
                        fit: BoxFit.scaleDown,
                      ),
                    ],
                  ),
                ),
                20.verticalSpace,
                // Tab content with smooth transitions
                Expanded(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 300),
                    transitionBuilder: (child, animation) {
                      return FadeTransition(
                        opacity: animation,
                        child: SlideTransition(
                          position: Tween<Offset>(
                            begin: const Offset(0.1, 0),
                            end: Offset.zero,
                          ).animate(animation),
                          child: child,
                        ),
                      );
                    },
                    child: _getTabContent(),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
