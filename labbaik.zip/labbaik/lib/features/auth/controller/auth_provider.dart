import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:labbaik/core/services/auth_service.dart';
import 'package:labbaik/core/utilities/custom_logger.dart';
import 'package:labbaik/features/auth/model/user_model.dart';

/// Controller for authentication state management
/// Handles sign up, sign in, and email verification
class AuthProvider extends ChangeNotifier {
  final AuthService _authService = AuthService();

  bool _isLoading = false;
  bool _isEmailVerificationInProgress = false;
  String? _errorMessage;
  User? _currentFirebaseUser;
  UserModel? _currentUser;
  bool _isSignup = false;

  // Getters
  bool get isLoading => _isLoading;
  bool get isEmailVerificationInProgress => _isEmailVerificationInProgress;
  String? get errorMessage => _errorMessage;
  User? get currentFirebaseUser => _currentFirebaseUser;
  UserModel? get currentUser => _currentUser;
  bool get isAuthenticated => _currentFirebaseUser != null;
  bool get isEmailVerified => _currentFirebaseUser?.emailVerified ?? false;
  bool get isSignup => _isSignup;

  AuthProvider() {
    _initializeAuthState();
  }

  /// Initialize auth state listener
  void _initializeAuthState() {
    _authService.authStateChanges.listen((User? user) {
      _currentFirebaseUser = user;
      notifyListeners();
    });
  }

  /// Set signup mode
  void setIsSignup(bool value) {
    _isSignup = value;
    notifyListeners();
  }

  /// Sign up with email and password
  Future<bool> signUp({
    required String email,
    required String password,
    required String firstName,
    required String lastName,
    required String phoneNumber,
    required String countryCode,
    required String dateOfBirth,
  }) async {
    try {
      _isLoading = true;
      _errorMessage = null;
      notifyListeners();

      await _authService.signUpWithEmailAndPassword(
        email: email,
        password: password,
        firstName: firstName,
        lastName: lastName,
        phoneNumber: phoneNumber,
        countryCode: countryCode,
        dateOfBirth: dateOfBirth,
      );

      _currentFirebaseUser = _authService.currentUser;
      _isLoading = false;
      notifyListeners();
      return true;
    } on FirebaseAuthException catch (e) {
      _errorMessage = _getErrorMessage(e.code);
      _isLoading = false;
      notifyListeners();
      CustomLogger.instance.error('Sign up failed: ${e.code}');
      return false;
    } catch (e) {
      _errorMessage = 'unexpectedErrorOccurred';
      _isLoading = false;
      notifyListeners();
      CustomLogger.instance.error('Sign up error: $e');
      return false;
    }
  }

  /// Sign in with email and password
  Future<bool> signIn({required String email, required String password}) async {
    try {
      _isLoading = true;
      _errorMessage = null;
      notifyListeners();

      await _authService.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      _currentFirebaseUser = _authService.currentUser;
      _isLoading = false;
      notifyListeners();
      return true;
    } on FirebaseAuthException catch (e) {
      _errorMessage = _getErrorMessage(e.code);
      _isLoading = false;
      notifyListeners();
      CustomLogger.instance.error('Sign in failed: ${e.code}');
      return false;
    } catch (e) {
      _errorMessage = 'unexpectedErrorOccurred';
      _isLoading = false;
      notifyListeners();
      CustomLogger.instance.error('Sign in error: $e');
      return false;
    }
  }

  /// Send email verification
  Future<bool> sendEmailVerification() async {
    try {
      _isEmailVerificationInProgress = true;
      _errorMessage = null;
      notifyListeners();

      await _authService.sendEmailVerification();

      _isEmailVerificationInProgress = false;
      notifyListeners();
      return true;
    } catch (e) {
      _errorMessage = 'failedToSendVerificationEmail';
      _isEmailVerificationInProgress = false;
      notifyListeners();
      CustomLogger.instance.error('Send verification email error: $e');
      return false;
    }
  }

  /// Check email verification status
  Future<bool> checkEmailVerification() async {
    try {
      final bool isVerified = await _authService.checkEmailVerification();
      if (_currentFirebaseUser != null) {
        _currentFirebaseUser = _authService.currentUser;
      }
      notifyListeners();
      return isVerified;
    } catch (e) {
      CustomLogger.instance.error('Check email verification error: $e');
      return false;
    }
  }

  /// Sign out
  Future<void> signOut() async {
    try {
      await _authService.signOut();
      _currentFirebaseUser = null;
      _currentUser = null;
      notifyListeners();
    } catch (e) {
      _errorMessage = 'failedToSignOut';
      notifyListeners();
      CustomLogger.instance.error('Sign out error: $e');
    }
  }

  /// Set user data
  void setUser(UserModel user) {
    _currentUser = user;
    notifyListeners();
  }

  /// Update user data
  void updateUser(UserModel updatedUser) {
    _currentUser = updatedUser;
    notifyListeners();
  }

  /// Clear user data
  void clearUser() {
    _currentUser = null;
    notifyListeners();
  }

  /// Get user initials for avatar display
  String getUserInitials() {
    if (_currentUser == null || _currentUser!.name.isEmpty) {
      return '';
    }
    final parts = _currentUser!.name.split(' ');
    if (parts.length >= 2) {
      return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    }
    return _currentUser!.name[0].toUpperCase();
  }

  /// Clear error message
  void clearError() {
    _errorMessage = null;
    notifyListeners();
  }

  /// Change password
  Future<bool> changePassword(
    String currentPassword,
    String newPassword,
  ) async {
    try {
      _isLoading = true;
      _errorMessage = null;
      notifyListeners();

      await _authService.changePassword(
        currentPassword: currentPassword,
        newPassword: newPassword,
      );

      _isLoading = false;
      notifyListeners();
      return true;
    } on FirebaseAuthException catch (e) {
      _errorMessage = _getErrorMessage(e.code);
      _isLoading = false;
      notifyListeners();
      CustomLogger.instance.error('Change password failed: ${e.code}');
      return false;
    } catch (e) {
      _errorMessage = 'errorOccurred';
      _isLoading = false;
      notifyListeners();
      CustomLogger.instance.error('Change password error: $e');
      return false;
    }
  }

  /// Get user-friendly error message key for localization
  String _getErrorMessage(String code) {
    switch (code) {
      case 'weak-password':
        return 'weakPassword';
      case 'email-already-in-use':
        return 'emailAlreadyInUse';
      case 'invalid-email':
        return 'invalidEmail';
      case 'user-disabled':
        return 'userDisabled';
      case 'user-not-found':
        return 'userNotFound';
      case 'wrong-password':
        return 'wrongPassword';
      case 'too-many-requests':
        return 'tooManyRequests';
      case 'operation-not-allowed':
        return 'operationNotAllowed';
      default:
        return 'errorOccurred';
    }
  }
}
