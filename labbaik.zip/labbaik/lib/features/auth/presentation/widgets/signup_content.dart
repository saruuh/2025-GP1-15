part of '../screens/auth_screen.dart';

class SignupContent extends StatefulWidget {
  const SignupContent({super.key});

  @override
  State<SignupContent> createState() => _SignupContentState();
}

class _SignupContentState extends State<SignupContent> {
  final FocusNode fNameFocusNode = FocusNode();
  final FocusNode lNameFocusNode = FocusNode();
  final FocusNode emailFocusNode = FocusNode();
  final FocusNode passwordFocusNode = FocusNode();
  final FocusNode confirmPasswordFocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  final TextEditingController fNameController = TextEditingController();
  final TextEditingController lNameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController =
      TextEditingController();
  final TextEditingController dateOfBirthController = TextEditingController();
  final FocusNode dateOfBirthFocusNode = FocusNode();
  final TextEditingController phoneNumberController = TextEditingController();
  final FocusNode phoneNumberFocusNode = FocusNode();

  bool isPasswordVisible = false;
  bool isConfirmPasswordVisible = false;
  String selectedCountryCode = '+966';
  String selectedCountryName = 'Saudi Arabia';
  String selectedCountryFlag = 'sa';
  bool hasValidatedPassword = false;
  bool isSubmitting = false;
  void setIsPasswordVisible(bool value) {
    setState(() {
      isPasswordVisible = value;
    });
  }

  void setIsConfirmPasswordVisible(bool value) {
    setState(() {
      isConfirmPasswordVisible = value;
    });
  }

  @override
  void dispose() {
    fNameController.dispose();
    lNameController.dispose();
    emailController.dispose();
    passwordController.dispose();
    confirmPasswordController.dispose();
    fNameFocusNode.dispose();
    lNameFocusNode.dispose();
    emailFocusNode.dispose();
    passwordFocusNode.dispose();
    confirmPasswordFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Form(
          key: formKey,
          child: Column(
            spacing: 16,
            children: [
              8.verticalSpace,
              Row(
                spacing: 16,
                children: [
                  Expanded(
                    child: AppTextField(
                      labelText: S.of(context).fName,
                      focusNode: fNameFocusNode,
                      textEditingController: fNameController,
                      hintText: S.of(context).fName,
                      validator: AppValidator.validateName,
                    ),
                  ),
                  Expanded(
                    child: AppTextField(
                      labelText: S.of(context).lName,
                      focusNode: lNameFocusNode,
                      textEditingController: lNameController,
                      hintText: S.of(context).lName,
                      validator: AppValidator.validateName,
                    ),
                  ),
                ],
              ),
              AppTextField(
                labelText: S.of(context).email,
                focusNode: emailFocusNode,
                textEditingController: emailController,
                hintText: S.of(context).email,
                validator: AppValidator.validateEmail,
              ),
              AppTextField(
                readOnly: true,
                onTap: () async {
                  final date = await showDatePicker(
                    context: context,
                    initialDate: DateTime.now(),
                    firstDate: DateTime(1900),
                    lastDate: DateTime.now(),
                  );
                  if (date != null) {
                    // into english format
                    dateOfBirthController.text = DateFormat(
                      'dd/MM/yyyy',
                      'en',
                    ).format(date);
                  }
                },
                labelText: S.of(context).dateOfBirth,
                focusNode: dateOfBirthFocusNode,
                textEditingController: dateOfBirthController,
                hintText: S.of(context).dateOfBirth,
                keyBoardType: TextInputType.datetime,
                suffixWidget: Icon(
                  Icons.calendar_month,
                  color: ColorUtil.lightGrey,
                ),
                validator: AppValidator.validateDateOfBirth,
              ),
              AppTextField(
                labelText: S.of(context).phoneNumber,
                focusNode: phoneNumberFocusNode,
                textEditingController: phoneNumberController,
                hintText: S.of(context).phoneNumber,
                keyBoardType: TextInputType.phone,
                formatters: [FilteringTextInputFormatter.digitsOnly],
                validator: AppValidator.validatePhoneNumber,
                prefixWidth: 112,

                prefixWidget: CountryCodePicker(
                  showDropDownButton: true,
                  flagWidth: 20,
                  showOnlyCountryWhenClosed: true,
                  showCountryOnly: true,
                  hideMainText: true,
                  alignLeft: true,
                  padding: EdgeInsets.zero,
                  onChanged: (country) {
                    selectedCountryCode = country.dialCode!;
                    selectedCountryName = country.name!;
                    selectedCountryFlag = country.code!;
                  },
                  initialSelection: selectedCountryCode,
                  favorite: [selectedCountryCode, selectedCountryName],
                ),
              ),
              AppTextField(
                labelText: S.of(context).password,
                focusNode: passwordFocusNode,
                textEditingController: passwordController,
                hintText: S.of(context).password,
                validator: PasswordValidationHelper.validatePasswordWithRules,
                isPassword: true,
                hidePassword: !isPasswordVisible,
                onChanged: (value) {
                  setState(() {}); // Trigger rebuild to update stepper
                },
                suffixWidget: IconButton(
                  onPressed: () => setIsPasswordVisible(!isPasswordVisible),
                  icon: Icon(
                    isPasswordVisible ? Iconsax.eye : Iconsax.eye_slash,
                    color: ColorUtil.lightGrey,
                  ),
                ),
              ),
              Column(
                children: [
                  AppTextField(
                    labelText: S.of(context).confirmPassword,
                    focusNode: confirmPasswordFocusNode,
                    textEditingController: confirmPasswordController,
                    hintText: S.of(context).confirmPassword,
                    validator: (value) => AppValidator.validateConfirmPassword(
                      value,
                      passwordController.text,
                    ),
                    isPassword: true,
                    hidePassword: !isConfirmPasswordVisible,
                    suffixWidget: IconButton(
                      onPressed: () => setIsConfirmPasswordVisible(
                        !isConfirmPasswordVisible,
                      ),
                      icon: Icon(
                        isConfirmPasswordVisible
                            ? Iconsax.eye
                            : Iconsax.eye_slash,
                        color: ColorUtil.lightGrey,
                      ),
                    ),
                  ),
                  if (passwordFocusNode.hasFocus &&
                      passwordController.text.isNotEmpty)
                    PasswordValidationStepper(
                      password: passwordController.text,
                      hasValidated: hasValidatedPassword,
                    ),
                ],
              ),

              16.verticalSpace,
              Row(
                children: [
                  Expanded(
                    child: LoadingButton(
                      text: S.of(context).register,
                      isLoading: isSubmitting,
                      onPressed: () async {
                        setState(() {
                          hasValidatedPassword = true;
                        });
                        if (formKey.currentState!.validate()) {
                          setState(() {
                            isSubmitting = true;
                          });

                          final authProvider = context.read<AuthProvider>();
                          final success = await authProvider.signUp(
                            email: emailController.text.trim(),
                            password: passwordController.text,
                            firstName: fNameController.text.trim(),
                            lastName: lNameController.text.trim(),
                            phoneNumber: phoneNumberController.text.trim(),
                            countryCode: selectedCountryCode,
                            dateOfBirth: dateOfBirthController.text.trim(),
                          );

                          if (mounted) {
                            setState(() {
                              isSubmitting = false;
                            });

                            if (success) {
                              context.go(
                                VerifyEmailScreen.path,
                                extra: VerifyEmailScreen(
                                  email: emailController.text.trim(),
                                  isSignup: true,
                                ),
                              );
                            } else {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                    AuthErrorLocalizer.getLocalizedError(
                                      authProvider.errorMessage,
                                      S.of(context),
                                    ),
                                  ),
                                  backgroundColor: Colors.red,
                                ),
                              );
                            }
                          }
                        }
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}
