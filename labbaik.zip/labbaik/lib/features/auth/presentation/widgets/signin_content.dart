part of '../screens/auth_screen.dart';

class SigninContent extends StatefulWidget {
  const SigninContent({super.key});

  @override
  State<SigninContent> createState() => _SigninContentState();
}

class _SigninContentState extends State<SigninContent> {
  final FocusNode emailFocusNode = FocusNode();
  final FocusNode passwordFocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  bool rememberMe = false;
  bool isPasswordVisible = false;
  bool isSubmitting = false;
  void setRememberMe(bool value) {
    setState(() {
      rememberMe = value;
    });
  }

  void setIsPasswordVisible(bool value) {
    setState(() {
      isPasswordVisible = value;
    });
  }

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    emailFocusNode.dispose();
    passwordFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Form(
          key: formKey,
          child: Column(
            spacing: 16,
            children: [
              8.verticalSpace,
              AppTextField(
                labelText: S.of(context).email,
                focusNode: emailFocusNode,
                textEditingController: emailController,
                hintText: S.of(context).email,
                validator: AppValidator.validateEmail,
              ),
              AppTextField(
                labelText: S.of(context).password,
                focusNode: passwordFocusNode,
                textEditingController: passwordController,
                hintText: S.of(context).password,
                isPassword: true,
                hidePassword: !isPasswordVisible,
                suffixWidget: IconButton(
                  onPressed: () => setIsPasswordVisible(!isPasswordVisible),
                  icon: Icon(
                    isPasswordVisible ? Iconsax.eye : Iconsax.eye_slash,
                    color: ColorUtil.lightGrey,
                  ),
                ),
              ),
              //
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Checkbox(
                        value: rememberMe,
                        onChanged: (value) => setRememberMe(value ?? false),
                      ),
                      Text(S.of(context).rememberMe),
                    ],
                  ),

                  TextButton(
                    onPressed: () {
                      context.push(ForgotPasswordScreen.path);
                    },
                    child: Text(S.of(context).forgotPassword),
                  ),
                ],
              ),
              20.verticalSpace,
              Row(
                children: [
                  Expanded(
                    child: LoadingButton(
                      text: S.of(context).signIn,
                      isLoading: isSubmitting,
                      onPressed: () async {
                        if (formKey.currentState!.validate()) {
                          setState(() {
                            isSubmitting = true;
                          });

                          final authProvider = context.read<AuthProvider>();
                          final authService = AuthService();

                          final success = await authProvider.signIn(
                            email: emailController.text.trim(),
                            password: passwordController.text,
                          );

                          if (mounted) {
                            setState(() {
                              isSubmitting = false;
                            });

                            if (success) {
                              // Load user data
                              final currentUser = authService.currentUser;
                              if (currentUser != null) {
                                try {
                                  final userData = await authService
                                      .getUserData(currentUser.uid);
                                  if (userData != null) {
                                    authProvider.setUser(userData);
                                  }
                                } catch (e) {
                                  // Handle error
                                }
                              }
                              context.go(MainAppScreen.path);
                            } else {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                    AuthErrorLocalizer.getLocalizedError(
                                      authProvider.errorMessage,
                                      S.of(context),
                                    ),
                                  ),
                                  backgroundColor: Colors.red,
                                ),
                              );
                            }
                          }
                        }
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}
