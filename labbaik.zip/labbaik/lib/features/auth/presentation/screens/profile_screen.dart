import 'package:country_code_picker/country_code_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:labbaik/core/utilities/color_util.dart';
import 'package:labbaik/core/utilities/extensions.dart';
import 'package:provider/provider.dart';

import '../../../../core/utilities/path_util.dart';
import '../../../../core/widgets/custom_transition_page.dart'
    show CustomTransitionPageBuilder;
import '../../../../generated/l10n.dart';
import '../../controller/auth_provider.dart';
import '../../model/user_model.dart';

class ProfileScreen extends StatelessWidget {
  static const String routeName = 'profile';
  static const String path = '/profile';

  static CustomTransitionPageBuilder page(
    BuildContext context,
    GoRouterState state,
  ) => CustomTransitionPageBuilder(
    key: state.pageKey,
    page: const ProfileScreen(),
    name: routeName,
  );

  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: context.isDarkTheme ? ColorUtil.black : ColorUtil.white,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Icon(
            Icons.arrow_back,
            color: Theme.of(context).iconTheme.color,
          ),
          onPressed: () => context.pop(),
        ),
        title: Text(
          S.of(context).profile,
          style: Theme.of(
            context,
          ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Selector<AuthProvider, UserModel?>(
        selector: (context, authProvider) => authProvider.currentUser,
        builder: (context, user, child) {
          if (user == null) {
            return const Center(child: CircularProgressIndicator());
          }

          final authProvider = context.read<AuthProvider>();

          return SingleChildScrollView(
            padding: EdgeInsets.all(16).r,
            child: Column(
              children: [
                20.verticalSpace,
                // Profile Picture
                _buildProfilePicture(context, authProvider),
                16.verticalSpace,
                // User Name
                Text(
                  user.name,
                  style: Theme.of(
                    context,
                  ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                ),
                24.verticalSpace,
                // General Section
                _buildSectionHeader(context),
                12.verticalSpace,
                _buildInfoRow(
                  context,
                  icon: PathUtil.personIcon,
                  label: S.of(context).name,
                  value: user.name,
                ),
                8.verticalSpace,
                _buildInfoRow(
                  context,
                  icon: PathUtil.emailIcon,
                  label: S.of(context).email,
                  value: user.email,
                ),
                8.verticalSpace,
                _buildPhoneRow(context, user),
                24.verticalSpace,
                // Manage Companions
                _buildManageCompanionsRow(context),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildProfilePicture(BuildContext context, AuthProvider authProvider) {
    final initials = authProvider.getUserInitials();

    return Container(
      width: 100.w,
      height: 100.w,
      decoration: BoxDecoration(
        color: const Color(0xFFE8F5E9),
        shape: BoxShape.circle,
      ),
      child: Center(
        child: Text(
          initials.isNotEmpty ? initials : 'U',
          style: TextStyle(
            fontSize: 32.sp,
            fontWeight: FontWeight.bold,
            color: const Color(0xFF2E7D32),
          ),
        ),
      ),
    );
  }

  Widget _buildSectionHeader(BuildContext context) {
    return Align(
      alignment: Alignment.centerLeft,
      child: Text(
        S.of(context).general,
        style: Theme.of(
          context,
        ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget _buildInfoRow(
    BuildContext context, {
    required String icon,
    required String label,
    required String value,
  }) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 16).r,
      decoration: BoxDecoration(
        color: context.isDarkTheme ? ColorUtil.black : ColorUtil.white,
        borderRadius: BorderRadius.circular(12).r,
      ),
      child: Row(
        children: [
          Image.asset(icon, width: 24.w, height: 24.w, color: Colors.grey[700]),
          12.horizontalSpace,
          Expanded(
            child: Text(value, style: Theme.of(context).textTheme.bodyMedium),
          ),
        ],
      ),
    );
  }

  Widget _buildPhoneRow(BuildContext context, user) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 16).r,
      decoration: BoxDecoration(
        color: context.isDarkTheme ? ColorUtil.black : ColorUtil.white,
        borderRadius: BorderRadius.circular(12).r,
      ),
      child: Row(
        children: [
          Image.asset(
            PathUtil.phoneIcon,
            width: 40.spMin,
            height: 40.spMin,
            fit: BoxFit.scaleDown,
          ),
          12.horizontalSpace,

          CountryCodePicker(
            showDropDownButton: true,
            flagWidth: 20,
            showOnlyCountryWhenClosed: true,
            showCountryOnly: true,
            hideMainText: true,
            alignLeft: true,
            margin: EdgeInsets.zero,
            padding: EdgeInsets.zero,
            initialSelection: 'SA',
            favorite: ['+966', 'SA'],
            onChanged: (country) {},
          ),
          12.horizontalSpace,
          Text(
            "(${user.countryCode!}) " + user.phone,
            style: Theme.of(context).textTheme.bodyMedium,
          ),
        ],
      ),
    );
  }

  Widget _buildManageCompanionsRow(BuildContext context) {
    return InkWell(
      onTap: () {
        // Navigate to manage companions
        // TODO: Implement navigation
      },
      borderRadius: BorderRadius.circular(12).r,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 16).r,
        decoration: BoxDecoration(
          color: context.isDarkTheme ? ColorUtil.black : ColorUtil.white,
          borderRadius: BorderRadius.circular(12).r,
        ),
        child: Row(
          children: [
            Image.asset(
              PathUtil.manageCompanions,
              width: 24.w,
              height: 24.w,
              color: Colors.grey[700],
            ),
            12.horizontalSpace,
            Expanded(
              child: Text(
                S.of(context).manageCompanions,
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ),
            Icon(Icons.arrow_forward_ios, size: 16.sp, color: Colors.grey[700]),
          ],
        ),
      ),
    );
  }
}
