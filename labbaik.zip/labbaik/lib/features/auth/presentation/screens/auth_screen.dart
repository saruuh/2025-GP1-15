import 'package:country_code_picker/country_code_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show FilteringTextInputFormatter;
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:go_router/go_router.dart';
import 'package:iconsax/iconsax.dart';
import 'package:intl/intl.dart';
import 'package:labbaik/core/utilities/extensions.dart';
import 'package:provider/provider.dart';

import '../../../../core/utilities/app_validators.dart';
import '../../../../core/utilities/color_util.dart';
import '../../../../core/utilities/path_util.dart';
import '../../../../core/utilities/auth_error_localizer.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../../../../core/widgets/loading_button.dart';
import '../../../../core/widgets/password_validation_stepper.dart';
import '../../../../core/widgets/custom_transition_page.dart'
    show CustomTransitionPageBuilder;
import '../../../../generated/l10n.dart';
import '../../../home/presentation/screens/home.dart';
import '../../../settings/controller/settings_controller.dart'
    show SettingsController;
import '../../controller/auth_provider.dart';
import '../../../../core/services/auth_service.dart';
import 'forgot_password_screen.dart';
import 'verify_email.dart';

part '../widgets/signin_content.dart';
part '../widgets/signup_content.dart';

class AuthScreen extends StatefulWidget {
  static const String routeName = 'auth';
  static const String path = '/auth';

  static CustomTransitionPageBuilder page(
    BuildContext context,
    GoRouterState state,
  ) => CustomTransitionPageBuilder(
    key: state.pageKey,
    page: const AuthScreen(),
    name: routeName,
  );

  const AuthScreen({super.key});

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool isSignup = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8).r,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(PathUtil.authBg),
            fit: BoxFit.fill,
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              spacing: 8,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  mainAxisSize: MainAxisSize.max,
                  spacing: 8,
                  children: [
                    ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        minimumSize: Size(120, 30),
                        backgroundColor: ColorUtil.primaryColor,
                        foregroundColor: context.isDarkTheme
                            ? ColorUtil.white
                            : ColorUtil.black,
                        shape: StadiumBorder(),
                        padding: EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 0,
                        ).r,
                      ),

                      onPressed: () {
                        context.read<SettingsController>().toggleLanguage(
                          !context.isArabic,
                        );
                      },
                      label: Text(
                        context.isArabic
                            ? S.of(context).english
                            : S.of(context).arabic,
                        style: Theme.of(
                          context,
                        ).textTheme.bodyMedium!.copyWith(color: Colors.white),
                        textAlign: TextAlign.center,
                      ),
                      icon: Icon(Icons.language),
                    ),
                  ],
                ),
                50.verticalSpace,
                SvgPicture.asset(PathUtil.logoLight, width: 80, height: 80),
                // Get Started now
                Text(
                  S.of(context).getStartedNow,
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                SizedBox(
                  width: context.screenWidth * 0.8,
                  child: Text(
                    isSignup
                        ? S
                              .of(context)
                              .startYourPathTowardHajjAndUmrahWithPersonalizedGuidance
                        : S
                              .of(context)
                              .yourLabbaikJourneyAwaitsLogInToReconnectWithYourGuidance,
                    style: Theme.of(context).textTheme.bodyMedium,
                    textAlign: TextAlign.center,
                  ),
                ),
                Container(
                  padding: EdgeInsets.all(4).r,
                  decoration: BoxDecoration(
                    color: Color(0xfff5f6f9),
                    borderRadius: BorderRadius.circular(12).r,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    spacing: 8,
                    children: [
                      Expanded(
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              isSignup = false;
                            });
                          },
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.symmetric(
                              vertical: 8,
                              horizontal: 16,
                            ).r,
                            decoration: BoxDecoration(
                              color: !isSignup ? Colors.white : null,
                              borderRadius: BorderRadius.circular(12).r,
                            ),
                            child: Text(
                              S.of(context).signIn,
                              style: Theme.of(context).textTheme.bodyMedium,
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                      ),
                      Expanded(
                        child: GestureDetector(
                          onTap: () {
                            setState(() {
                              isSignup = true;
                            });
                          },
                          child: Container(
                            width: double.infinity,
                            padding: EdgeInsets.symmetric(
                              vertical: 8,
                              horizontal: 16,
                            ).r,
                            decoration: BoxDecoration(
                              color: isSignup ? Colors.white : null,
                              borderRadius: BorderRadius.circular(12).r,
                            ),
                            child: Text(
                              S.of(context).signUp,
                              style: Theme.of(context).textTheme.bodyMedium,
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                if (isSignup) SignupContent() else SigninContent(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
