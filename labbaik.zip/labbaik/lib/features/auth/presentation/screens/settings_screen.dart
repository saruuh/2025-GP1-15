import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:labbaik/core/utilities/extensions.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../../core/services/theme_service.dart';
import '../../../../core/utilities/path_util.dart';
import '../../../../core/widgets/k_app_header.dart';
import '../../../../core/widgets/custom_transition_page.dart'
    show CustomTransitionPageBuilder;
import '../../../../generated/l10n.dart';
import '../../../../core/widgets/language_selection_dialog.dart';

class SettingsScreen extends StatefulWidget {
  static const String routeName = 'settings';
  static const String path = '/settings';

  static CustomTransitionPageBuilder page(
    BuildContext context,
    GoRouterState state,
  ) => CustomTransitionPageBuilder(
    key: state.pageKey,
    page: const SettingsScreen(),
    name: routeName,
  );

  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final ThemeService _themeService = ThemeService.instance;
  bool _locationEnabled = false;

  @override
  void initState() {
    super.initState();
    _themeService.addListener(_onThemeChanged);
    _loadLocationSetting();
  }

  @override
  void dispose() {
    _themeService.removeListener(_onThemeChanged);
    super.dispose();
  }

  void _onThemeChanged() {
    setState(() {});
  }

  Future<void> _loadLocationSetting() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _locationEnabled = prefs.getBool('location_enabled') ?? false;
    });
  }

  Future<void> _toggleLocation(bool value) async {
    setState(() {
      _locationEnabled = value;
    });
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('location_enabled', value);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,

      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(16).r,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              KAppHeader(showBackButton: true, showTrailing: false),
              10.verticalSpace,
              Text(
                S.of(context).settings,
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: context.isDarkTheme ? Colors.white : Colors.black,
                ),
              ),
              20.verticalSpace,
              // Dark Mode
              _buildSettingItem(
                context: context,
                iconPath: PathUtil.darkMode,
                title: S.of(context).darkMode,
                trailing: _buildDarkModeToggle(),
              ),
              12.verticalSpace,
              // Change Password
              _buildSettingItem(
                context: context,
                iconPath: PathUtil.changePassword,
                title: S.of(context).changePassword,
                onTap: () {
                  context.push('/change-password');
                },
              ),
              12.verticalSpace,
              // Calendar
              _buildSettingItem(
                context: context,
                iconPath: PathUtil.calendar,
                title: S.of(context).calendar,
                onTap: () {
                  // TODO: Navigate to calendar screen
                },
              ),
              12.verticalSpace,
              // App Language
              _buildSettingItem(
                context: context,
                iconPath: PathUtil.appLanguage,
                title: S.of(context).appLanguage,
                onTap: () {
                  LanguageSelectionDialog.show(context);
                },
              ),
              12.verticalSpace,
              // Location
              _buildSettingItem(
                context: context,
                iconPath: PathUtil.location,
                title: S.of(context).location,
                trailing: _buildLocationToggle(),
              ),
              30.verticalSpace,
              Divider(color: Colors.grey[100], height: 1),

              30.verticalSpace,
              // Rate Us
              _buildSettingItem(
                context: context,
                iconPath: PathUtil.rateUs,
                title: S.of(context).rateUs,
                onTap: () {
                  // TODO: Open app store rating
                },
              ),
              12.verticalSpace,
              // Technical Support
              _buildSettingItem(
                context: context,
                iconPath: PathUtil.technicalSupport,
                title: S.of(context).technicalSupport,
                onTap: () {
                  // TODO: Open support screen or contact
                },
              ),
              12.verticalSpace,
              // Share App
              _buildSettingItem(
                context: context,
                iconPath: PathUtil.shareApp,
                title: S.of(context).shareApp,
                onTap: () {
                  // TODO: Share app functionality
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSettingItem({
    required BuildContext context,
    required String iconPath,
    required String title,
    VoidCallback? onTap,
    Widget? trailing,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12).r,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8).r,
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(12).r,
          boxShadow: [
            BoxShadow(
              color: Theme.of(context).shadowColor.withValues(alpha: 0.05),
              blurRadius: 4,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Row(
          children: [
            Image.asset(
              iconPath,
              width: 40.spMin,
              height: 40.spMin,
              fit: BoxFit.scaleDown,
            ),
            16.horizontalSpace,
            Expanded(
              child: Text(
                title,
                style: Theme.of(
                  context,
                ).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w500),
              ),
            ),
            if (trailing != null)
              trailing
            else if (onTap != null)
              Icon(
                Icons.arrow_forward_ios,
                size: 16.spMin,
                color: Theme.of(context).iconTheme.color,
              )
            else
              const SizedBox(),
          ],
        ),
      ),
    );
  }

  Widget _buildDarkModeToggle() {
    final bool isDarkMode = _themeService.isDarkMode;
    return Transform.scale(
      scale: 0.8,
      child: Switch.adaptive(
        value: isDarkMode,
        onChanged: (value) async {
          await _themeService.toggleTheme();
        },
      ),
    );
  }

  Widget _buildLocationToggle() {
    return Transform.scale(
      scale: 0.8,
      child: Switch.adaptive(
        value: _locationEnabled,
        onChanged: _toggleLocation,
      ),
    );
  }
}
