import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iconsax/iconsax.dart';
import 'package:labbaik/core/utilities/extensions.dart';
import 'package:provider/provider.dart';

import '../../../../core/utilities/color_util.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../../../../core/widgets/k_app_header.dart';
import '../../../../core/widgets/password_validation_stepper.dart';
import '../../../../core/widgets/custom_transition_page.dart'
    show CustomTransitionPageBuilder;
import '../../../../generated/l10n.dart';
import '../../controller/auth_provider.dart';

class ChangePasswordScreen extends StatefulWidget {
  const ChangePasswordScreen({super.key});

  static const String routeName = 'change-password';
  static const String path = '/change-password';

  static CustomTransitionPageBuilder page(
    BuildContext context,
    GoRouterState state,
  ) {
    return CustomTransitionPageBuilder(
      key: state.pageKey,
      page: const ChangePasswordScreen(),
      name: routeName,
    );
  }

  @override
  State<ChangePasswordScreen> createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  final FocusNode currentPasswordFocusNode = FocusNode();
  final FocusNode newPasswordFocusNode = FocusNode();
  final FocusNode confirmPasswordFocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  final TextEditingController currentPasswordController =
      TextEditingController();
  final TextEditingController newPasswordController = TextEditingController();
  final TextEditingController confirmPasswordController =
      TextEditingController();

  bool isCurrentPasswordVisible = false;
  bool isPasswordVisible = false;
  bool isConfirmPasswordVisible = false;
  bool hasValidated = false;
  bool isSubmitting = false;

  @override
  void dispose() {
    currentPasswordController.dispose();
    newPasswordController.dispose();
    confirmPasswordController.dispose();
    currentPasswordFocusNode.dispose();
    newPasswordFocusNode.dispose();
    confirmPasswordFocusNode.dispose();
    super.dispose();
  }

  void setIsCurrentPasswordVisible(bool value) {
    setState(() {
      isCurrentPasswordVisible = value;
    });
  }

  void setIsPasswordVisible(bool value) {
    setState(() {
      isPasswordVisible = value;
    });
  }

  void setIsConfirmPasswordVisible(bool value) {
    setState(() {
      isConfirmPasswordVisible = value;
    });
  }

  String? validateCurrentPassword(String? value) {
    if (value == null || value.isEmpty) {
      return S.of(context).passwordRequired;
    }
    return null;
  }

  String? validateNewPassword(String? value) {
    if (value == null || value.isEmpty) {
      return S.of(context).passwordRequired;
    }
    if (value == currentPasswordController.text) {
      return S.of(context).newPasswordMustBeDifferent;
    }
    return null;
  }

  String? validateConfirmPassword(String? value) {
    if (value == null || value.isEmpty) {
      return S.of(context).passwordRequired;
    }
    if (value != newPasswordController.text) {
      return S.of(context).confirmPasswordNotMatch;
    }
    return null;
  }

  bool _isPasswordValid = false;

  void onValidationChanged() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        setState(() {
          _isPasswordValid = _evaluatePasswordValidity();
        });
      }
    });
  }

  bool _evaluatePasswordValidity() {
    final password = newPasswordController.text;
    return password.length >= 8 &&
        password.contains(RegExp(r'[A-Z]')) &&
        password.contains(RegExp(r'[a-z]')) &&
        password.contains(RegExp(r'[0-9]')) &&
        password.contains(RegExp(r'[!@#$%^&*()_+]')) &&
        !password.contains(' ');
  }

  Future<void> _handleChangePassword() async {
    if (!_isPasswordValid) {
      setState(() {
        hasValidated = true;
      });
      return;
    }

    if (formKey.currentState!.validate()) {
      setState(() {
        isSubmitting = true;
        hasValidated = true;
      });

      final authProvider = context.read<AuthProvider>();
      final success = await authProvider.changePassword(
        currentPasswordController.text,
        newPasswordController.text,
      );

      setState(() {
        isSubmitting = false;
      });

      if (mounted) {
        if (success) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(S.of(context).passwordChangedSuccessfully),
              backgroundColor: Colors.green,
            ),
          );
          context.pop();
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(
                authProvider.errorMessage != null
                    ? S.of(context).wrongPassword
                    : S.of(context).errorOccurred,
              ),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    } else {
      setState(() {
        hasValidated = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.r, vertical: 8.r),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              spacing: 16,
              children: [
                KAppHeader(showBackButton: true),
                20.verticalSpace,

                // Title
                Text(
                  S.of(context).changePassword,
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: context.isDarkTheme ? Colors.white : Colors.black,
                  ),
                  textAlign: TextAlign.start,
                ),

                8.verticalSpace,

                // Description
                Text(
                  S.of(context).pleaseTypeSomethingYoullRemember,
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: context.isDarkTheme ? Colors.white : Colors.black,
                  ),
                  textAlign: TextAlign.start,
                ),

                30.verticalSpace,

                // Form
                Form(
                  key: formKey,
                  child: Column(
                    spacing: 20,
                    children: [
                      // Current Password Field
                      AppTextField.transparentWithBorder(
                        labelText: S.of(context).currentPassword,
                        focusNode: currentPasswordFocusNode,
                        textEditingController: currentPasswordController,
                        hintText: S.of(context).currentPassword,
                        validator: validateCurrentPassword,
                        isPassword: true,
                        onChanged: (value) {
                          setState(() {});
                        },
                        hidePassword: !isCurrentPasswordVisible,
                        suffixWidget: IconButton(
                          onPressed: () => setIsCurrentPasswordVisible(
                            !isCurrentPasswordVisible,
                          ),
                          icon: Icon(
                            isCurrentPasswordVisible
                                ? Iconsax.eye
                                : Iconsax.eye_slash,
                            color: ColorUtil.lightGrey,
                          ),
                        ),
                      ),

                      20.verticalSpace,

                      // New Password Field
                      AppTextField.transparentWithBorder(
                        labelText: S.of(context).newPassword,
                        focusNode: newPasswordFocusNode,
                        textEditingController: newPasswordController,
                        hintText: S.of(context).newPassword,
                        validator: validateNewPassword,
                        isPassword: true,
                        onChanged: (value) {
                          setState(() {});
                        },
                        hidePassword: !isPasswordVisible,
                        suffixWidget: IconButton(
                          onPressed: () =>
                              setIsPasswordVisible(!isPasswordVisible),
                          icon: Icon(
                            isPasswordVisible ? Iconsax.eye : Iconsax.eye_slash,
                            color: ColorUtil.lightGrey,
                          ),
                        ),
                      ),

                      // Password Requirements
                      PasswordValidationStepper(
                        password: newPasswordController.text,
                        hasValidated: hasValidated,
                        onValidationChanged: onValidationChanged,
                      ),

                      // Confirm Password Field
                      AppTextField.transparentWithBorder(
                        labelText: S.of(context).confirmNewPassword,
                        focusNode: confirmPasswordFocusNode,
                        textEditingController: confirmPasswordController,
                        hintText: S.of(context).confirmNewPassword,
                        validator: validateConfirmPassword,
                        isPassword: true,
                        hidePassword: !isConfirmPasswordVisible,
                        onChanged: (value) {
                          setState(() {});
                        },
                        suffixWidget: IconButton(
                          onPressed: () => setIsConfirmPasswordVisible(
                            !isConfirmPasswordVisible,
                          ),
                          icon: Icon(
                            isConfirmPasswordVisible
                                ? Iconsax.eye
                                : Iconsax.eye_slash,
                            color: ColorUtil.lightGrey,
                          ),
                        ),
                      ),

                      30.verticalSpace,

                      // Change Password Button
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                            child: ElevatedButton(
                              onPressed: isSubmitting
                                  ? null
                                  : _handleChangePassword,
                              style: ElevatedButton.styleFrom(
                                padding: EdgeInsets.symmetric(vertical: 16.r),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12.r),
                                ),
                              ),
                              child: isSubmitting
                                  ? SizedBox(
                                      height: 20.r,
                                      width: 20.r,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(
                                              Colors.white,
                                            ),
                                      ),
                                    )
                                  : Text(
                                      S.of(context).changePassword,
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
