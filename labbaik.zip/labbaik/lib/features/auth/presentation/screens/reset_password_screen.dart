import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:iconsax/iconsax.dart';
import 'package:labbaik/core/utilities/extensions.dart';

import '../../../../core/utilities/color_util.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../../../../core/widgets/k_app_header.dart';
import '../../../../core/widgets/password_validation_stepper.dart'
    show PasswordValidationStepper;
import '../../../../core/widgets/custom_transition_page.dart'
    show CustomTransitionPageBuilder;
import '../../../../generated/l10n.dart';

class ResetPasswordScreen extends StatefulWidget {
  final String email;

  const ResetPasswordScreen({super.key, required this.email});

  static const String routeName = 'reset-password';
  static const String path = '/reset-password';

  static CustomTransitionPageBuilder page(
    BuildContext context,
    GoRouterState state,
  ) {
    final screen = state.extra as ResetPasswordScreen;
    return CustomTransitionPageBuilder(
      key: state.pageKey,
      page: ResetPasswordScreen(email: screen.email),
      name: routeName,
    );
  }

  @override
  State<ResetPasswordScreen> createState() => _ResetPasswordScreenState();
}

class _ResetPasswordScreenState extends State<ResetPasswordScreen> {
  final FocusNode newPasswordFocusNode = FocusNode();
  final FocusNode confirmPasswordFocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  final TextEditingController newPasswordController = TextEditingController();
  final TextEditingController confirmPasswordController =
      TextEditingController();

  bool isPasswordVisible = false;
  bool isConfirmPasswordVisible = false;
  bool hasValidated = false;
  bool isSubmitting = false;

  @override
  void dispose() {
    newPasswordController.dispose();
    confirmPasswordController.dispose();
    newPasswordFocusNode.dispose();
    confirmPasswordFocusNode.dispose();
    super.dispose();
  }

  void setIsPasswordVisible(bool value) {
    setState(() {
      isPasswordVisible = value;
    });
  }

  void setIsConfirmPasswordVisible(bool value) {
    setState(() {
      isConfirmPasswordVisible = value;
    });
  }

  String? validateNewPassword(String? value) {
    if (value == null || value.isEmpty) {
      return S.of(context).passwordRequired;
    }
    return null;
  }

  String? validateConfirmPassword(String? value) {
    if (value == null || value.isEmpty) {
      return S.of(context).passwordRequired;
    }
    if (value != newPasswordController.text) {
      return S.of(context).confirmPasswordNotMatch;
    }
    return null;
  }

  bool _isPasswordValid = false;

  void onValidationChanged() {
    // Defer state update to after current frame to avoid setState during build
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        setState(() {
          // Re-evaluate password validity
          _isPasswordValid = _evaluatePasswordValidity();
        });
      }
    });
  }

  bool _evaluatePasswordValidity() {
    final password = newPasswordController.text;
    return password.length >= 8 &&
        password.contains(RegExp(r'[A-Z]')) &&
        password.contains(RegExp(r'[a-z]')) &&
        password.contains(RegExp(r'[0-9]')) &&
        password.contains(RegExp(r'[!@#$%^&*()_+]')) &&
        !password.contains(' ');
  }

  Future<void> _handleResetPassword() async {
    if (!_isPasswordValid) {
      setState(() {
        hasValidated = true;
      });
      return;
    }

    if (formKey.currentState!.validate()) {
      setState(() {
        isSubmitting = true;
        hasValidated = true;
      });

      // TODO: Implement password reset API call
      await Future.delayed(const Duration(seconds: 2));

      setState(() {
        isSubmitting = false;
      });

      if (mounted) {
        // Navigate to success screen
        context.go('/password-change-success');
      }
    } else {
      setState(() {
        hasValidated = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.r, vertical: 8.r),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              spacing: 16,
              children: [
                KAppHeader(showBackButton: true),
                20.verticalSpace,

                // Title
                Text(
                  S.of(context).resetPassword,
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: context.isDarkTheme ? Colors.white : Colors.black,
                  ),
                  textAlign: TextAlign.start,
                ),

                8.verticalSpace,

                // Description
                Text(
                  S.of(context).pleaseTypeSomethingYoullRemember,
                  style: Theme.of(
                    context,
                  ).textTheme.bodyMedium?.copyWith(color: Colors.grey[600]),
                  textAlign: TextAlign.start,
                ),

                30.verticalSpace,

                // Form
                Form(
                  key: formKey,
                  child: Column(
                    spacing: 20,
                    children: [
                      // New Password Field
                      AppTextField.transparentWithBorder(
                        labelText: S.of(context).newPassword,
                        focusNode: newPasswordFocusNode,
                        textEditingController: newPasswordController,
                        hintText: S.of(context).newPassword,
                        validator: validateNewPassword,
                        isPassword: true,
                        hidePassword: !isPasswordVisible,
                        suffixWidget: IconButton(
                          onPressed: () =>
                              setIsPasswordVisible(!isPasswordVisible),
                          icon: Icon(
                            isPasswordVisible ? Iconsax.eye : Iconsax.eye_slash,
                            color: ColorUtil.lightGrey,
                          ),
                        ),
                      ),

                      // Password Requirements
                      PasswordValidationStepper(
                        password: newPasswordController.text,
                        hasValidated: hasValidated,
                        onValidationChanged: onValidationChanged,
                      ),

                      20.verticalSpace,

                      // Confirm Password Field
                      AppTextField.transparentWithBorder(
                        labelText: S.of(context).confirmNewPassword,
                        focusNode: confirmPasswordFocusNode,
                        textEditingController: confirmPasswordController,
                        hintText: S.of(context).confirmNewPassword,
                        validator: validateConfirmPassword,
                        isPassword: true,
                        hidePassword: !isConfirmPasswordVisible,
                        suffixWidget: IconButton(
                          onPressed: () => setIsConfirmPasswordVisible(
                            !isConfirmPasswordVisible,
                          ),
                          icon: Icon(
                            isConfirmPasswordVisible
                                ? Iconsax.eye
                                : Iconsax.eye_slash,
                            color: ColorUtil.lightGrey,
                          ),
                        ),
                      ),

                      30.verticalSpace,

                      // Reset Password Button
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                            child: ElevatedButton(
                              onPressed: isSubmitting
                                  ? null
                                  : _handleResetPassword,
                              style: ElevatedButton.styleFrom(
                                padding: EdgeInsets.symmetric(vertical: 16.r),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12.r),
                                ),
                              ),
                              child: isSubmitting
                                  ? SizedBox(
                                      height: 20.r,
                                      width: 20.r,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(
                                              Colors.white,
                                            ),
                                      ),
                                    )
                                  : Text(
                                      S.of(context).resetPassword,
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                20.verticalSpace,

                // Back to Login
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      S.of(context).alreadyHaveAnAccount,
                      style: Theme.of(
                        context,
                      ).textTheme.bodySmall?.copyWith(color: ColorUtil.black),
                    ),
                    TextButton(
                      onPressed: () => context.go('/auth'),
                      child: Text(
                        S.of(context).login,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
