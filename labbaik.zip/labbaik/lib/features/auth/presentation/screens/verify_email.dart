import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:labbaik/core/utilities/extensions.dart';
import 'package:labbaik/features/home/presentation/screens/home.dart';
import 'package:labbaik/generated/l10n.dart';
import 'package:provider/provider.dart';
import 'package:labbaik/core/services/auth_service.dart';
import 'package:labbaik/core/utilities/auth_error_localizer.dart';
import 'package:labbaik/core/widgets/k_app_header.dart';
import 'package:labbaik/core/widgets/custom_transition_page.dart'
    show CustomTransitionPageBuilder;
import 'package:labbaik/features/auth/controller/auth_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'reset_password_screen.dart';

class VerifyEmailScreen extends StatefulWidget {
  final String email;
  final bool isSignup;

  const VerifyEmailScreen({
    super.key,
    required this.email,
    required this.isSignup,
  });

  static const String routeName = 'verify-email';
  static const String path = '/verify-email';

  static CustomTransitionPageBuilder page(
    BuildContext context,
    GoRouterState state,
  ) {
    final screen = state.extra as VerifyEmailScreen;
    return CustomTransitionPageBuilder(
      key: state.pageKey,
      page: VerifyEmailScreen(email: screen.email, isSignup: screen.isSignup),
      name: routeName,
    );
  }

  @override
  State<VerifyEmailScreen> createState() => _VerifyEmailScreenState();
}

class _VerifyEmailScreenState extends State<VerifyEmailScreen> {
  late final String email = widget.email;
  late final bool isSignup = widget.isSignup;

  int countdown = 120; // 2 minutes in seconds
  Timer? countdownTimer;
  Timer? verificationCheckTimer;
  bool canResend = false;
  bool isEmailVerified = false;

  @override
  void initState() {
    super.initState();
    _loadTimerState();
    _startVerificationCheck();
  }

  /// Load saved timer state from SharedPreferences
  /// This handles the scenario where user closes app before verifying
  Future<void> _loadTimerState() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final savedTimestamp = prefs.getInt('email_verification_timestamp');

      if (savedTimestamp != null) {
        final now = DateTime.now().millisecondsSinceEpoch;
        final elapsed = (now - savedTimestamp) ~/ 1000;

        if (elapsed < 120) {
          // Timer hasn't expired, continue from saved state
          countdown = 120 - elapsed;
          canResend = false;
        } else {
          // Timer expired
          countdown = 0;
          canResend = true;
        }
      }

      startCountdown();
    } catch (e) {
      // If error, start fresh timer
      startCountdown();
    }
  }

  /// Save timer state to SharedPreferences
  Future<void> _saveTimerState() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt(
        'email_verification_timestamp',
        DateTime.now().millisecondsSinceEpoch,
      );
    } catch (e) {
      // Handle error silently
    }
  }

  /// Start periodic check for email verification
  void _startVerificationCheck() {
    verificationCheckTimer = Timer.periodic(const Duration(seconds: 3), (
      timer,
    ) async {
      if (!mounted) {
        timer.cancel();
        return;
      }

      final authProvider = context.read<AuthProvider>();
      final isVerified = await authProvider.checkEmailVerification();

      if (isVerified && !isEmailVerified) {
        setState(() {
          isEmailVerified = true;
        });
        timer.cancel();
        countdownTimer?.cancel();
        _navigateToNextScreen();
      }
    });
  }

  void startCountdown() {
    _saveTimerState();
    countdownTimer?.cancel();
    countdownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (countdown > 0) {
        setState(() {
          countdown--;
          canResend = countdown == 0;
        });
      } else {
        timer.cancel();
        setState(() {
          canResend = true;
        });
      }
    });
  }

  Future<void> resendLink() async {
    if (canResend) {
      final authProvider = context.read<AuthProvider>();
      final success = await authProvider.sendEmailVerification();

      if (success && mounted) {
        setState(() {
          countdown = 120; // Reset to 2 minutes
          canResend = false;
        });
        startCountdown();

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(S.of(context).resetLinkSentMessage),
            backgroundColor: Colors.green,
          ),
        );
      } else if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              AuthErrorLocalizer.getLocalizedError(
                authProvider.errorMessage,
                S.of(context),
              ),
            ),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _navigateToNextScreen() async {
    if (!mounted) return;

    final authService = AuthService();
    final authProvider = context.read<AuthProvider>();
    final currentUser = authService.currentUser;

    if (currentUser != null && isSignup) {
      // Load user data and navigate to home
      try {
        final userData = await authService.getUserData(currentUser.uid);
        if (userData != null) {
          authProvider.setUser(userData);
        }
      } catch (e) {
        // Handle error
      }
    }

    if (mounted) {
      if (isSignup) {
        context.go(MainAppScreen.path);
      } else {
        context.push(
          ResetPasswordScreen.path,
          extra: ResetPasswordScreen(email: email),
        );
      }
    }
  }

  @override
  void dispose() {
    countdownTimer?.cancel();
    verificationCheckTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final String displayEmail = email.length > 25
        ? '${email.substring(0, 22)}...'
        : email;

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 16).r,
          child: Column(
            children: [
              // Header
              KAppHeader(showBackButton: true),

              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      40.verticalSpace,

                      // Email Icon
                      Icon(
                        Icons.email_outlined,
                        size: 80.spMin,
                        color: theme.primaryColor,
                      ),

                      32.verticalSpace,

                      // Title
                      Text(
                        S.of(context).pleaseCheckYourEmail,
                        style: theme.textTheme.headlineMedium?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: context.isDarkTheme
                              ? Colors.white
                              : Colors.black,
                        ),
                        textAlign: TextAlign.center,
                      ),

                      16.verticalSpace,

                      // Description
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 24).r,
                        child: Text(
                          S.of(context).weveSentACodeTo(displayEmail),
                          style: theme.textTheme.bodyMedium?.copyWith(
                            color: Colors.grey[600],
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),

                      24.verticalSpace,

                      // Instruction
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 24).r,
                        child: Text(
                          S.of(context).clickTheLinkInYourEmail,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: Colors.grey[700],
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),

                      60.verticalSpace,

                      // Loading Indicator
                      SizedBox(
                        width: 40.spMin,
                        height: 40.spMin,
                        child: CircularProgressIndicator(
                          valueColor: AlwaysStoppedAnimation<Color>(
                            theme.primaryColor,
                          ),
                        ),
                      ),

                      16.verticalSpace,

                      // Waiting message
                      Text(
                        S.of(context).waitingForVerification,
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: Colors.grey[600],
                        ),
                        textAlign: TextAlign.center,
                      ),

                      60.verticalSpace,

                      // Resend Link
                      TextButton(
                        onPressed: canResend ? resendLink : null,
                        child: Text(
                          canResend
                              ? S.of(context).resendLink
                              : '${S.of(context).resendLink} ${formatTime(countdown)}',
                          style: TextStyle(
                            color: canResend ? theme.primaryColor : Colors.grey,
                            fontSize: 14.spMin,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              20.verticalSpace,
            ],
          ),
        ),
      ),
    );
  }

  String formatTime(int seconds) {
    final minutes = seconds ~/ 60;
    final secs = seconds % 60;
    return '${minutes.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
  }
}
