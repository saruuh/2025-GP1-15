import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:labbaik/core/utilities/extensions.dart';

import '../../../../core/utilities/app_validators.dart';
import '../../../../core/utilities/color_util.dart';
import '../../../../core/widgets/app_text_field.dart';
import '../../../../core/widgets/k_app_header.dart';
import '../../../../core/widgets/custom_transition_page.dart'
    show CustomTransitionPageBuilder;
import '../../../../generated/l10n.dart';
import 'verify_email.dart';

class ForgotPasswordScreen extends StatefulWidget {
  static const String routeName = 'forgot-password';
  static const String path = '/forgot-password';

  static CustomTransitionPageBuilder page(
    BuildContext context,
    GoRouterState state,
  ) => CustomTransitionPageBuilder(
    key: state.pageKey,
    page: const ForgotPasswordScreen(),
    name: routeName,
  );

  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final FocusNode emailFocusNode = FocusNode();
  final formKey = GlobalKey<FormState>();
  final TextEditingController emailController = TextEditingController();
  bool isSubmitting = false;

  @override
  void dispose() {
    emailController.dispose();
    emailFocusNode.dispose();
    super.dispose();
  }

  Future<void> _handleResetPassword() async {
    if (formKey.currentState!.validate()) {
      setState(() {
        isSubmitting = true;
      });

      await Future.delayed(const Duration(seconds: 2));

      setState(() {
        isSubmitting = false;
      });

      // Show success message
      if (mounted) {
        // Navigate to verify email screen
        if (mounted) {
          context.push(
            VerifyEmailScreen.path,
            extra: VerifyEmailScreen(
              email: emailController.text,
              isSignup: false,
            ),
          );
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8).r,
        child: Form(
          key: formKey,
          child: SafeArea(
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                spacing: 16,
                children: [
                  KAppHeader(showBackButton: true),
                  40.verticalSpace,
                  // Title
                  Text(
                    S.of(context).forgotPassword,
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: context.isDarkTheme ? Colors.white : Colors.black,
                    ),
                    textAlign: TextAlign.start,
                  ),
                  // Description
                  Text(
                    S
                        .of(context)
                        .donTworryItHappensPleaseEnterTheEmailAssociatedWithYourAccount,
                    style: Theme.of(context).textTheme.bodySmall,
                    textAlign: TextAlign.start,
                  ),
                  35.verticalSpace,
                  Column(
                    spacing: 20,
                    children: [
                      AppTextField.transparentWithBorder(
                        labelText: S.of(context).email,
                        focusNode: emailFocusNode,
                        textEditingController: emailController,
                        hintText: S.of(context).email,
                        validator: AppValidator.validateEmail,
                        keyBoardType: TextInputType.emailAddress,
                      ),
                      40.verticalSpace,
                      // Submit Button
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                            child: ElevatedButton(
                              onPressed: isSubmitting
                                  ? null
                                  : _handleResetPassword,
                              style: ElevatedButton.styleFrom(
                                padding: EdgeInsets.symmetric(vertical: 16).r,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12).r,
                                ),
                              ),
                              child: isSubmitting
                                  ? SizedBox(
                                      height: 20,
                                      width: 20,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(
                                              Colors.white,
                                            ),
                                      ),
                                    )
                                  : Text(
                                      S.of(context).sendCode,
                                      style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),

                  // Back to Login
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        S.of(context).rememberPasswordQuestion,
                        style: Theme.of(
                          context,
                        ).textTheme.bodySmall?.copyWith(color: ColorUtil.black),
                      ),
                      TextButton(
                        onPressed: () => context.pop(),
                        child: Text(
                          S.of(context).login,
                          style: Theme.of(context).textTheme.bodySmall
                              ?.copyWith(fontWeight: FontWeight.bold),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
