import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:equatable/equatable.dart';
import 'package:labbaik/core/utilities/safe_type_casting.dart';

class UserModel extends Equatable {
  final String id;
  final String name;
  final String email;
  final String phone;
  final String firstName;
  final String lastName;
  final String? profilePicture;
  final String countryCode;
  final String dateOfBirth;
  final bool emailVerified;
  final DateTime createdAt;
  final DateTime? updatedAt;

  const UserModel({
    required this.id,
    required this.name,
    required this.firstName,
    required this.lastName,
    required this.email,
    required this.phone,
    required this.countryCode,
    required this.dateOfBirth,
    required this.emailVerified,
    required this.createdAt,
    this.updatedAt,
    this.profilePicture,
  });

  UserModel copyWith({
    String? id,
    String? name,
    String? email,
    String? phone,
    String? firstName,
    String? lastName,
    String? profilePicture,
    String? countryCode,
    String? dateOfBirth,
    bool? emailVerified,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    return UserModel(
      id: id ?? this.id,
      name: name ?? this.name,
      firstName: firstName ?? this.firstName,
      lastName: lastName ?? this.lastName,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      profilePicture: profilePicture ?? this.profilePicture,
      countryCode: countryCode ?? this.countryCode,
      dateOfBirth: dateOfBirth ?? this.dateOfBirth,
      emailVerified: emailVerified ?? this.emailVerified,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'firstName': firstName,
      'lastName': lastName,
      'email': email,
      'phone': phone,
      'profilePicture': profilePicture,
      'countryCode': countryCode,
      'dateOfBirth': dateOfBirth,
      'emailVerified': emailVerified,
      'createdAt': createdAt,
      'updatedAt': updatedAt,
    };
  }

  factory UserModel.fromJson(Map<String, dynamic> json) {
    // Safely extract firstName and lastName for name construction
    final firstName = SafeTypeCasting.safeString(json['firstName']) ?? '';
    final lastName = SafeTypeCasting.safeString(json['lastName']) ?? '';

    return UserModel(
      id: SafeTypeCasting.safeString(json['id']) ?? '',
      name:
          SafeTypeCasting.safeString(json['name']) ??
          (firstName.isNotEmpty && lastName.isNotEmpty
              ? '$firstName $lastName'
              : ''),
      firstName: firstName,
      lastName: lastName,
      email: SafeTypeCasting.safeString(json['email']) ?? '',
      phone: SafeTypeCasting.safeString(json['phone']) ?? '',
      profilePicture: SafeTypeCasting.safeString(json['profilePicture']),
      countryCode: SafeTypeCasting.safeString(json['countryCode']) ?? '',
      dateOfBirth: SafeTypeCasting.safeString(json['dateOfBirth']) ?? '',
      emailVerified: SafeTypeCasting.safeBool(json['emailVerified']) ?? false,
      createdAt: _safeDateTime(json['createdAt']) ?? DateTime.now(),
      updatedAt: _safeDateTime(json['updatedAt']),
    );
  }

  /// Safely converts various date formats to DateTime
  /// Handles: Timestamp (Firestore), DateTime, String (ISO), int/double (epoch)
  static DateTime? _safeDateTime(dynamic value) {
    if (value == null) return null;

    // Handle Firestore Timestamp
    if (value is Timestamp) {
      return value.toDate();
    }

    // Handle DateTime
    if (value is DateTime) {
      return value;
    }

    // Handle String (ISO format)
    if (value is String) {
      try {
        return DateTime.parse(value);
      } catch (e) {
        return null;
      }
    }

    // Handle int/double (epoch timestamp - could be seconds or milliseconds)
    if (value is int) {
      // If timestamp is in milliseconds (13 digits), convert to seconds
      if (value > 1000000000000) {
        return DateTime.fromMillisecondsSinceEpoch(value);
      }
      return DateTime.fromMillisecondsSinceEpoch(value * 1000);
    }

    if (value is double) {
      final milliseconds = value.toInt();
      if (milliseconds > 1000000000000) {
        return DateTime.fromMillisecondsSinceEpoch(milliseconds);
      }
      return DateTime.fromMillisecondsSinceEpoch((milliseconds * 1000).toInt());
    }

    return null;
  }

  @override
  String toString() {
    return 'UserModel(id: $id, name: $name, email: $email, phone: $phone, profilePicture: $profilePicture, countryCode: $countryCode)';
  }

  @override
  List<Object?> get props => [
    id,
    name,
    email,
    phone,
    firstName,
    lastName,
    profilePicture,
    countryCode,
    dateOfBirth,
    emailVerified,
    createdAt,
    updatedAt,
  ];
}
