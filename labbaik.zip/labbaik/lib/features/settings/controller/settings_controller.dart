import 'package:flutter/foundation.dart';
import 'package:labbaik/core/services/locale_service.dart';

class SettingsController extends ChangeNotifier {
  SettingsController();

  final LocaleService _localeService = LocaleService.instance;

  bool get isArabic => _localeService.isArabic;

  Future<void> toggleLanguage(bool isArabic) async {
    await _localeService.toggleLanguage(isArabic);
    notifyListeners();
  }
}
