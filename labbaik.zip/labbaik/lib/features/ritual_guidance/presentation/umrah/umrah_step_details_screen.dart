import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:labbaik/core/models/ritual_guidance.dart';
import 'package:provider/provider.dart';
import 'package:labbaik/core/widgets/confirmation_dialog.dart';
import 'package:labbaik/core/widgets/custom_transition_page.dart'
    show CustomTransitionPageBuilder;

import '../../providers/umrah_progress_provider.dart'
    show UmrahProgressProvider;
import 'package:labbaik/core/widgets/ritual_progress_stepper.dart';
import '../widgets/umrah_widgets/widgets.dart';

class UmrahStepDetailsScreen extends StatefulWidget {
  static const String routeName = 'umrah_step_details';
  static const String path = '/umrah_step_details';

  final RitualGuidance ritualStep;
  final UmrahProgressProvider progressProvider;

  const UmrahStepDetailsScreen({
    super.key,
    required this.ritualStep,
    required this.progressProvider,
  });

  static CustomTransitionPageBuilder page(
    BuildContext context,
    GoRouterState state,
  ) {
    final screen = state.extra as Map<String, dynamic>;
    final ritualStep = screen['ritualStep'] as RitualGuidance;
    final progressProvider =
        screen['progressProvider'] as UmrahProgressProvider;
    return CustomTransitionPageBuilder(
      key: state.pageKey,
      page: UmrahStepDetailsScreen(
        ritualStep: ritualStep,
        progressProvider: progressProvider,
      ),
      name: routeName,
    );
  }

  static void push({
    required BuildContext context,
    required RitualGuidance ritualStep,
    // i will pass provider to this page
    required UmrahProgressProvider progressProvider,
  }) => context.push(
    path,
    extra: {'ritualStep': ritualStep, 'progressProvider': progressProvider},
  );

  @override
  State<UmrahStepDetailsScreen> createState() => _UmrahStepDetailsScreenState();
}

class _UmrahStepDetailsScreenState extends State<UmrahStepDetailsScreen> {
  late RitualGuidance ritualStep;
  late UmrahProgressProvider progressProvider;

  @override
  void initState() {
    super.initState();
    ritualStep = widget.ritualStep;
    progressProvider = widget.progressProvider;
  }

  Future<bool> _onWillPop() async {
    // Check if step is already completed
    if (progressProvider.isStepCompleted(ritualStep.stepNumber)) {
      return true; // Allow pop if already completed
    }

    if (!progressProvider.showCompletionDialog) {
      return true;
    }

    // Show confirmation dialog (handles progress update internally)
    await ConfirmationDialog.showStepCompletionDialog(
      context: context,
      stepName: ritualStep.title,
      stepNumber: ritualStep.stepNumber,
      progressProvider: progressProvider,
    );

    // Allow pop (dialog handles progress update)
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: progressProvider,
      child: Consumer<UmrahProgressProvider>(
        builder: (context, progressProvider, child) {
          final currentStep = progressProvider.allSteps.firstWhere(
            (step) => step.stepNumber == ritualStep.stepNumber,
          );

          return PopScope(
            canPop: false,
            onPopInvokedWithResult: (bool didPop, dynamic result) async {
              if (!didPop) {
                final shouldPop = await _onWillPop();
                if (shouldPop && mounted) {
                  context.pop();
                }
              }
            },
            child: Scaffold(
              backgroundColor: Theme.of(context).scaffoldBackgroundColor,
              body: SafeArea(
                top: false,
                child: Column(
                  children: [
                    // Enhanced Header
                    UmrahStepHeader(
                      stepNumber: ritualStep.stepNumber,
                      stepTitle: currentStep.title,
                      stepIcon: currentStep.icon,
                      onBackPressedAsync: _onWillPop,
                      isCompleted: progressProvider.isStepCompleted(
                        ritualStep.stepNumber,
                      ),
                      onToggleCompletion: (value) {
                        if (value) {
                          progressProvider.markStepCompleted(
                            ritualStep.stepNumber,
                          );
                        }
                      },
                    ),
                    // Progress Stepper
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 16).r,
                      child: RitualProgressStepper(
                        steps: progressProvider.allSteps,
                        currentStepNumber: ritualStep.stepNumber,
                        progress: progressProvider.completedSteps,
                      ),
                    ),
                    // Content
                    Expanded(
                      child: SingleChildScrollView(
                        padding: EdgeInsets.symmetric(horizontal: 16).r,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            20.verticalSpace,
                            UmrahStepDescriptionCard(
                              description: currentStep.description,
                            ),
                            30.verticalSpace,
                            _buildStepDetails(
                              context,
                              currentStep,
                              progressProvider.completedSteps,
                            ),
                            40.verticalSpace,
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildStepDetails(
    BuildContext context,
    RitualGuidance step,
    Map<int, bool> progress,
  ) {
    final steps = getUmrahGuidance(
      context,
      progress: progress,
    ).firstWhere((element) => element.stepNumber == step.stepNumber);

    return UmrahStepDetailsList(step: steps);
  }
}
