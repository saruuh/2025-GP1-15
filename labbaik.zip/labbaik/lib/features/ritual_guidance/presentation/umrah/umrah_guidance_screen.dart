import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:labbaik/core/models/ritual_guidance.dart';
import 'package:labbaik/core/widgets/global_scaffold.dart';
import 'package:labbaik/core/widgets/reset_button.dart';
import 'package:provider/provider.dart';
import 'package:labbaik/core/widgets/k_app_header.dart';
import 'package:labbaik/core/widgets/loading_indicator.dart';
import 'package:labbaik/core/widgets/custom_transition_page.dart'
    show CustomTransitionPageBuilder;
import 'package:labbaik/generated/l10n.dart';

import '../../providers/umrah_progress_provider.dart'
    show UmrahProgressProvider;
import '../widgets/umrah_widgets/step_timeline_item.dart' show StepTimelineItem;
import '../widgets/umrah_widgets/widgets.dart' show StepProgressIndicator;
import 'umrah_step_details_screen.dart' show UmrahStepDetailsScreen;

class UmrahGuidanceScreen extends StatelessWidget {
  static const String routeName = 'umrah_guidance';
  static const String path = '/umrah_guidance';

  static CustomTransitionPageBuilder page(
    BuildContext context,
    GoRouterState state,
  ) => CustomTransitionPageBuilder(
    key: state.pageKey,
    page: const UmrahGuidanceScreen(),
    name: routeName,
  );

  const UmrahGuidanceScreen({super.key});

  static void push({required BuildContext context}) => context.push(path);

  @override
  Widget build(BuildContext context) {
    return GlobalScaffold<UmrahProgressProvider>(
      withBackButton: true,
      bottomNavBarIndex: 1,
      create: (context) => UmrahProgressProvider(),
      child: Consumer<UmrahProgressProvider>(
        builder: (context, progressProvider, child) {
          return SafeArea(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 16).r,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  KAppHeader(showBackButton: false, showTrailing: false),
                  10.verticalSpace,
                  Row(
                    spacing: 16.spMin,
                    children: [
                      Text(
                        S.of(context).umrahGuidance,
                        style: Theme.of(context).textTheme.headlineMedium
                            ?.copyWith(fontWeight: FontWeight.bold),
                      ),
                      ResetButton(
                        onTap: () {
                          progressProvider.reset();
                        },
                      ),
                    ],
                  ),
                  if (progressProvider.isLoading)
                    LoadingIndicator()
                  else ...[
                    20.verticalSpace,
                    StepProgressIndicator(
                      completedSteps: progressProvider.completedStepsCount,
                      totalSteps: getUmrahGuidance(context).length,
                    ),
                    30.verticalSpace,
                    ...getUmrahGuidance(context).asMap().entries.map((entry) {
                      final index = entry.key;
                      final step = entry.value;
                      final isLast =
                          index == getUmrahGuidance(context).length - 1;

                      return StepTimelineItem(
                        step: step,
                        isLast: isLast,
                        index: index,
                        isCompleted: progressProvider.isStepCompleted(
                          step.stepNumber,
                        ),
                        isActive:
                            step.stepNumber ==
                            (progressProvider.activeStepNumber + 1),
                        onTap: () {
                          UmrahStepDetailsScreen.push(
                            context: context,
                            ritualStep: step,
                            progressProvider: progressProvider,
                          );
                        },
                      );
                    }),
                    40.verticalSpace,
                  ],
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
