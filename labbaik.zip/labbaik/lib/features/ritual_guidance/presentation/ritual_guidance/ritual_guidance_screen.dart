import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:labbaik/core/utilities/path_util.dart';
import 'package:labbaik/core/widgets/app_card.dart';
import 'package:labbaik/generated/l10n.dart';

import '../hijj/hijj_guidance_screen.dart' show HijjGuidanceScreen;
import '../umrah/umrah_guidance_screen.dart' show UmrahGuidanceScreen;

class RitualGuidanceScreen extends StatelessWidget {
  static const String routeName = 'ritual_guidance_screen';
  static const String path = '/ritual_guidance_screen';
  const RitualGuidanceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 16).r,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            spacing: 16,
            children: [
              GestureDetector(
                onTap: () {
                  HijjGuidanceScreen.push(context: context);
                },
                child: AppCard(title: S.of(context).hajj, icon: PathUtil.hajj),
              ),
              GestureDetector(
                onTap: () {
                  UmrahGuidanceScreen.push(context: context);
                },
                child: AppCard(
                  title: S.of(context).umrah,
                  icon: PathUtil.umrah,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
