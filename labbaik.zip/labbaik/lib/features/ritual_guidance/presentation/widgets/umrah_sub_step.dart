import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:labbaik/core/utilities/extensions.dart';
import 'package:labbaik/core/widgets/k_app_header.dart';
import 'package:labbaik/core/widgets/rich_text_parser.dart';
import 'package:labbaik/core/widgets/custom_transition_page.dart'
    show CustomTransitionPageBuilder;

import '../../../../core/models/ritual_guidance_sub_step.dart'
    show RitualGuidanceSubStep;
import '../../../../core/utilities/color_util.dart';

class UmrahSubStep extends StatelessWidget {
  static const String routeName = 'umrah_sub_step';
  static const String path = '/umrah_sub_step';

  final RitualGuidanceSubStep subStep;

  const UmrahSubStep({super.key, required this.subStep});

  static CustomTransitionPageBuilder page(
    BuildContext context,
    GoRouterState state,
  ) {
    final subStep = state.extra as RitualGuidanceSubStep;
    return CustomTransitionPageBuilder(
      key: state.pageKey,
      page: UmrahSubStep(subStep: subStep),
      name: routeName,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 16).r,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              KAppHeader(),
              10.verticalSpace,
              RichTextParser(
                text: subStep.title,
                defaultStyle: Theme.of(context).textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),
              if (subStep.description != null) ...[
                20.verticalSpace,

                Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(12).r,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(10).r,
                  ),
                  child: RichTextParser(text: subStep.description ?? ''),
                ),
              ],

              // grid view of images
              if (subStep.images.isNotEmpty) ...[
                20.verticalSpace,
                GridView.builder(
                  padding: EdgeInsets.zero,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                  ),
                  itemCount: subStep.images.length,
                  itemBuilder: (context, index) =>
                      Image.asset(subStep.images[index]),
                ),
              ],

              if (subStep.steps.isNotEmpty) ...[
                20.verticalSpace,
                ListView.separated(
                  separatorBuilder: (context, index) => 10.verticalSpace,
                  padding: EdgeInsets.zero,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: subStep.steps.length,
                  itemBuilder: (context, index) => Stack(
                    children: [
                      Container(
                        alignment: context.isArabic
                            ? Alignment.centerRight
                            : Alignment.centerLeft,
                        padding: EdgeInsets.all(12).r,
                        margin: EdgeInsets.only(
                          left: context.isArabic ? 0 : 20,
                          right: context.isArabic ? 20 : 0,
                        ).r,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10).r,
                        ),
                        child: RichTextParser(text: subStep.steps[index]),
                      ),

                      Positioned(
                        top: 0,
                        left: context.isArabic ? null : 0,
                        right: context.isArabic ? 0 : null,
                        bottom: 0,
                        child: Container(
                          padding: EdgeInsets.all(8).r,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: ColorUtil.primaryColor,
                          ),
                          child: Text(
                            "${index + 1}",
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
