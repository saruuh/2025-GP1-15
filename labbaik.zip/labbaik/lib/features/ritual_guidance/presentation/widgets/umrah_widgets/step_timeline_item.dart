import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:labbaik/features/ritual_guidance/presentation/widgets/umrah_widgets/step_card.dart';
import 'package:labbaik/features/ritual_guidance/presentation/widgets/umrah_widgets/step_timeline_indicator.dart';
import 'package:labbaik/features/ritual_guidance/presentation/widgets/umrah_widgets/step_timeline_line.dart';

import '../../../../../core/models/ritual_guidance.dart' show RitualGuidance;

/// A reusable timeline item widget that combines the indicator, line, and card
/// for a complete step display in a timeline.
class StepTimelineItem extends StatelessWidget {
  final RitualGuidance step;
  final bool isLast;
  final int index;
  final bool isCompleted;
  final bool isActive;
  final VoidCallback onTap;
  const StepTimelineItem({
    super.key,
    required this.step,
    required this.isLast,
    required this.index,
    required this.isCompleted,
    required this.isActive,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: 20).r,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Timeline Indicator
          Column(
            children: [
              StepTimelineIndicator(
                isCompleted: isCompleted,
                isActive: isActive,
              ),
              if (!isLast)
                StepTimelineLine(
                  status: step.status,
                  index: index,
                  isCompleted: isCompleted,
                  isActive: isActive,
                ),
            ],
          ),
          16.horizontalSpace,
          // Step Card
          Expanded(
            child: AnimatedContainer(
              duration: Duration(milliseconds: 300 + (index * 100)),
              curve: Curves.easeOutBack,
              child: StepCard(step: step, onTap: onTap),
            ),
          ),
        ],
      ),
    );
  }
}
