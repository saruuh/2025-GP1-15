import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:labbaik/core/utilities/color_util.dart';
import 'package:labbaik/core/utilities/extensions.dart';
import 'package:labbaik/core/widgets/rich_text_parser.dart';

/// A reusable card widget for displaying step description
class UmrahStepDescriptionCard extends StatelessWidget {
  final String description;

  const UmrahStepDescriptionCard({super.key, required this.description});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(20).r,
      decoration: BoxDecoration(
        color: context.isDarkTheme ? ColorUtil.black : ColorUtil.white,
        borderRadius: BorderRadius.circular(20).r,
        border: Border.all(
          color: context.isDarkTheme
              ? ColorUtil.black.withValues(alpha: 0.1)
              : ColorUtil.accentColor.withValues(alpha: 0.1),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: RichTextParser(
        text: description,
        defaultStyle: TextStyle(
          fontSize: 16.sp,
          color: ColorUtil.blueGreyColor,
          height: 1.6,
        ),
      ),
    );
  }
}
