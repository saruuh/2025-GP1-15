import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:labbaik/core/utilities/color_util.dart';
import 'package:labbaik/generated/l10n.dart';

/// A reusable progress indicator widget that displays completion progress
/// for a series of steps.
class StepProgressIndicator extends StatelessWidget {
  final int completedSteps;
  final int totalSteps;

  const StepProgressIndicator({
    super.key,
    required this.completedSteps,
    required this.totalSteps,
  });

  @override
  Widget build(BuildContext context) {
    final progress = totalSteps > 0 ? completedSteps / totalSteps : 0.0;

    return Container(
      padding: EdgeInsets.all(16).r,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            ColorUtil.accentColor.withValues(alpha: 0.1),
            ColorUtil.primaryColor.withValues(alpha: 0.05),
          ],
        ),
        borderRadius: BorderRadius.circular(16).r,
        border: Border.all(
          color: ColorUtil.accentColor.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                S.of(context).progress,
                style: TextStyle(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.w600,
                  color: ColorUtil.darkGrey,
                ),
              ),
              Text(
                S.of(context).progressDescription(
                  completedSteps,
                  totalSteps,
                  totalSteps == 1 ? 1 : totalSteps,
                ),
                style: TextStyle(
                  fontSize: 14.sp,
                  fontWeight: FontWeight.w500,
                  color: ColorUtil.accentColor,
                ),
              ),
            ],
          ),
          12.verticalSpace,
          Stack(
            children: [
              Container(
                height: 8.r,
                decoration: BoxDecoration(
                  color: ColorUtil.accentColor.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(4).r,
                ),
              ),
              AnimatedContainer(
                duration: const Duration(milliseconds: 800),
                curve: Curves.easeInOut,
                height: 8.r,
                width: MediaQuery.of(context).size.width * 0.8 * progress,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      ColorUtil.accentColor,
                      ColorUtil.accentColor.withValues(alpha: 0.8),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(4).r,
                  boxShadow: [
                    BoxShadow(
                      color: ColorUtil.accentColor.withValues(alpha: 0.3),
                      blurRadius: 4,
                      offset: const Offset(0, 1),
                    ),
                  ],
                ),
              ),
            ],
          ),
          8.verticalSpace,
          Text(
            '${(progress * 100).toInt()}% ${S.of(context).complete}',
            style: TextStyle(
              fontSize: 12.sp,
              color: ColorUtil.blueGreyColor,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}




