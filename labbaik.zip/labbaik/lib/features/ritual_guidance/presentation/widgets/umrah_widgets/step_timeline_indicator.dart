import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:labbaik/core/utilities/color_util.dart';

/// A reusable timeline indicator widget that displays the status of a step
/// in a timeline view.
class StepTimelineIndicator extends StatelessWidget {
  final bool isCompleted;
  final bool isActive;
  const StepTimelineIndicator({
    super.key,
    required this.isCompleted,
    required this.isActive,
  });

  @override
  Widget build(BuildContext context) {
    if (isCompleted) {
      return Container(
        width: 28.r,
        height: 28.r,
        decoration: BoxDecoration(
          color: ColorUtil.accentColor,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: ColorUtil.accentColor.withValues(alpha: 0.3),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Icon(Icons.check_rounded, size: 16.spMin, color: Colors.white),
      );
    } else if (isActive) {
      return Container(
        width: 28.r,
        height: 28.r,
        decoration: BoxDecoration(
          color: ColorUtil.accentColor,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: ColorUtil.accentColor.withValues(alpha: 0.4),
              blurRadius: 12,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Container(
          width: 12.r,
          height: 12.r,
          decoration: const BoxDecoration(
            color: Colors.white,
            shape: BoxShape.circle,
          ),
        ),
      );
    } else {
      return Container(
        width: 28.r,
        height: 28.r,
        decoration: BoxDecoration(
          color: ColorUtil.accentColor,
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: ColorUtil.accentColor.withValues(alpha: 0.3),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
      );
    }
  }
}
