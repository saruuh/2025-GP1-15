import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:labbaik/core/models/ritual_guidance.dart' show RitualGuidance;

import '../../../../../core/widgets/app_card.dart' show AppCard;

/// A reusable step card widget that displays step information and handles navigation.
class StepCard extends StatelessWidget {
  final RitualGuidance step;
  final VoidCallback onTap;

  const StepCard({super.key, required this.step, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20).r,
      child: AppCard(
        title: step.title,
        stepNumber: step.stepNumber,
        stepTitle: step.stepTitle,
        icon: step.icon,
      ),
    );
  }
}
