import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:labbaik/core/utilities/color_util.dart';
import 'package:labbaik/core/models/ritual_guidance.dart'
    show RitualGuidanceStatus;

/// A reusable timeline line widget that connects steps in a timeline view.
class StepTimelineLine extends StatelessWidget {
  final RitualGuidanceStatus status;
  final int index;
  final bool isCompleted;
  final bool isActive;

  const StepTimelineLine({
    super.key,
    required this.status,
    required this.index,
    required this.isCompleted,
    required this.isActive,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: Duration(milliseconds: 500 + (index * 100)),
      width: 3,
      height: 90.r,
      margin: EdgeInsets.symmetric(vertical: 4.r),
      decoration: BoxDecoration(
        gradient: isCompleted || isActive
            ? LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  ColorUtil.accentColor,
                  ColorUtil.accentColor.withValues(alpha: 0.6),
                ],
              )
            : LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  ColorUtil.accentColor.withValues(alpha: 0.3),
                  ColorUtil.accentColor.withValues(alpha: 0.1),
                ],
              ),
        borderRadius: BorderRadius.circular(2),
        boxShadow: (isCompleted || isActive)
            ? [
                BoxShadow(
                  color: ColorUtil.accentColor.withValues(alpha: 0.2),
                  blurRadius: 4,
                  offset: const Offset(0, 1),
                ),
              ]
            : null,
      ),
    );
  }
}
