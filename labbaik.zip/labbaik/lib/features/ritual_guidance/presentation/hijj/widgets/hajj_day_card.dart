import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:labbaik/core/models/ritual_guidance.dart';
import 'package:labbaik/core/utilities/color_util.dart';
import 'package:labbaik/core/utilities/extensions.dart';
import 'package:labbaik/core/widgets/rich_text_parser.dart';
import 'hajj_step_card.dart';

class HajjDayCard extends StatelessWidget {
  final RitualGuidance dayStep;
  final Function(RitualGuidance) onStepTap;
  final bool showSteps;
  final bool isExpanded;
  final VoidCallback? onToggleExpanded;
  final bool hasNestedSteps;

  const HajjDayCard({
    super.key,
    required this.dayStep,
    required this.onStepTap,
    this.showSteps = true,
    this.isExpanded = false,
    this.onToggleExpanded,
    this.hasNestedSteps = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(20).r,
      decoration: BoxDecoration(
        color: context.isDarkTheme ? ColorUtil.black : ColorUtil.white,
        borderRadius: BorderRadius.circular(20).r,
        border: Border.all(
          color: context.isDarkTheme
              ? ColorUtil.black.withValues(alpha: 0.1)
              : ColorUtil.accentColor.withValues(alpha: 0.1),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: context.isDarkTheme
                ? Colors.black.withValues(alpha: 0.08)
                : ColorUtil.black.withValues(alpha: 0.08),
            blurRadius: 12,
            offset: const Offset(0, 6),
            spreadRadius: 0,
          ),
          BoxShadow(
            color: context.isDarkTheme
                ? ColorUtil.black.withValues(alpha: 0.05)
                : ColorUtil.accentColor.withValues(alpha: 0.05),
            blurRadius: 20,
            offset: const Offset(0, 2),
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with expand button
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (dayStep.stepTitle != null)
                      Text(
                        dayStep.stepTitle!,
                        style: TextStyle(
                          color: ColorUtil.lightGrey,
                          fontSize: 14.sp,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    4.verticalSpace,
                    if (dayStep.title.isNotEmpty)
                      Text(
                        dayStep.title,
                        style: TextStyle(
                          color: context.isDarkTheme
                              ? Colors.white
                              : Colors.black,
                          fontSize: 18.sp,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                  ],
                ),
              ),
              if (hasNestedSteps || dayStep.description.isNotEmpty)
                IconButton(
                  onPressed: onToggleExpanded,
                  icon: Icon(
                    isExpanded
                        ? Icons.keyboard_arrow_up_rounded
                        : Icons.keyboard_arrow_down_rounded,
                    color: ColorUtil.primaryColor,
                  ),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
            ],
          ),

          // Description
          if (dayStep.description.isNotEmpty && isExpanded) ...[
            12.verticalSpace,
            RichTextParser(
              text: dayStep.description,
              defaultStyle: TextStyle(
                color: context.isDarkTheme
                    ? Colors.white.withValues(alpha: 0.8)
                    : ColorUtil.blueGreyColor,
                fontSize: 16.sp,
                height: 1.6,
              ),
            ),
          ],

          // Steps (only shown when showSteps is true, not used in timeline)
          if (showSteps && dayStep.nestedSteps != null) ...[
            16.verticalSpace,
            ...dayStep.nestedSteps!.map(
              (step) => HajjStepCard(step: step, onTap: () => onStepTap(step)),
            ),
          ],
        ],
      ),
    );
  }
}
