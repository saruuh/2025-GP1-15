import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:labbaik/core/models/ritual_guidance_sub_step.dart';
import 'package:labbaik/core/utilities/color_util.dart';
import 'package:labbaik/core/utilities/extensions.dart';
import 'package:labbaik/core/widgets/rich_text_parser.dart';

class HijjTypeCard extends StatelessWidget {
  final RitualGuidanceSubStep step;

  const HijjTypeCard({super.key, required this.step});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 16.h),
      decoration: BoxDecoration(
        color: context.isDarkTheme ? Colors.black : Colors.white,
        borderRadius: BorderRadius.circular(16).r,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          tilePadding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 8.h),
          childrenPadding: EdgeInsets.fromLTRB(20.w, 0, 20.w, 20.h),
          title: Text(
            step.title,
            style: TextStyle(
              fontSize: 18.sp,
              fontWeight: FontWeight.w600,
              color: context.isDarkTheme ? Colors.white : ColorUtil.darkGrey,
            ),
          ),
          trailing: Icon(
            Icons.keyboard_arrow_down_rounded,
            color: context.isDarkTheme ? Colors.white : ColorUtil.darkGrey,
            size: 24.sp,
          ),
          children: [
            if (step.description != null)
              RichTextParser(
                text: step.description!,
                defaultStyle: TextStyle(
                  fontSize: 14.sp,
                  color: context.isDarkTheme
                      ? Colors.white.withValues(alpha: 0.8)
                      : ColorUtil.darkGrey.withValues(alpha: 0.8),
                  height: 1.5,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
