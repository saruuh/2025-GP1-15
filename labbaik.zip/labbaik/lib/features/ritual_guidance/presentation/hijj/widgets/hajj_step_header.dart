import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:labbaik/core/utilities/color_util.dart';
import 'package:labbaik/generated/l10n.dart';

class HajjStepHeader extends StatelessWidget {
  final int stepNumber;
  final String stepTitle;
  final String stepIcon;
  final String dayTitle;
  final VoidCallback? onBackPressed;
  final Future<bool> Function()? onBackPressedAsync;
  final bool isCompleted;
  final ValueChanged<bool>? onToggleCompletion;

  const HajjStepHeader({
    super.key,
    required this.stepNumber,
    required this.stepTitle,
    required this.stepIcon,
    required this.dayTitle,
    this.onBackPressed,
    this.onBackPressedAsync,
    this.isCompleted = false,
    this.onToggleCompletion,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top).r,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            ColorUtil.primaryColor,
            ColorUtil.primaryColor.withValues(alpha: 0.9),
            ColorUtil.primaryColor.withValues(alpha: 0.8),
            Theme.of(context).scaffoldBackgroundColor,
          ],
          stops: const [0.0, 0.7, 0.8, 1.0],
        ),
      ),
      child: Column(
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16).r,
            child: Column(
              children: [
                10.verticalSpace,
                Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        if (onBackPressedAsync != null) {
                          onBackPressedAsync!().then((shouldPop) {
                            if (shouldPop && context.mounted) {
                              context.pop();
                            }
                          });
                        } else if (onBackPressed != null) {
                          onBackPressed!();
                        } else {
                          if (context.mounted) {
                            context.pop();
                          }
                        }
                      },
                      child: Container(
                        padding: EdgeInsets.all(8).r,
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(12).r,
                          border: Border.all(
                            color: Colors.white.withValues(alpha: 0.3),
                            width: 1,
                          ),
                        ),
                        child: Icon(
                          Icons.arrow_back_ios_rounded,
                          color: Colors.white,
                          size: 20.spMin,
                        ),
                      ),
                    ),
                    Expanded(
                      child: Center(
                        child: Text(
                          dayTitle,
                          style: TextStyle(
                            fontSize: 20.sp,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),

                    // Placeholder to balance the back button
                  ],
                ),
                20.verticalSpace,
                Row(
                  children: [
                    Container(
                      width: 60.r,
                      height: 60.r,
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(16).r,
                        border: Border.all(
                          color: Colors.white.withValues(alpha: 0.3),
                          width: 2,
                        ),
                      ),
                      child: Image.asset(stepIcon),
                    ),
                    SizedBox(width: 16.w),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                padding: EdgeInsets.symmetric(
                                  horizontal: 10.r,
                                  vertical: 4.r,
                                ),
                                decoration: BoxDecoration(
                                  color: ColorUtil.accentColor.withValues(
                                    alpha: 0.9,
                                  ),
                                  borderRadius: BorderRadius.circular(16).r,
                                ),
                                child: Text(
                                  '${S.of(context).step} $stepNumber',
                                  style: TextStyle(
                                    fontSize: 12.sp,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ),
                              if (onToggleCompletion != null)
                                GestureDetector(
                                  onTap: () =>
                                      onToggleCompletion!(!isCompleted),
                                  child: Container(
                                    padding: EdgeInsets.all(8).r,
                                    decoration: BoxDecoration(
                                      color: Colors.white.withValues(
                                        alpha: 0.2,
                                      ),
                                      borderRadius: BorderRadius.circular(12).r,
                                      border: Border.all(
                                        color: Colors.white.withValues(
                                          alpha: 0.3,
                                        ),
                                        width: 1,
                                      ),
                                    ),
                                    child: Icon(
                                      isCompleted
                                          ? Icons.radio_button_checked
                                          : Icons.radio_button_off,
                                      color: Colors.white,
                                      size: 20.spMin,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                          8.verticalSpace,
                          Text(
                            stepTitle,
                            style: TextStyle(
                              fontSize: 24.sp,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                              height: 1.2,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                25.verticalSpace,
              ],
            ),
          ),
          20.verticalSpace,
        ],
      ),
    );
  }
}
