import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:labbaik/core/utilities/color_util.dart';
import 'package:labbaik/core/models/ritual_guidance.dart';
import 'package:labbaik/core/utilities/extensions.dart';
import 'package:labbaik/generated/l10n.dart';

class HajjStepCard extends StatelessWidget {
  final RitualGuidance step;
  final VoidCallback onTap;
  final RitualGuidanceStatus status;

  const HajjStepCard({
    super.key,
    required this.step,
    required this.onTap,
    this.status = RitualGuidanceStatus.pending,
  });

  @override
  Widget build(BuildContext context) {
    final isCompleted = status == RitualGuidanceStatus.completed;
    final isActive = status == RitualGuidanceStatus.active;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.only(bottom: 12.h),
        padding: EdgeInsets.all(16.r),
        decoration: BoxDecoration(
          color: context.isDarkTheme ? ColorUtil.black : Colors.white,
          borderRadius: BorderRadius.circular(12.r),
          border: isActive
              ? Border.all(color: ColorUtil.primaryColor, width: 2)
              : null,
          boxShadow: [
            BoxShadow(
              color: context.isDarkTheme
                  ? Colors.black.withValues(alpha: 0.08)
                  : ColorUtil.black.withValues(alpha: 0.08),
              blurRadius: 12,
              offset: const Offset(0, 6),
              spreadRadius: 0,
            ),
            BoxShadow(
              color: context.isDarkTheme
                  ? ColorUtil.black.withValues(alpha: 0.05)
                  : ColorUtil.accentColor.withValues(alpha: 0.05),
              blurRadius: 20,
              offset: const Offset(0, 2),
              spreadRadius: 2,
            ),
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${S.of(context).step} ${step.stepNumber}',
                    style: TextStyle(
                      color: isActive
                          ? ColorUtil.primaryColor
                          : ColorUtil.accentColor,
                      fontSize: 12.sp,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  4.verticalSpace,
                  Text(
                    step.title,
                    style: TextStyle(
                      color: ColorUtil.primaryColor,
                      fontSize: 16.sp,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: 48.r,
              height: 48.r,
              decoration: BoxDecoration(
                color: isCompleted
                    ? Colors.green
                    : isActive
                    ? ColorUtil.primaryColor
                    : ColorUtil.primaryColor.withValues(alpha: 0.5),
                shape: BoxShape.circle,
              ),
              child: Image.asset(step.icon, fit: BoxFit.cover),
            ),
            12.horizontalSpace,
            Icon(
              isCompleted
                  ? Icons.check_circle
                  : isActive
                  ? Icons.play_circle_fill
                  : Icons.arrow_forward_ios,
              size: isCompleted || isActive ? 24.sp : 16.sp,
              color: isCompleted
                  ? ColorUtil.accentColor
                  : isActive
                  ? ColorUtil.accentColor
                  : ColorUtil.primaryColor.withValues(alpha: 0.5),
            ),
          ],
        ),
      ),
    );
  }
}
