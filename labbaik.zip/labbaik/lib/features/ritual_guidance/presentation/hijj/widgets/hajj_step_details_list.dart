import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:labbaik/core/utilities/color_util.dart';
import 'package:labbaik/core/models/ritual_guidance.dart';
import 'package:labbaik/core/models/ritual_guidance_sub_step.dart';
import 'package:labbaik/features/ritual_guidance/presentation/widgets/umrah_sub_step.dart';
import 'package:labbaik/core/widgets/rich_text_parser.dart';
import 'package:labbaik/core/utilities/extensions.dart';

class HajjStepDetailsList extends StatelessWidget {
  final RitualGuidance step;

  const HajjStepDetailsList({super.key, required this.step});

  @override
  Widget build(BuildContext context) {
    if (step.subSteps == null || step.subSteps!.isEmpty) {
      return const SizedBox.shrink();
    }

    return ListView.builder(
      padding: EdgeInsets.zero,
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemCount: step.subSteps!.length,
      itemBuilder: (context, index) {
        final subStep = step.subSteps![index];
        if (subStep.isListTile) {
          return _buildButton(context, subStep);
        } else {
          return _buildNumberedItem(context, subStep, index + 1);
        }
      },
    );
  }

  Widget _buildButton(BuildContext context, RitualGuidanceSubStep subStep) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 16, horizontal: 16).r,
      margin: EdgeInsets.only(bottom: 8).r,
      decoration: BoxDecoration(
        color: ColorUtil.primaryColor,
        borderRadius: BorderRadius.circular(20).r,
        border: Border.all(
          color: ColorUtil.accentColor.withValues(alpha: 0.1),
          width: 1,
        ),
      ),
      child: InkWell(
        onTap: () {
          context.push(UmrahSubStep.path, extra: subStep);
        },
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Text(
                subStep.title,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  fontSize: 16.sp,
                ),
              ),
            ),
            Icon(
              Icons.arrow_forward_ios_rounded,
              size: 20.spMin,
              color: ColorUtil.accentColor,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNumberedItem(
    BuildContext context,
    RitualGuidanceSubStep subStep,
    int index,
  ) {
    return Container(
      margin: EdgeInsets.only(bottom: 16).r,
      child: Stack(
        children: [
          // Content Box
          Container(
            width: double.infinity,
            margin: EdgeInsets.only(
              left: context.isArabic ? 0 : 16,
              right: context.isArabic ? 16 : 0,
            ).r,
            padding: EdgeInsets.only(
              left: context.isArabic ? 20 : 50,
              right: context.isArabic ? 50 : 20,
              top: 20,
              bottom: 20,
            ).r,
            decoration: BoxDecoration(
              color: context.isDarkTheme ? ColorUtil.black : Colors.white,
              borderRadius: BorderRadius.circular(20).r,
            ),
            child: RichTextParser(
              text: subStep.title, // Using title as the content
              defaultStyle: TextStyle(
                fontWeight: FontWeight.normal,
                fontSize: 16.sp,
              ),
            ),
          ),
          // Number Circle
          Positioned(
            left: context.isArabic ? null : 0,
            right: context.isArabic ? 0 : null,
            top: 0,
            child: Container(
              alignment: Alignment.center,
              padding: EdgeInsets.all(14).r,
              decoration: BoxDecoration(
                color: ColorUtil.primaryColor,
                shape: BoxShape.circle,
              ),
              child: Text(
                '$index',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  fontSize: 16.sp,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
