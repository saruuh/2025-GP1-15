import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:labbaik/core/models/ritual_guidance.dart';
import 'package:labbaik/features/ritual_guidance/presentation/widgets/umrah_widgets/step_timeline_indicator.dart';
import 'hajj_day_card.dart';
import 'package:labbaik/core/utilities/color_util.dart';
import 'hajj_step_card.dart';
import 'package:provider/provider.dart';
import 'package:labbaik/features/ritual_guidance/providers/hijj_provider.dart';

class HajjTimelineItem extends StatefulWidget {
  final RitualGuidance dayStep;
  final bool isLast;
  final bool isCompleted;
  final bool isActive;
  final Function(RitualGuidance) onStepTap;

  const HajjTimelineItem({
    super.key,
    required this.dayStep,
    required this.isLast,
    required this.isCompleted,
    required this.isActive,
    required this.onStepTap,
  });

  @override
  State<HajjTimelineItem> createState() => _HajjTimelineItemState();
}

class _HajjTimelineItemState extends State<HajjTimelineItem> {
  bool _isExpanded = false;

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<HijjProvider>();
    final hasNestedSteps =
        widget.dayStep.nestedSteps != null &&
        widget.dayStep.nestedSteps!.isNotEmpty;

    return Column(
      children: [
        Padding(
          padding: EdgeInsets.only(bottom: 20.r),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Column(
                children: [
                  StepTimelineIndicator(
                    isCompleted: widget.isCompleted,
                    isActive: widget.isActive,
                  ),
                  if (!widget.isLast || hasNestedSteps)
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 500),
                      width: 3,
                      height: 90.r,
                      margin: EdgeInsets.symmetric(vertical: 4.r),
                      decoration: BoxDecoration(
                        gradient: widget.isCompleted || widget.isActive
                            ? LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                  ColorUtil.accentColor,
                                  ColorUtil.accentColor.withValues(alpha: 0.6),
                                ],
                              )
                            : LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [
                                  ColorUtil.accentColor.withValues(alpha: 0.3),
                                  ColorUtil.accentColor.withValues(alpha: 0.1),
                                ],
                              ),
                        borderRadius: BorderRadius.circular(2),
                        boxShadow: (widget.isCompleted || widget.isActive)
                            ? [
                                BoxShadow(
                                  color: ColorUtil.accentColor.withValues(
                                    alpha: 0.2,
                                  ),
                                  blurRadius: 4,
                                  offset: const Offset(0, 1),
                                ),
                              ]
                            : null,
                      ),
                    ),
                ],
              ),
              16.horizontalSpace,
              Expanded(
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  curve: Curves.easeOutBack,
                  child: HajjDayCard(
                    dayStep: widget.dayStep,
                    onStepTap: widget.onStepTap,
                    showSteps: false,
                    isExpanded: _isExpanded,
                    hasNestedSteps: hasNestedSteps,
                    onToggleExpanded:
                        hasNestedSteps || widget.dayStep.description.isNotEmpty
                        ? () {
                            setState(() {
                              _isExpanded = !_isExpanded;
                            });
                          }
                        : null,
                  ),
                ),
              ),
            ],
          ),
        ),
        if (hasNestedSteps && _isExpanded)
          ...widget.dayStep.nestedSteps!.asMap().entries.map((entry) {
            final index = entry.key;
            final step = entry.value;
            final isLastStep = step == widget.dayStep.nestedSteps!.last;

            final isStepCompleted = provider.isStepCompleted(
              widget.dayStep.stepNumber,
              step.stepNumber,
            );

            // Determine if the step is active (next turn)
            // It is active if it is NOT completed AND:
            // 1. It is the first step in the list
            // 2. OR the previous step is completed
            bool isStepActive = false;
            if (!isStepCompleted) {
              if (index == 0) {
                // If it's the first step, it's active ONLY if the day itself is active
                isStepActive = widget.isActive;
              } else {
                final previousStep = widget.dayStep.nestedSteps![index - 1];
                final isPreviousCompleted = provider.isStepCompleted(
                  widget.dayStep.stepNumber,
                  previousStep.stepNumber,
                );
                if (isPreviousCompleted) {
                  isStepActive = true;
                }
              }
            }

            RitualGuidanceStatus status = RitualGuidanceStatus.pending;
            if (isStepCompleted) {
              status = RitualGuidanceStatus.completed;
            } else if (isStepActive) {
              status = RitualGuidanceStatus.active;
            }

            return Padding(
              padding: EdgeInsets.only(bottom: 16.r),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: 28.r,
                    child: Column(
                      children: [
                        AnimatedContainer(
                          duration: Duration(milliseconds: 500 + (index * 100)),
                          width: 3,
                          height: 50.r,
                          decoration: BoxDecoration(
                            gradient: isStepCompleted || isStepActive
                                ? LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      ColorUtil.accentColor,
                                      ColorUtil.accentColor.withValues(
                                        alpha: 0.6,
                                      ),
                                    ],
                                  )
                                : LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      ColorUtil.accentColor.withValues(
                                        alpha: 0.3,
                                      ),
                                      ColorUtil.accentColor.withValues(
                                        alpha: 0.1,
                                      ),
                                    ],
                                  ),
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                        AnimatedContainer(
                          duration: Duration(milliseconds: 300 + (index * 50)),
                          width: 10.r,
                          height: 10.r,
                          margin: EdgeInsets.symmetric(vertical: 4.r),
                          decoration: BoxDecoration(
                            color: isStepCompleted
                                ? Colors.green
                                : isStepActive
                                ? ColorUtil.primaryColor
                                : ColorUtil.accentColor.withValues(alpha: 0.5),
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 2),
                            boxShadow: [
                              BoxShadow(
                                color:
                                    (isStepCompleted
                                            ? Colors.green
                                            : isStepActive
                                            ? ColorUtil.primaryColor
                                            : ColorUtil.accentColor)
                                        .withValues(alpha: 0.3),
                                blurRadius: 4,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                        ),
                        AnimatedContainer(
                          duration: Duration(milliseconds: 500 + (index * 100)),
                          width: 3,
                          height: 50.r,
                          decoration: BoxDecoration(
                            gradient: (widget.isLast && isLastStep)
                                ? LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      ColorUtil.accentColor.withValues(
                                        alpha: 0.3,
                                      ),
                                      Colors.transparent,
                                    ],
                                  )
                                : (isStepCompleted || isStepActive
                                      ? LinearGradient(
                                          begin: Alignment.topCenter,
                                          end: Alignment.bottomCenter,
                                          colors: [
                                            ColorUtil.accentColor,
                                            ColorUtil.accentColor.withValues(
                                              alpha: 0.6,
                                            ),
                                          ],
                                        )
                                      : LinearGradient(
                                          begin: Alignment.topCenter,
                                          end: Alignment.bottomCenter,
                                          colors: [
                                            ColorUtil.accentColor.withValues(
                                              alpha: 0.3,
                                            ),
                                            ColorUtil.accentColor.withValues(
                                              alpha: 0.1,
                                            ),
                                          ],
                                        )),
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                      ],
                    ),
                  ),
                  16.horizontalSpace,
                  Expanded(
                    child: AnimatedContainer(
                      duration: Duration(milliseconds: 300 + (index * 100)),
                      curve: Curves.easeOutBack,
                      child: HajjStepCard(
                        step: step,
                        onTap: () => widget.onStepTap(step),
                        status: status,
                      ),
                    ),
                  ),
                ],
              ),
            );
          }),
      ],
    );
  }
}
