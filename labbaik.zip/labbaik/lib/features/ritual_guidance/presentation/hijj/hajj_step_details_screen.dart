import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:labbaik/core/models/ritual_guidance.dart';
import 'package:provider/provider.dart';
import 'package:labbaik/core/widgets/confirmation_dialog.dart';
import 'package:labbaik/core/widgets/custom_transition_page.dart'
    show CustomTransitionPageBuilder;
import 'package:labbaik/features/ritual_guidance/providers/hijj_provider.dart';
import 'widgets/hajj_step_header.dart';
import 'widgets/hajj_step_details_list.dart';
import 'package:labbaik/core/widgets/ritual_progress_stepper.dart';
import 'package:labbaik/features/ritual_guidance/presentation/widgets/umrah_widgets/umrah_step_description_card.dart';

class HajjStepDetailsScreen extends StatefulWidget {
  static const String routeName = 'hajj_step_details';
  static const String path = '/hajj_step_details';

  final RitualGuidance ritualStep;
  final int dayNumber;
  final HijjProvider progressProvider;
  final String dayTitle;

  const HajjStepDetailsScreen({
    super.key,
    required this.ritualStep,
    required this.dayNumber,
    required this.progressProvider,
    required this.dayTitle,
  });

  static CustomTransitionPageBuilder page(
    BuildContext context,
    GoRouterState state,
  ) {
    final screen = state.extra as Map<String, dynamic>;
    final ritualStep = screen['ritualStep'] as RitualGuidance;
    final progressProvider = screen['progressProvider'] as HijjProvider;
    final dayNumber = screen['dayNumber'] as int;
    final dayTitle = screen['dayTitle'] as String;
    return CustomTransitionPageBuilder(
      key: state.pageKey,
      page: HajjStepDetailsScreen(
        ritualStep: ritualStep,
        dayNumber: dayNumber,
        progressProvider: progressProvider,
        dayTitle: dayTitle,
      ),
      name: routeName,
    );
  }

  static void push({
    required BuildContext context,
    required RitualGuidance ritualStep,
    required int dayNumber,
    required HijjProvider progressProvider,
    required String dayTitle,
  }) => context.push(
    path,
    extra: {
      'ritualStep': ritualStep,
      'dayNumber': dayNumber,
      'progressProvider': progressProvider,
      'dayTitle': dayTitle,
    },
  );

  @override
  State<HajjStepDetailsScreen> createState() => _HajjStepDetailsScreenState();
}

class _HajjStepDetailsScreenState extends State<HajjStepDetailsScreen> {
  late RitualGuidance ritualStep;
  late HijjProvider progressProvider;

  @override
  void initState() {
    super.initState();
    ritualStep = widget.ritualStep;
    progressProvider = widget.progressProvider;
  }

  Future<bool> _onWillPop() async {
    if (progressProvider.isStepCompleted(
      widget.dayNumber,
      ritualStep.stepNumber,
    )) {
      return true;
    }

    if (!progressProvider.showCompletionDialog) {
      return true;
    }

    await ConfirmationDialog.showHajjStepCompletionDialog(
      context: context,
      stepName: ritualStep.title,
      dayNumber: widget.dayNumber,
      stepNumber: ritualStep.stepNumber,
      progressProvider: progressProvider,
    );

    return true;
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: progressProvider,
      child: Consumer<HijjProvider>(
        builder: (context, progressProvider, child) {
          return PopScope(
            canPop: false,
            onPopInvokedWithResult: (bool didPop, dynamic result) async {
              if (!didPop) {
                final shouldPop = await _onWillPop();
                if (shouldPop && mounted) {
                  context.pop();
                }
              }
            },
            child: Scaffold(
              backgroundColor: Theme.of(context).scaffoldBackgroundColor,
              body: SafeArea(
                top: false,
                child: Column(
                  children: [
                    HajjStepHeader(
                      stepNumber: ritualStep.stepNumber,
                      stepTitle: ritualStep.title,
                      stepIcon: ritualStep.icon,
                      dayTitle: widget.dayTitle,
                      onBackPressedAsync: _onWillPop,
                      isCompleted: progressProvider.isStepCompleted(
                        widget.dayNumber,
                        ritualStep.stepNumber,
                      ),
                      onToggleCompletion: (value) {
                        if (value) {
                          progressProvider.markStepCompleted(
                            widget.dayNumber,
                            ritualStep.stepNumber,
                          );
                        }
                        // We don't support un-completing from here yet, or maybe we should?
                        // The requirement says "mark it as complete", usually implies one way or toggle.
                        // Given the provider only has markStepCompleted, I'll assume one way for now
                        // or if I want to toggle I need a method for that.
                        // But wait, the user said "radio button... to mark it as complete".
                        // If it's a radio button, it usually stays selected.
                        // Let's just call markStepCompleted if value is true.
                      },
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(horizontal: 16).r,
                      child: RitualProgressStepper(
                        steps: progressProvider.getStepsForDay(
                          widget.dayNumber,
                        ),
                        currentStepNumber: ritualStep.stepNumber,
                        progress: progressProvider.getCompletedStepsForDay(
                          widget.dayNumber,
                        ),
                      ),
                    ),
                    Expanded(
                      child: SingleChildScrollView(
                        padding: EdgeInsets.symmetric(horizontal: 16).r,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            20.verticalSpace,
                            if (ritualStep.description.isNotEmpty) ...[
                              UmrahStepDescriptionCard(
                                description: ritualStep.description,
                              ),
                              30.verticalSpace,
                            ],
                            HajjStepDetailsList(step: ritualStep),
                            40.verticalSpace,
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
