import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart' show GoRouterState, GoRouterHelper;
import 'package:labbaik/core/widgets/global_scaffold.dart';
import 'package:labbaik/core/widgets/reset_button.dart';
import 'package:labbaik/features/ritual_guidance/presentation/hijj/hijj_journey.dart';
import 'package:labbaik/features/ritual_guidance/presentation/widgets/umrah_widgets/step_card.dart';
import 'package:provider/provider.dart';
import 'package:labbaik/features/ritual_guidance/providers/hijj_provider.dart';
import 'package:labbaik/generated/l10n.dart';
import 'widgets/hajj_timeline_item.dart';
import 'hajj_step_details_screen.dart';

import '../../../../core/widgets/custom_transition_page.dart'
    show CustomTransitionPageBuilder;

class HijjGuidanceScreen extends StatefulWidget {
  static const String routeName = 'hijj_guidance_screen';
  static const String path = '/hijj_guidance_screen';

  const HijjGuidanceScreen({super.key});

  static CustomTransitionPageBuilder page(
    BuildContext context,
    GoRouterState state,
  ) => CustomTransitionPageBuilder(
    key: state.pageKey,
    page: const HijjGuidanceScreen(),
    name: routeName,
  );

  static void push({required BuildContext context}) => context.push(path);

  @override
  State<HijjGuidanceScreen> createState() => _HijjGuidanceScreenState();
}

class _HijjGuidanceScreenState extends State<HijjGuidanceScreen> {
  @override
  Widget build(BuildContext context) {
    return GlobalScaffold(
      withBackButton: true,
      bottomNavBarIndex: 1,
      create: (_) => HijjProvider(),
      child: Consumer<HijjProvider>(
        builder: (context, progressProvider, child) {
          return SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                16.verticalSpace,
                Row(
                  spacing: 16.spMin,
                  children: [
                    Text(
                      S.of(context).hijjGuidance,
                      style: Theme.of(context).textTheme.headlineMedium
                          ?.copyWith(fontWeight: FontWeight.bold),
                    ),
                    ResetButton(
                      onTap: () {
                        progressProvider.reset();
                      },
                    ),
                  ],
                ),
                16.verticalSpace,
                StepCard(
                  step: progressProvider.initalStep,
                  onTap: () {
                    YourHijjJourneyScreen.push(
                      context,
                      hijjProvider: progressProvider,
                    );
                  },
                ),
                30.verticalSpace,
                ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: progressProvider.hijjProgressSteps.length,
                  itemBuilder: (context, index) {
                    final dayStep = progressProvider.hijjProgressSteps[index];
                    return HajjTimelineItem(
                      dayStep: dayStep,
                      isLast:
                          index ==
                          progressProvider.hijjProgressSteps.length - 1,
                      isCompleted: progressProvider.isDayCompleted(
                        dayStep.stepNumber,
                      ),
                      isActive: progressProvider.isDayActive(
                        dayStep.stepNumber,
                      ),
                      onStepTap: (step) {
                        HajjStepDetailsScreen.push(
                          context: context,
                          ritualStep: step,
                          dayNumber: dayStep.stepNumber,
                          progressProvider: progressProvider,
                          dayTitle: dayStep.title,
                        );
                      },
                    );
                  },
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
