import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:labbaik/core/widgets/k_app_header.dart';
import 'package:labbaik/features/ritual_guidance/providers/hijj_provider.dart';
import 'package:provider/provider.dart';
import 'package:labbaik/core/widgets/custom_transition_page.dart'
    show CustomTransitionPageBuilder;
import 'widgets/hijj_type_card.dart';

class YourHijjJourneyScreen extends StatelessWidget {
  static const String routeName = 'your_hijj_journey_screen';
  static const String path = '/your_hijj_journey_screen';

  final HijjProvider hijjProvider;

  const YourHijjJourneyScreen({super.key, required this.hijjProvider});

  static CustomTransitionPageBuilder page(
    BuildContext context,
    GoRouterState state,
  ) {
    final hijjProvider = state.extra as HijjProvider;
    return CustomTransitionPageBuilder(
      key: state.pageKey,
      page: YourHijjJourneyScreen(hijjProvider: hijjProvider),
      name: routeName,
    );
  }

  static void push(
    BuildContext context, {
    required HijjProvider hijjProvider,
  }) => context.push(path, extra: hijjProvider);

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider.value(
      value: hijjProvider,
      child: Consumer<HijjProvider>(
        builder: (context, provider, child) {
          return Scaffold(
            backgroundColor: Theme.of(context).scaffoldBackgroundColor,
            body: SafeArea(
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(horizontal: 16).r,
                child: Column(
                  children: [
                    const KAppHeader(),
                    20.verticalSpace,
                    ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: provider.initalStep.subSteps!.length,
                      itemBuilder: (context, index) {
                        final subStep = provider.initalStep.subSteps![index];
                        return HijjTypeCard(step: subStep);
                      },
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
