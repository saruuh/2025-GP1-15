import 'dart:async';
import 'package:flutter/material.dart';
import 'package:labbaik/core/services/auth_service.dart';
import 'package:labbaik/core/utilities/custom_logger.dart';
import 'package:labbaik/core/services/umrah_progress_service.dart';
import 'package:labbaik/core/utilities/path_util.dart';
import 'package:labbaik/generated/l10n.dart';

import '../../../core/models/ritual_guidance.dart' show RitualGuidance;

/// Provider for managing Umrah progress state
/// Uses selectors for optimal performance
class UmrahProgressProvider extends ChangeNotifier {
  final UmrahProgressService _progressService = UmrahProgressService();
  final AuthService _authService = AuthService();

  UmrahProgressProvider() {
    CustomLogger.instance.info('UmrahProgressProvider constructor');

    // Initialize immediately if user is already logged in
    if (isAuthenticated) {
      // Use a microtask to avoid calling async in constructor
      Future.microtask(() => initialize());
    }
  }

  bool _isLoading = false;
  String? _error;
  Map<int, bool> _completedSteps = {};
  bool _showCompletionDialog = true;

  List<RitualGuidance> allSteps = [
    RitualGuidance(
      stepNumber: 1,
      title: S.current.ihram,
      icon: PathUtil.step1,
      description: S.current.step1Description,
    ),
    RitualGuidance(
      stepNumber: 2,
      title: S.current.tawaf,
      icon: PathUtil.step2,
      description: S.current.step2Description,
    ),
    RitualGuidance(
      stepNumber: 3,
      title: S.current.saee,
      icon: PathUtil.step3,
      description: S.current.step3Description,
    ),
    RitualGuidance(
      stepNumber: 4,
      title: S.current.tahallul,
      icon: PathUtil.step4,
      description: S.current.step4Description,
    ),
  ];

  // Getters with selectors support
  bool get isLoading => _isLoading;
  String? get error => _error;
  Map<int, bool> get completedSteps => _completedSteps;
  bool get showCompletionDialog => _showCompletionDialog;

  /// Check if user is authenticated
  bool get isAuthenticated => _authService.currentUser != null;

  int get activeStepNumber => _completedSteps.keys.lastWhere(
    (key) => _completedSteps[key] == false,
    orElse: () => 0,
  );

  /// Get completion status for a specific step
  bool isStepCompleted(int stepNumber) {
    return _completedSteps[stepNumber] ?? false;
  }

  /// Get count of completed steps
  int get completedStepsCount {
    return _completedSteps.values.where((completed) => completed).length;
  }

  /// Initialize and fetch progress from Firebase
  Future<void> initialize({bool force = false}) async {
    if (!isAuthenticated) {
      CustomLogger.instance.warning(
        'Cannot initialize progress: user not authenticated',
      );
      return;
    }
    // Prevent multiple simultaneous initializations
    if (_isLoading) {
      CustomLogger.instance.info(
        'Initialization already in progress, skipping...',
      );
      return;
    }

    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      _completedSteps = await _progressService.fetchProgress();
      _showCompletionDialog = await _progressService.fetchDialogPreference();
      CustomLogger.instance.info('Progress initialized: $_completedSteps');
    } catch (e) {
      _error = e.toString();
      CustomLogger.instance.error('Error initializing progress: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Mark a step as completed
  Future<void> markStepCompleted(int stepNumber) async {
    if (!isAuthenticated) {
      _error = 'User not authenticated';
      notifyListeners();
      return;
    }

    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      await _progressService.markStepCompleted(stepNumber);
      _completedSteps[stepNumber] = true;
      refreshProgress();
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      CustomLogger.instance.error('Error marking step completed: $e');
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Reset all progress
  Future<void> resetProgress() async {
    if (!isAuthenticated) {
      _error = 'User not authenticated';
      notifyListeners();
      return;
    }

    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      await _progressService.resetProgress();
      _completedSteps.clear();
      CustomLogger.instance.info('Progress reset');
    } catch (e) {
      _error = e.toString();
      CustomLogger.instance.error('Error resetting progress: $e');
      rethrow;
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Refresh progress from Firebase
  Future<void> refreshProgress() async {
    if (!isAuthenticated) {
      return;
    }

    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      _completedSteps = await _progressService.fetchProgress();
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      CustomLogger.instance.error('Error refreshing progress: $e');
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  /// Set dialog preference
  Future<void> setDialogPreference(bool show) async {
    CustomLogger.instance.info('Setting dialog preference in provider: $show');
    _showCompletionDialog = show;
    notifyListeners();
    await _progressService.saveDialogPreference(show);
  }

  /// Clear error
  void clearError() {
    _error = null;
    notifyListeners();
  }

  /// Reset provider state (for disposal)
  void reset() {
    _isLoading = false;
    _error = null;
    _completedSteps.clear();
    resetProgress();
    refreshProgress();
    notifyListeners();
  }

  @override
  void dispose() {
    CustomLogger.instance.info('UmrahProgressProvider disposed');
    super.dispose();
  }
}
