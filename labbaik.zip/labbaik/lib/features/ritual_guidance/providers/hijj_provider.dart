import 'package:flutter/material.dart';
import 'package:labbaik/core/models/ritual_guidance.dart';
import 'package:labbaik/core/services/hajj_progress_service.dart';
import 'package:labbaik/core/utilities/custom_logger.dart';

class HijjProvider extends ChangeNotifier {
  final HajjProgressService _progressService = HajjProgressService();

  late RitualGuidance _initalStep;
  List<RitualGuidance> _hijjProgressSteps = [];
  Map<String, bool> _completedSteps = {};
  bool _isLoading = false;
  bool _showCompletionDialog = true;

  // Getters
  RitualGuidance get initalStep => _initalStep;
  List<RitualGuidance> get hijjProgressSteps => _hijjProgressSteps;
  bool get isLoading => _isLoading;
  bool get showCompletionDialog => _showCompletionDialog;

  HijjProvider() {
    _initalStep = dummyInitalStep();
    _hijjProgressSteps = dummyHijjProgressSteps();
    _loadProgress();
  }

  Future<void> _loadProgress() async {
    _isLoading = true;
    notifyListeners();
    try {
      _completedSteps = await _progressService.fetchProgress();
      _showCompletionDialog = await _progressService.fetchDialogPreference();
    } catch (e) {
      // Handle error
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  bool isStepCompleted(int dayNumber, int stepNumber) {
    final key = '${dayNumber}_$stepNumber';
    return _completedSteps[key] ?? false;
  }

  Future<void> markStepCompleted(int dayNumber, int stepNumber) async {
    final key = '${dayNumber}_$stepNumber';
    _completedSteps[key] = true;
    notifyListeners();

    try {
      await _progressService.markStepCompleted(dayNumber, stepNumber);
    } catch (e) {
      // Handle error
    }
  }

  Future<void> reset() async {
    _completedSteps.clear();
    notifyListeners();
    await _progressService.resetProgress();
  }

  Future<void> setDialogPreference(bool show) async {
    CustomLogger.instance.info('Setting dialog preference in provider: $show');
    _showCompletionDialog = show;
    notifyListeners();
    await _progressService.saveDialogPreference(show);
  }

  List<RitualGuidance> getStepsForDay(int dayNumber) {
    return _hijjProgressSteps
            .firstWhere(
              (day) => day.stepNumber == dayNumber,
              orElse: () => _hijjProgressSteps.first,
            )
            .nestedSteps ??
        [];
  }

  Map<int, bool> getCompletedStepsForDay(int dayNumber) {
    final steps = getStepsForDay(dayNumber);
    final Map<int, bool> dayProgress = {};

    for (var step in steps) {
      final key = '${dayNumber}_${step.stepNumber}';
      if (_completedSteps.containsKey(key)) {
        dayProgress[step.stepNumber] = _completedSteps[key]!;
      }
    }

    return dayProgress;
  }

  bool isDayCompleted(int dayNumber) {
    final steps = getStepsForDay(dayNumber);
    if (steps.isEmpty) return false;

    for (var step in steps) {
      if (!isStepCompleted(dayNumber, step.stepNumber)) {
        return false;
      }
    }
    return true;
  }

  bool isDayActive(int dayNumber) {
    // A day is active if it is NOT completed AND:
    // 1. It is the first day (index 0 in _hijjProgressSteps)
    // 2. OR the previous day is completed

    if (isDayCompleted(dayNumber)) return false;

    final dayIndex = _hijjProgressSteps.indexWhere(
      (d) => d.stepNumber == dayNumber,
    );
    if (dayIndex == -1) return false;

    if (dayIndex == 0) return true;

    final previousDay = _hijjProgressSteps[dayIndex - 1];
    return isDayCompleted(previousDay.stepNumber);
  }
}
