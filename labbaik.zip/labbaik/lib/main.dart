import 'package:flutter/material.dart';
import 'package:labbaik/firebase_options.dart' show DefaultFirebaseOptions;
import 'package:firebase_core/firebase_core.dart' show Firebase;

import 'core/config/provider_config.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(ProviderConfig.getProviderWidget());
}
