import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../utilities/color_util.dart';
import 'app_fonts.dart';
import 'app_styles.dart';
import 'app_values.dart';

ThemeData getLightTheme() {
  return ThemeData(
    brightness: Brightness.light,
    scaffoldBackgroundColor: LightThemeColors.scaffold,
    // main colors
    primaryColor: ColorUtil.primaryColor,
    primaryColorLight: ColorUtil.primaryW50,
    primaryColorDark: ColorUtil.primaryW700,
    disabledColor: ColorUtil.grey1,
    splashColor: ColorUtil.primaryW50.withValues(alpha: .5),
    // ripple effect color

    // card view theme
    cardTheme: CardThemeData(
      surfaceTintColor: ColorUtil.transparent,
      color: LightThemeColors.surface,
      shadowColor: LightThemeColors.shadow,
      elevation: AppSize.s4,
    ),

    // app bar theme
    appBarTheme: AppBarTheme(
      systemOverlayStyle: SystemUiOverlayStyle(
        statusBarColor: ColorUtil.transparent,
        statusBarIconBrightness: Brightness.dark,
      ),
      backgroundColor: LightThemeColors.surface,
      elevation: AppSize.s0,
      shadowColor: ColorUtil.primaryW50,
      surfaceTintColor: ColorUtil.transparent,
      foregroundColor: ColorUtil.primaryColor,
      titleTextStyle: getBoldStyle(
        fontSize: FontSize.s22,
        color: LightThemeColors.textPrimary,
      ),
    ),

    // button theme
    buttonTheme: ButtonThemeData(
      shape: const StadiumBorder(),
      disabledColor: ColorUtil.grey1,
      buttonColor: ColorUtil.primaryColor,
      splashColor: ColorUtil.primaryW50.withValues(alpha: .5),
    ),

    // elevated button theme
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.all(AppPadding.p14),
        textStyle: getRegularStyle(
          color: ColorUtil.white,
          fontSize: FontSize.s17,
        ),
        backgroundColor: ColorUtil.primaryColor, // Dark green background
        foregroundColor: ColorUtil.white, // White text
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppSize.s12),
        ),
        elevation: 2, // Add elevation for button shadow
      ),
    ),
    // Text button theme
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppSize.s12.r),
        ),
        textStyle: getRegularStyle(
          color: ColorUtil.linkColor,
          fontSize: FontSize.s15.r,
        ),
        foregroundColor: ColorUtil.linkColor, // Blue for links
      ),
    ),
    bottomSheetTheme: BottomSheetThemeData(
      surfaceTintColor: ColorUtil.transparent,
      backgroundColor: LightThemeColors.surface,
      elevation: AppSize.s4,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(AppSize.s20),
          topRight: Radius.circular(AppSize.s20),
        ),
      ),
    ),
    // text theme
    textTheme: TextTheme(
      displayLarge: getSemiBoldStyle(
        color: ColorUtil.primaryColor,
        fontSize: FontSize.s25,
      ),
      headlineLarge: getBoldStyle(
        color: LightThemeColors.textPrimary,
        fontSize: FontSize.s20,
      ),
      headlineMedium: getRegularStyle(
        color: LightThemeColors.textSecondary,
        fontSize: FontSize.s22,
      ),
      headlineSmall: getBoldStyle(
        color: LightThemeColors.textPrimary,
        fontSize: FontSize.s22,
      ),
      titleLarge: getBoldStyle(
        color: LightThemeColors.textPrimary,
        fontSize: FontSize.s30,
      ),
      titleMedium: getMediumStyle(
        color: LightThemeColors.textSecondary,
        fontSize: FontSize.s15,
      ),
      titleSmall: getRegularStyle(
        color: ColorUtil.blueGray,
        fontSize: FontSize.s15,
      ),
      bodyLarge: getRegularStyle(
        color: LightThemeColors.textPrimary,
        fontSize: FontSize.s17,
      ),
      bodySmall: getRegularStyle(
        color: ColorUtil.primaryColor,
        fontSize: FontSize.s12,
      ),
    ),

    // input decoration theme (text form field)
    inputDecorationTheme: InputDecorationTheme(
      // content padding
      contentPadding: const EdgeInsets.all(AppPadding.p8),
      // hint style
      hintStyle: getRegularStyle(
        color: LightThemeColors.textHint,
        fontSize: FontSize.s14,
      ),
      labelStyle: getMediumStyle(
        color: LightThemeColors.textPrimary,
        fontSize: FontSize.s14,
      ),
      prefixStyle: getRegularStyle(
        color: LightThemeColors.textHint,
        fontSize: FontSize.s14,
      ),
      prefixIconColor: LightThemeColors.textHint,
      errorStyle: getRegularStyle(color: ColorUtil.errorColor),
      fillColor: LightThemeColors.inputFill,
      filled: true,

      // enabled border style
      enabledBorder: OutlineInputBorder(
        borderSide: BorderSide(
          color: LightThemeColors.border,
          width: AppSize.s1_5,
        ),
        borderRadius: const BorderRadius.all(Radius.circular(AppSize.s8)),
      ),

      // focused border style
      focusedBorder: OutlineInputBorder(
        borderSide: BorderSide(
          color: ColorUtil.primaryColor,
          width: AppSize.s1_5,
        ),
        borderRadius: const BorderRadius.all(Radius.circular(AppSize.s8)),
      ),

      // error border style
      errorBorder: OutlineInputBorder(
        borderSide: BorderSide(
          color: ColorUtil.errorColor,
          width: AppSize.s1_5,
        ),
        borderRadius: const BorderRadius.all(Radius.circular(AppSize.s8)),
      ),
      // focused error border style
      focusedErrorBorder: OutlineInputBorder(
        borderSide: BorderSide(
          color: ColorUtil.errorColor,
          width: AppSize.s1_5,
        ),
        borderRadius: const BorderRadius.all(Radius.circular(AppSize.s8)),
      ),
    ),

    //bottom nav
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      selectedItemColor: ColorUtil.white,
      unselectedItemColor: ColorUtil.white.withValues(alpha: .7),
      showSelectedLabels: true,
      showUnselectedLabels: true,
      backgroundColor: ColorUtil.primaryColor, // Dark green background
      type: BottomNavigationBarType.fixed,
    ),
    iconTheme: IconThemeData(color: ColorUtil.primaryColor),
    listTileTheme: ListTileThemeData(iconColor: ColorUtil.primaryColor),
  );
}

ThemeData getDarkTheme() {
  return ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: DarkThemeColors.scaffold,
    // main colors
    primaryColor: ColorUtil.primaryColor,
    primaryColorLight: ColorUtil.primaryW50,
    primaryColorDark: ColorUtil.primaryW700,
    disabledColor: ColorUtil.grey1,
    splashColor: ColorUtil.primaryW50.withValues(alpha: .5),
    // ripple effect color

    // card view theme
    cardTheme: CardThemeData(
      surfaceTintColor: ColorUtil.transparent,
      color: DarkThemeColors.card,
      shadowColor: DarkThemeColors.shadow,
      elevation: AppSize.s4,
    ),

    // app bar theme
    appBarTheme: AppBarTheme(
      systemOverlayStyle: SystemUiOverlayStyle(
        statusBarColor: ColorUtil.transparent,
        statusBarIconBrightness: Brightness.light,
      ),
      backgroundColor: DarkThemeColors.surface,
      elevation: AppSize.s0,
      shadowColor: ColorUtil.primaryW50,
      surfaceTintColor: ColorUtil.transparent,
      foregroundColor: ColorUtil.primaryColor,
      titleTextStyle: getBoldStyle(
        fontSize: FontSize.s22,
        color: DarkThemeColors.textPrimary,
      ),
    ),

    // button theme
    buttonTheme: ButtonThemeData(
      shape: const StadiumBorder(),
      disabledColor: ColorUtil.grey1,
      buttonColor: ColorUtil.primaryColor,
      splashColor: ColorUtil.primaryW50.withValues(alpha: .5),
    ),

    // elevated button theme
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        padding: const EdgeInsets.all(AppPadding.p14),
        textStyle: getRegularStyle(
          color: ColorUtil.white,
          fontSize: FontSize.s17,
        ),
        backgroundColor: ColorUtil.primaryColor, // Dark green background
        foregroundColor: ColorUtil.white, // White text
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppSize.s12),
        ),
        elevation: 2, // Add elevation for button shadow
      ),
    ),
    // Text button them
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppSize.s12.r),
        ),
        textStyle: getRegularStyle(
          color: ColorUtil.primaryColor,
          fontSize: FontSize.s15.r,
        ),
        foregroundColor: ColorUtil.primaryColor,
      ),
    ),
    bottomSheetTheme: BottomSheetThemeData(
      surfaceTintColor: ColorUtil.transparent,
      backgroundColor: DarkThemeColors.surface,
      elevation: AppSize.s4,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(AppSize.s20),
          topRight: Radius.circular(AppSize.s20),
        ),
      ),
    ),
    // text theme
    textTheme: TextTheme(
      displayLarge: getSemiBoldStyle(
        color: ColorUtil.primaryColor,
        fontSize: FontSize.s25,
      ),
      headlineLarge: getBoldStyle(
        color: DarkThemeColors.textPrimary,
        fontSize: FontSize.s20,
      ),
      headlineMedium: getRegularStyle(
        color: DarkThemeColors.textSecondary,
        fontSize: FontSize.s22,
      ),
      headlineSmall: getBoldStyle(
        color: DarkThemeColors.textPrimary,
        fontSize: FontSize.s22,
      ),
      titleLarge: getBoldStyle(
        color: DarkThemeColors.textPrimary,
        fontSize: FontSize.s30,
      ),
      titleMedium: getMediumStyle(
        color: DarkThemeColors.textSecondary,
        fontSize: FontSize.s15,
      ),
      titleSmall: getRegularStyle(
        color: DarkThemeColors.textHint,
        fontSize: FontSize.s15,
      ),
      bodyLarge: getRegularStyle(
        color: DarkThemeColors.textPrimary,
        fontSize: FontSize.s17,
      ),
      bodySmall: getRegularStyle(
        color: ColorUtil.primaryColor,
        fontSize: FontSize.s12,
      ),
    ),

    // input decoration theme (text form field)
    inputDecorationTheme: InputDecorationTheme(
      // content padding
      contentPadding: const EdgeInsets.all(AppPadding.p8),
      // hint style
      hintStyle: getRegularStyle(
        color: DarkThemeColors.textHint,
        fontSize: FontSize.s14,
      ),
      labelStyle: getMediumStyle(
        color: DarkThemeColors.textPrimary,
        fontSize: FontSize.s14,
      ),
      prefixStyle: getRegularStyle(
        color: DarkThemeColors.textHint,
        fontSize: FontSize.s14,
      ),
      prefixIconColor: DarkThemeColors.textHint,
      errorStyle: getRegularStyle(color: ColorUtil.errorColor),
      fillColor: DarkThemeColors.inputFill,
      filled: true,

      // enabled border style
      enabledBorder: OutlineInputBorder(
        borderSide: BorderSide(
          color: DarkThemeColors.border,
          width: AppSize.s1_5,
        ),
        borderRadius: const BorderRadius.all(Radius.circular(AppSize.s8)),
      ),

      // focused border style
      focusedBorder: OutlineInputBorder(
        borderSide: BorderSide(
          color: ColorUtil.primaryColor,
          width: AppSize.s1_5,
        ),
        borderRadius: const BorderRadius.all(Radius.circular(AppSize.s8)),
      ),

      // error border style
      errorBorder: OutlineInputBorder(
        borderSide: BorderSide(
          color: ColorUtil.errorColor,
          width: AppSize.s1_5,
        ),
        borderRadius: const BorderRadius.all(Radius.circular(AppSize.s8)),
      ),
      // focused error border style
      focusedErrorBorder: OutlineInputBorder(
        borderSide: BorderSide(
          color: ColorUtil.errorColor,
          width: AppSize.s1_5,
        ),
        borderRadius: const BorderRadius.all(Radius.circular(AppSize.s8)),
      ),
    ),

    //bottom nav
    bottomNavigationBarTheme: BottomNavigationBarThemeData(
      selectedItemColor: ColorUtil.white,
      unselectedItemColor: ColorUtil.white.withValues(alpha: .7),
      showSelectedLabels: true,
      showUnselectedLabels: true,
      backgroundColor: ColorUtil.primaryColor, // Dark green background
      type: BottomNavigationBarType.fixed,
    ),
    iconTheme: IconThemeData(color: ColorUtil.primaryColor),
    listTileTheme: ListTileThemeData(iconColor: ColorUtil.primaryColor),
  );
}

// Backward compatibility function
ThemeData getApplicationTheme() {
  return getLightTheme();
}
