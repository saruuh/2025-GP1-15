// change to productionBaseUrl when release
class AppConstant {
  static String appName = "Labbaik";
  static String appTagLine = "Your Personal Assistant";
  static String copyRight = "Labbaik © 2025 All Rights Reserved";
  static String appDescription =
      "$appName is a platform for sharing and discovering hijab and omra videos.";
  static String appDeveloper = "----";
  static String appDeveloperEmail = "----";
  static String gMapsAPIKey = "AIzaSyBpcVxhnVXK_Dt0UdYA6Y_hRgKOFwUyZtI";
  static String appDeveloperWebsite = "----";
  static String appDeveloperLinkedIn = "----";

  // cache
  static String cacheBox = "app_data";
  static String langCache = "lang_cache";
  static String onboardingStatusCache = "onboarding_status_cache";
  static String tokenCache = "token_cache";
  static String userCache = "user_cache";
  static String userSearchCache = "user_search";
  static String filterListCache = "filter_cache";
  static String betaCache = "beta_cache";
  static String isSwitchingEnvironmentCache = "is_switching_environment_cache";
  static String showCaseCache = "show_case_cache";
  static String tokenRemovedCached = "token_removed_cache";
  static String didHeSetPreferencesCache = "did_he_set_preferences_cache";
}

class EndPoints {}
