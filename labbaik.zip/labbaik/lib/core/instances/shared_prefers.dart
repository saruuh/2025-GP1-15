import 'dart:async' show Future;

import 'package:shared_preferences/shared_preferences.dart';

class PreferenceUtils {
  static SharedPreferences? _prefs;

  // SINGLETON
  PreferenceUtils._privateConstructor();

  static final PreferenceUtils _instance =
  PreferenceUtils._privateConstructor();

  static PreferenceUtils get instance => _instance;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  static String getString(String key, [String? defValue]) {
    return _prefs?.getString(key) ?? defValue ?? "";
  }

  static Future<bool> setString(String key, String value) async {
    return await _prefs?.setString(key, value) ?? false;
  }

  static Future<bool?> delString(String key) async {
    return await _prefs?.remove(key);
  }
}
