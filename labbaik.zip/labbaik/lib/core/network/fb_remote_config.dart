import 'package:firebase_remote_config/firebase_remote_config.dart';

class RemoteConfigService {
  final FirebaseRemoteConfig _remoteConfig;

  RemoteConfigService._(this._remoteConfig);

  static Future<RemoteConfigService> initialize() async {
    final remoteConfig = FirebaseRemoteConfig.instance;

    await remoteConfig.setConfigSettings(
      RemoteConfigSettings(
        fetchTimeout: const Duration(minutes: 1),
        minimumFetchInterval: const Duration(microseconds: 30),
      ),
    );

    // Set default values (optional)
    await remoteConfig.setDefaults(<String, dynamic>{
      'android_version': 1,
      'ios_version': 1,
    });

    // Fetch and activate values
    await remoteConfig.fetchAndActivate();
    return RemoteConfigService._(remoteConfig);
  }

  String getSConfig(String value) {
    return _remoteConfig.getString(value);
  }

  int getIConfig(String value) {
    return _remoteConfig.getInt(value);
  }

  bool getBConfig(String value) {
    return _remoteConfig.getBool(value);
  }
}
