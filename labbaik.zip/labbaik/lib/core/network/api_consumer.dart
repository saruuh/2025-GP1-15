import 'dart:io';
import 'package:dio/dio.dart';
import 'package:gal/gal.dart';
import '../../generated/l10n.dart';
import '../utilities/custom_logger.dart';
import 'interceptors.dart';

abstract interface class APIConsumer {
  void setToken(String? token);

  void setLang(String languageCode);

  // Add method to update headers dynamically
  void updateAuthorizationHeader();

  // Add download functionality
  Future<void> downloadFile({
    required String url,
    required String fileName,
    bool isAlbum = true,
    bool isImage = true,
  });

  Future<dynamic> get({
    required String path,
    int apiVersion = 1,
    Object? cancelToken,
    Map<String, dynamic>? headers,
    Map<String, dynamic>? queryParameters,
    Function(int? count, int? total)? onReceiveProgress,
    bool throwDioException = false,
    ResponseType? responseType,
  });

  Future<dynamic> post({
    required String path,
    int apiVersion = 1,
    Object? data,
    Object? cancelToken,
    Map<String, dynamic>? headers,
    Map<String, dynamic>? queryParameters,
    Function(int? count, int? total)? onSendProgress,
    Function(int? count, int? total)? onReceiveProgress,
    bool throwDioException = false,
    ResponseType? responseType,
  });

  Future<dynamic> put({
    required String path,
    int apiVersion = 1,
    Object? data,
    Object? cancelToken,
    Map<String, dynamic>? headers,
    Map<String, dynamic>? queryParameters,
    Function(int? count, int? total)? onSendProgress,
    Function(int? count, int? total)? onReceiveProgress,
    bool throwDioException = false,
    ResponseType? responseType,
  });

  Future<dynamic> patch({
    required String path,
    int apiVersion = 1,
    Object? data,
    Object? cancelToken,
    Map<String, dynamic>? headers,
    Map<String, dynamic>? queryParameters,
    Function(int? count, int? total)? onSendProgress,
    Function(int? count, int? total)? onReceiveProgress,
    bool throwDioException = false,
    ResponseType? responseType,
  });

  Future<dynamic> delete({
    required String path,
    int apiVersion = 1,
    Object? data,
    Object? cancelToken,
    Map<String, dynamic>? headers,
    Map<String, dynamic>? queryParameters,
    bool throwDioException = false,
    ResponseType? responseType,
  });
}

class APIConsumerImpl implements APIConsumer {
  final Dio _dio;

  APIConsumerImpl({required Dio dio}) : _dio = dio {
    _dio.interceptors.addAll([
      AuthorizationInterceptor(),
      LocaleInterceptor(),
      ResponseInterceptor(),
      ErrorInterceptor(),
    ]);

    CustomLogger.instance.info(
      "\n------------------------------------"
      "\n------API consumer Initialized------"
      "\n[BaseUrl]                     : ${_dio.options.baseUrl}"
      "\n[Header]                      : ${_dio.options.headers}"
      "\n[connectTimeout]              : ${_dio.options.connectTimeout?.inSeconds ?? "default"} sec"
      "\n[sendTimeout]                 : ${_dio.options.sendTimeout?.inSeconds ?? "default"} sec"
      "\n[receiveTimeout]              : ${_dio.options.receiveTimeout?.inSeconds ?? "default"} sec"
      "\n[receiveDataWhenStatusError]  : ${_dio.options.receiveDataWhenStatusError}"
      "\n------------------------------------",
    );
  }

  @override
  void setToken(String? token) {
    _dio.interceptors.removeWhere(
      (interceptor) => interceptor is AuthorizationInterceptor,
    );

    _dio.interceptors.add(AuthorizationInterceptor(token: token));
  }

  @override
  void setLang(String languageCode) {
    _dio.interceptors.removeWhere(
      (interceptor) => interceptor is LocaleInterceptor,
    );

    _dio.interceptors.add(LocaleInterceptor(languageCode: languageCode));
  }

  @override
  void updateAuthorizationHeader() {
    // Update the AuthorizationInterceptor with current token
    // setToken(Global.token);

    // Update the LocaleInterceptor with current language
    // setLang(Global.kLang ?? "en");
  }

  @override
  Future<void> downloadFile({
    required String url,
    required String fileName,
    bool isAlbum = true,
    bool isImage = true,
  }) async {
    final path = '${Directory.systemTemp.path}/$fileName.png';
    await Dio().download(url, path);
    if (isImage) {
      await Gal.putImage(path, album: isAlbum ? S.current.album : null);
    } else {
      await Gal.putVideo(path, album: isAlbum ? S.current.album : null);
    }
  }

  void _onSendProgress(int count, int total) {
    if (count == total) {
      CustomLogger.instance.info("Request progress Done 100%");
    } else {
      CustomLogger.instance.warning(
        'Request progress : ${(count / total).toStringAsFixed(2)} %',
      );
    }
  }

  String logFormData(dynamic data) {
    String dataFields = '';
    String dataFiles = '';
    CustomLogger.instance.info("data is FormData ${data.runtimeType}");
    if (data is FormData) {
      for (var i = 0; i < data.fields.length; i++) {
        final item = data.fields[i];
        dataFields = 'FIELD$i: ${item.key} = ${item.value}\n';
      }

      for (var i = 0; i < data.files.length; i++) {
        final file = data.files[i];
        dataFiles = 'FILE$i: ${file.key} = ${file.value}\n';
      }
    } else if (data is Map<String, dynamic>) {
      data.forEach((key, value) {
        dataFields = 'Field: $key = $value\n';
      });
    }
    return 'FIELDS: $dataFields FILES: $dataFiles';
  }

  DioException _handleDioException(DioException exception) {
    DioException dioException = exception;

    switch (exception.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.sendTimeout:
      case DioExceptionType.receiveTimeout:
      case DioExceptionType.badCertificate:
        dioException = exception.copyWith(message: S.current.timeOutException);
        break;
      case DioExceptionType.cancel:
        dioException = exception.copyWith(message: S.current.cancelException);
        break;
      case DioExceptionType.connectionError:
        dioException = exception.copyWith(message: S.current.httpException);
        break;
      case DioExceptionType.badResponse:
      case DioExceptionType.unknown:
        break;
    }

    return dioException;
  }

  @override
  Future<dynamic> get({
    required String path,
    int apiVersion = 1,
    Object? cancelToken,
    Map<String, dynamic>? headers,
    Map<String, dynamic>? queryParameters,
    Function(int? count, int? total)? onReceiveProgress,
    bool throwDioException = false,
    ResponseType? responseType,
  }) async {
    updateAuthorizationHeader();
    try {
      queryParameters?.removeWhere(
        (key, value) =>
            value == null ||
            (value is String && value.isEmpty) ||
            (value is List && value.isEmpty) ||
            (value is Map && value.isEmpty),
      );

      final response = await _dio.get(
        "/$path",
        queryParameters: queryParameters,
        cancelToken: cancelToken as CancelToken?,
        onReceiveProgress: onReceiveProgress,
        options: Options(headers: headers, responseType: responseType),
      );
      return response.data;
    } on DioException catch (dioException) {
      final exception = _handleDioException(dioException);

      throwDioException
          ? throw exception
          : throw exception.message ?? S.current.httpException;
    }
  }

  @override
  Future<dynamic> post({
    required String path,
    int apiVersion = 1,
    Object? data,
    Object? cancelToken,
    Map<String, dynamic>? headers,
    Map<String, dynamic>? queryParameters,
    Function(int? count, int? total)? onSendProgress,
    Function(int? count, int? total)? onReceiveProgress,
    bool throwDioException = false,
    ResponseType? responseType,
  }) async {
    updateAuthorizationHeader();
    try {
      queryParameters?.removeWhere(
        (key, value) =>
            value == null ||
            (value is String && value.isEmpty) ||
            (value is List && value.isEmpty) ||
            (value is Map && value.isEmpty),
      );

      final response = await _dio.post(
        "/$path",
        queryParameters: queryParameters,
        cancelToken: cancelToken as CancelToken?,
        onSendProgress: onSendProgress ?? _onSendProgress,
        onReceiveProgress: onReceiveProgress,
        options: Options(headers: headers, responseType: responseType),
        data: data,
      );

      return response.data;
    } on DioException catch (dioException) {
      final exception = _handleDioException(dioException);

      throwDioException
          ? throw exception
          : throw exception.message ?? S.current.httpException;
    }
  }

  @override
  Future<dynamic> put({
    required String path,
    int apiVersion = 1,
    Object? data,
    Object? cancelToken,
    Map<String, dynamic>? headers,
    Map<String, dynamic>? queryParameters,
    Function(int? count, int? total)? onSendProgress,
    Function(int? count, int? total)? onReceiveProgress,
    bool throwDioException = false,
    ResponseType? responseType,
  }) async {
    updateAuthorizationHeader();
    try {
      queryParameters?.removeWhere(
        (key, value) =>
            value == null ||
            (value is String && value.isEmpty) ||
            (value is List && value.isEmpty) ||
            (value is Map && value.isEmpty),
      );

      final response = await _dio.put(
        "/$path",
        queryParameters: queryParameters,
        cancelToken: cancelToken as CancelToken?,
        onSendProgress: onSendProgress ?? _onSendProgress,
        onReceiveProgress: onReceiveProgress,
        options: Options(headers: headers, responseType: responseType),
        data: data,
      );

      return response.data;
    } on DioException catch (dioException) {
      final exception = _handleDioException(dioException);

      throwDioException
          ? throw exception
          : throw exception.message ?? S.current.httpException;
    }
  }

  @override
  Future patch({
    required String path,
    int apiVersion = 1,
    Object? data,
    Object? cancelToken,
    Map<String, dynamic>? headers,
    Map<String, dynamic>? queryParameters,
    Function(int? count, int? total)? onSendProgress,
    Function(int? count, int? total)? onReceiveProgress,
    bool throwDioException = false,
    ResponseType? responseType,
  }) async {
    updateAuthorizationHeader();
    try {
      queryParameters?.removeWhere(
        (key, value) =>
            value == null ||
            (value is String && value.isEmpty) ||
            (value is List && value.isEmpty) ||
            (value is Map && value.isEmpty),
      );

      final response = await _dio.patch(
        "/$path",
        queryParameters: queryParameters,
        cancelToken: cancelToken as CancelToken?,
        onSendProgress: onSendProgress ?? _onSendProgress,
        onReceiveProgress: onReceiveProgress,
        options: Options(headers: headers, responseType: responseType),
        data: data,
      );

      return response.data;
    } on DioException catch (dioException) {
      final exception = _handleDioException(dioException);

      throwDioException
          ? throw exception
          : throw exception.message ?? S.current.httpException;
    }
  }

  @override
  Future<dynamic> delete({
    required String path,
    int apiVersion = 1,
    Object? data,
    Object? cancelToken,
    Map<String, dynamic>? headers,
    Map<String, dynamic>? queryParameters,
    bool throwDioException = false,
    ResponseType? responseType,
  }) async {
    updateAuthorizationHeader();
    try {
      queryParameters?.removeWhere(
        (key, value) =>
            value == null ||
            (value is String && value.isEmpty) ||
            (value is List && value.isEmpty) ||
            (value is Map && value.isEmpty),
      );

      final response = await _dio.delete(
        "/$path",
        queryParameters: queryParameters,
        cancelToken: cancelToken as CancelToken?,
        data: data,
        options: Options(headers: headers, responseType: responseType),
      );

      return response.data;
    } on DioException catch (dioException) {
      final exception = _handleDioException(dioException);

      throwDioException
          ? throw exception
          : throw exception.message ?? S.current.httpException;
    }
  }
}
