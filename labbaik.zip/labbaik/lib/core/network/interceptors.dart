import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:firebase_crashlytics/firebase_crashlytics.dart'
    show FirebaseCrashlytics;
import 'package:firebase_database/firebase_database.dart' show FirebaseDatabase;
import 'package:intl/intl.dart';
import 'package:labbaik/core/utilities/extensions.dart';
import 'status_code.dart';
import '../../generated/l10n.dart';
import '../utilities/custom_logger.dart';

class AuthorizationInterceptor extends Interceptor {
  AuthorizationInterceptor({String? token}) : _token = token;

  final String? _token;

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    if (_token != null) {
      options.headers['Authorization'] = "Bearer $_token";
    }

    // Enhanced request logging with more detailed information
    CustomLogger.instance.info(
      "\n\t🚀 OnRequest [${options.method.toUpperCase()}]"
      "\n\t\t📍 URL: ${options.uri.toString()}"
      "\n\t\t🔍 Query Parameters: ${options.queryParameters.isNotEmpty ? options.queryParameters : 'None'}"
      "\n\t\t📋 Headers: ${options.headers}"
      "\n\t\t📦 Request Body: ${options.data ?? 'No body'}"
      "\n\t\t📏 Content Type: ${options.contentType}"
      "\n\t\t⏱️  Timeout: ${options.connectTimeout}ms"
      "\n\t\t🔄 Follow Redirects: ${options.followRedirects}\n",
    );

    return handler.next(options);
  }

  @override
  Future<void> onError(
    DioException err,
    ErrorInterceptorHandler handler,
  ) async {
    final statusCode = ServerStatusCode.fromNullableInt(
      err.response?.statusCode,
    );

    if (statusCode == ServerStatusCode.unAuthorized) {
      await _logUserOutAndDeleteToken();
      return handler.next(err.copyWith(message: S.current.unAuthorized));
    }

    return handler.next(err);
  }

  Future<void> _logUserOutAndDeleteToken() async {
    // await NavigationService.navigatorKey.currentContext?.read<AuthCubit>().logout();
    // log it in realtime database
    final log = {
      'message': 'User logged out',
      'timestamp': FieldValue.serverTimestamp(),
    };
    // realtime database
    final logRef = FirebaseDatabase.instance.ref('logout/logs');
    await logRef.push().set(log);
  }
}

class LocaleInterceptor extends Interceptor {
  String? languageCode;

  LocaleInterceptor({this.languageCode});

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    languageCode ??= Intl.getCurrentLocale();
    options.headers['lang'] = languageCode?.capitalized ?? "En";

    CustomLogger.instance.info(
      "\n\tNew locale applied"
      "\n\t\tlanguageCode: $languageCode",
    );

    handler.next(options);
  }
}

class ResponseInterceptor extends Interceptor {
  final _logger = CustomLogger.instance;

  @override
  void onResponse(Response response, ResponseInterceptorHandler handler) {
    // Calculate response time if available
    final responseTime = response.extra['response_time'] as Duration?;
    final responseTimeStr = responseTime != null
        ? '${responseTime.inMilliseconds}ms'
        : 'Unknown';

    _logger.success(
      "\n\t✅ OnResponse [${response.requestOptions.method.toUpperCase()}]"
      "\n\t\t📍 URL: ${response.realUri.toString()}"
      "\n\t\t🔍 Query Parameters: ${response.requestOptions.queryParameters.isNotEmpty ? response.requestOptions.queryParameters : 'None'}"
      "\n\t\t📊 Status Code: ${response.statusCode}"
      "\n\t\t📋 Response Headers: ${response.headers}"
      "\n\t\t📦 Response Data: ${response.data}"
      "\n\t\t📏 Content Type: ${response.headers['content-type'] ?? 'Unknown'}"
      "\n\t\t⏱️  Response Time: $responseTimeStr"
      "\n\t\t📐 Data Size: ${response.data.toString().length} characters\n",
    );

    final eitherResponseOrException = _validateResponseOrThrowException(
      response,
    );

    eitherResponseOrException.fold(
      (dioException) => handler.reject(dioException, true),
      (response) => handler.resolve(response),
    );
  }
}

class ErrorInterceptor extends Interceptor {
  ErrorInterceptor();

  @override
  Future<void> onError(
    DioException err,
    ErrorInterceptorHandler handler,
  ) async {
    try {
      FirebaseCrashlytics.instance.recordError(
        "FROM OnError [${err.requestOptions.method.toUpperCase()}] ${err.requestOptions.uri.path}"
        "\n\t\tURL: ${err.requestOptions.uri.toString()}"
        "\n\t\tRequest Body: ${err.requestOptions.data ?? 'No body'}"
        "\n\t\tRequest Headers: ${err.requestOptions.headers}"
        "\n\t\tError Type: ${err.type.name}"
        "\n\t\tStatus Code: ${err.response?.statusCode ?? 'No response'}"
        "\n\t\tMessage: ${err.message}"
        "\n\t\tResponse Headers: ${err.response?.headers}"
        "\n\t\tResponse Data: ${err.response?.data}"
        "\n\t\tStack Trace: ${err.stackTrace}\n",
        err.stackTrace,
        fatal: true,
        information: [
          "FROM OnError [${err.requestOptions.method.toUpperCase()}] ${err.requestOptions.uri.path}"
              "\n\t\tURL: ${err.requestOptions.uri.toString()}"
              "\n\t\tRequest Body: ${err.requestOptions.data ?? 'No body'}"
              "\n\t\tRequest Headers: ${err.requestOptions.headers}"
              "\n\t\tError Type: ${err.type.name}"
              "\n\t\tStatus Code: ${err.response?.statusCode ?? 'No response'}"
              "\n\t\tMessage: ${err.message}"
              "\n\t\tResponse Headers: ${err.response?.headers}"
              "\n\t\tResponse Data: ${err.response?.data}"
              "\n\t\tStack Trace: ${err.stackTrace}\n",
        ],
      );
    } catch (e) {
      CustomLogger.instance.error("Error in ErrorInterceptor: $e");
    }
    CustomLogger.instance.error(
      "\n\t❌ OnError [${err.requestOptions.method.toUpperCase()}]"
      "\n\t\t📍 URL: ${err.requestOptions.uri.toString()}"
      "\n\t\t🔍 Query Parameters: ${err.requestOptions.queryParameters.isNotEmpty ? err.requestOptions.queryParameters : 'None'}"
      "\n\t\t📦 Request Body: ${err.requestOptions.data ?? 'No body'}"
      "\n\t\t📋 Request Headers: ${err.requestOptions.headers}"
      "\n\t\t🚨 Error Type: ${err.type.name}"
      "\n\t\t📊 Status Code: ${err.response?.statusCode ?? 'No response'}"
      "\n\t\t💬 Error Message: ${err.message}"
      "\n\t\t📋 Response Headers: ${err.response?.headers ?? 'No response headers'}"
      "\n\t\t📦 Response Data: ${err.response?.data ?? 'No response data'}\n",
    );

    // If is an error from the server, we won't know any info about it
    // due to browser security policies, so we will handle it as a connection error
    // If the error is a connection error and the status code is null,
    if (err.type == DioExceptionType.connectionError &&
        err.response?.statusCode == null) {
      err = err.copyWith(
        type: DioExceptionType.unknown,
        response: Response(
          data: err.response?.data,
          requestOptions: err.requestOptions,
          statusCode: ServerStatusCode.serverDown.statusCode,
        ),
      );
    }

    if (err.type == DioExceptionType.badResponse) {
      handler.next(err.copyWith(message: S.current.httpException));
      return;
    } else {
      final serverStatusCode = ServerStatusCode.fromNullableInt(
        err.response?.statusCode,
      );

      switch (serverStatusCode) {
        case ServerStatusCode.badRequest:
          handler.next(
            err.copyWith(
              message: err.response?.data['errors']?.isNotEmpty ?? false
                  ? err.response?.data['errors']
                        .map((e) => e.message)
                        .join(", ")
                  : S.current.badRequestException,
            ),
          );
          break;
        case ServerStatusCode.systemUnderMaintenance:
          handler.next(
            err.copyWith(message: S.current.underMaintenanceException),
          );
          break;
        case ServerStatusCode.serverDown:
          handler.next(err.copyWith(message: S.current.httpException));
          break;
        case ServerStatusCode.forbidden:
          handler.next(err.copyWith(message: S.current.forbiddenException));
          break;
        case ServerStatusCode.tooManyRequests:
          handler.next(
            err.copyWith(message: S.current.tooManyRequestsException),
          );
          break;
        case ServerStatusCode.someResourcesAreDown:
          handler.next(err.copyWith(message: S.current.badRequestException));
          break;
        default:
          handler.next(err);
          break;
      }
    }
  }
}

Either<DioException, Response> _validateResponseOrThrowException(
  Response response,
) {
  final serverStatusCode = response.statusCode ?? -1;
  final responseType = response.requestOptions.responseType;
  final bool isJsonResponse = response.data is Map;

  ResponseStatusCode? responseStatusCodeOrNull;

  if (responseType == ResponseType.json && isJsonResponse) {
    responseStatusCodeOrNull = ResponseStatusCode.fromNullableString(
      response.data['statusCode'],
    );
  }

  // Update the status code based on the response status code.
  // As browser security policies prevent us from accessing the response status code
  // in case of a CORS error or other network errors.
  if (responseStatusCodeOrNull == ResponseStatusCode.systemUnderMaintenance) {
    response.statusCode = ServerStatusCode.systemUnderMaintenance.statusCode;
  }

  if (serverStatusCode >= 200 && serverStatusCode < 300) {
    if (responseType == ResponseType.json && isJsonResponse) {
      // If response has a statusCode field, validate it
      if (response.data.containsKey('statusCode')) {
        if (responseStatusCodeOrNull == ResponseStatusCode.success) {
          return Right(response);
        } else {
          // Update the status code based on the response status code.
          response.statusCode = int.tryParse(
            response.data['statusCode'].toString(),
          );

          return Left(
            DioException(
              requestOptions: response.requestOptions,
              type: DioExceptionType.unknown,
              response: response,
              message:
                  responseStatusCodeOrNull?.message ?? response.data['message'],
            ),
          );
        }
      } else {
        // If no statusCode field is present but HTTP status is successful, treat as success
        return Right(response);
      }
    } else {
      return Right(response);
    }
  }

  return Left(
    DioException(
      requestOptions: response.requestOptions,
      type: DioExceptionType.unknown,
      response: response,
      message:
          responseStatusCodeOrNull?.message ??
          response.data['message'] ??
          S.current.httpException,
    ),
  );
}
