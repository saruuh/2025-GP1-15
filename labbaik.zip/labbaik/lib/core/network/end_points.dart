const LOGIN = "UsersAuth/login";
const USER = "allemp/37500";
const HOSPITAL = "allemp/hos/1";
const DISTINATION = "maps/api/directions/json";
const GOOGLEAPLKEY = "AIzaSyBpcVxhnVXK_Dt0UdYA6Y_hRgKOFwUyZtI";
