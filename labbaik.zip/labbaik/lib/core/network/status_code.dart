import '../../generated/l10n.dart';

enum ServerStatusCode {
  unKnown(null),
  badRequest(400),
  unAuthorized(401),
  forbidden(403),
  notFound(404),
  someResourcesAreDown(409),
  tooManyRequests(429),
  serverDown(500),
  systemUnderMaintenance(503);

  const ServerStatusCode(this.statusCode);

  final int? statusCode;

  factory ServerStatusCode.fromNullableInt(int? nullableInt) =>
      switch (nullableInt) {
        400 => ServerStatusCode.badRequest,
        503 => ServerStatusCode.systemUnderMaintenance,
        500 => ServerStatusCode.serverDown,
        429 => ServerStatusCode.tooManyRequests,
        409 => ServerStatusCode.someResourcesAreDown,
        404 => ServerStatusCode.notFound,
        403 => ServerStatusCode.forbidden,
        401 => ServerStatusCode.unAuthorized,
        _ => ServerStatusCode.unKnown,
      };
}

enum ResponseStatusCode {
  unKnown(null),
  success("SUCCESS"),
  mutabbibAPIRequestFailed("MUTABBIB_API_REQUEST_FAILED"),
  someResourcesAreDown("SOME_RESOURCES_ARE_DOWN"),
  unAuthorized("UNAUTHORIZED"),
  systemUnderMaintenance("SYSTEM_UNDER_MAINTENANCE"),
  tooManyRequests("TOO_MANY_REQUESTS");

  const ResponseStatusCode(this.statusCode);

  final String? statusCode;

  factory ResponseStatusCode.fromNullableString(String? nullableStr) =>
      switch (nullableStr) {
        "SUCCESS" || "OK" => ResponseStatusCode.success,
        "TOO_MANY_REQUESTS" => ResponseStatusCode.tooManyRequests,
        "SYSTEM_UNDER_MAINTENANCE" => ResponseStatusCode.systemUnderMaintenance,
        "UNAUTHORIZED" => ResponseStatusCode.unAuthorized,
        "SOME_RESOURCES_ARE_DOWN" => ResponseStatusCode.someResourcesAreDown,
        "MUTABBIB_API_REQUEST_FAILED" =>
          ResponseStatusCode.mutabbibAPIRequestFailed,
        _ => ResponseStatusCode.unKnown,
      };

  String? get message => switch (this) {
        ResponseStatusCode.success => S.current.success,
        ResponseStatusCode.mutabbibAPIRequestFailed ||
        ResponseStatusCode.someResourcesAreDown =>
          S.current.badRequestException,
        ResponseStatusCode.unAuthorized => S.current.unAuthorized,
        ResponseStatusCode.systemUnderMaintenance =>
          S.current.underMaintenanceException,
        ResponseStatusCode.tooManyRequests =>
          S.current.tooManyRequestsException,
        ResponseStatusCode.unKnown => null,
      };
}
