import 'package:image_picker/image_picker.dart';
import 'package:labbaik/core/utilities/custom_logger.dart' show CustomLogger;

class MediaPickerService {
  final ImagePicker _picker = ImagePicker();

  // Capture an image or video using the camera
  Future<XFile?> captureFromCamera({required bool isVideo}) async {
    try {
      if (isVideo) {
        return await _picker.pickVideo(source: ImageSource.camera);
      } else {
        return await _picker.pickImage(source: ImageSource.camera);
      }
    } catch (e) {
      CustomLogger.instance.error("Error capturing media from camera: $e");
      return null;
    }
  }

  // Pick multiple images or a video from the gallery
  Future<List<XFile>?> pickFromGallery({required bool? isVideo}) async {
    try {
      if (isVideo == true) {
        final XFile? video = await _picker.pickVideo(
          source: ImageSource.gallery,
        );
        if (video != null) {
          return [video];
        }
      }
      if (isVideo == false) {
        return await _picker.pickMultiImage();
      } else {
        return await _picker.pickMultipleMedia();
      }
    } catch (e) {
      CustomLogger.instance.error("Error picking media from gallery: $e");
      return null;
    }
  }
}
