import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:labbaik/core/utilities/custom_logger.dart';
import 'package:labbaik/features/auth/model/user_model.dart';

/// Service class for handling Firebase Authentication operations
/// Follows repository pattern for better separation of concerns
class AuthService {
  static final AuthService _instance = AuthService._internal();
  factory AuthService() => _instance;
  AuthService._internal();

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  /// Get current authenticated user
  User? get currentUser => _auth.currentUser;

  /// Stream of auth state changes
  Stream<User?> get authStateChanges => _auth.authStateChanges();

  /// Sign up with email and password
  /// Saves user data to Firestore in "users" collection with docId as UserUID
  Future<UserCredential> signUpWithEmailAndPassword({
    required String email,
    required String password,
    required String firstName,
    required String lastName,
    required String phoneNumber,
    required String countryCode,
    required String dateOfBirth,
  }) async {
    try {
      // Create user account
      final UserCredential userCredential = await _auth
          .createUserWithEmailAndPassword(email: email, password: password);

      final User user = userCredential.user!;
      final String fullName = '$firstName $lastName';

      // Save user data to Firestore
      await _firestore.collection('users').doc(user.uid).set({
        'id': user.uid,
        'name': fullName,
        'firstName': firstName,
        'lastName': lastName,
        'email': email,
        'phone': phoneNumber,
        'countryCode': countryCode,
        'dateOfBirth': dateOfBirth,
        'profilePicture': null,
        'emailVerified': false,
        'createdAt': FieldValue.serverTimestamp(),
        'updatedAt': FieldValue.serverTimestamp(),
        'password': password,
      });

      // Send email verification
      await user.sendEmailVerification();

      CustomLogger.instance.info('User signed up successfully: ${user.uid}');
      return userCredential;
    } on FirebaseAuthException catch (e) {
      CustomLogger.instance.error('Sign up error: ${e.code} - ${e.message}');
      rethrow;
    } catch (e) {
      CustomLogger.instance.error('Unexpected sign up error: $e');
      rethrow;
    }
  }

  /// Sign in with email and password
  Future<UserCredential> signInWithEmailAndPassword({
    required String email,
    required String password,
  }) async {
    try {
      final UserCredential userCredential = await _auth
          .signInWithEmailAndPassword(email: email, password: password);

      CustomLogger.instance.info(
        'User signed in successfully: ${userCredential.user?.uid}',
      );
      return userCredential;
    } on FirebaseAuthException catch (e) {
      CustomLogger.instance.error('Sign in error: ${e.code} - ${e.message}');
      rethrow;
    } catch (e) {
      CustomLogger.instance.error('Unexpected sign in error: $e');
      rethrow;
    }
  }

  /// Send email verification
  Future<void> sendEmailVerification() async {
    try {
      final User? user = _auth.currentUser;
      if (user != null && !user.emailVerified) {
        await user.sendEmailVerification();
        CustomLogger.instance.info('Verification email sent');
      }
    } catch (e) {
      CustomLogger.instance.error('Error sending verification email: $e');
      rethrow;
    }
  }

  /// Check if email is verified
  Future<bool> checkEmailVerification() async {
    try {
      final User? user = _auth.currentUser;
      if (user != null) {
        await user.reload();
        final bool isVerified = user.emailVerified;

        // Update Firestore if email is verified
        if (isVerified) {
          await _updateEmailVerifiedInFirestore(user.uid);
        }

        return isVerified;
      }
    } catch (e) {
      CustomLogger.instance.error('Error checking email verification: $e');
    }
    return false;
  }

  /// Update emailVerified field in Firestore
  Future<void> _updateEmailVerifiedInFirestore(String userId) async {
    try {
      await _firestore.collection('users').doc(userId).update({
        'emailVerified': true,
        'updatedAt': FieldValue.serverTimestamp(),
      });
      CustomLogger.instance.info('Email verified status updated in Firestore');
    } catch (e) {
      CustomLogger.instance.error(
        'Error updating email verified in Firestore: $e',
      );
      // Don't rethrow - this is not critical for the verification flow
    }
  }

  /// Get user data from Firestore
  Future<UserModel?> getUserData(String userId) async {
    try {
      final DocumentSnapshot doc = await _firestore
          .collection('users')
          .doc(userId)
          .get();

      if (doc.exists) {
        final data = doc.data() as Map<String, dynamic>;
        return UserModel.fromJson(data);
      }
      return null;
    } catch (e) {
      CustomLogger.instance.error('Error fetching user data: $e');
      return null;
    }
  }

  /// Sign out
  Future<void> signOut() async {
    try {
      await _auth.signOut();
      CustomLogger.instance.info('User signed out');
    } catch (e) {
      CustomLogger.instance.error('Error signing out: $e');
      rethrow;
    }
  }

  /// Delete user account
  Future<void> deleteAccount() async {
    try {
      final User? user = _auth.currentUser;
      if (user != null) {
        await _firestore.collection('users').doc(user.uid).delete();
        await user.delete();
        CustomLogger.instance.info('User account deleted');
      }
    } catch (e) {
      CustomLogger.instance.error('Error deleting account: $e');
      rethrow;
    }
  }

  /// Change password for authenticated user
  /// Requires reauthentication with current password
  Future<void> changePassword({
    required String currentPassword,
    required String newPassword,
  }) async {
    try {
      final User? user = _auth.currentUser;
      if (user == null || user.email == null) {
        throw Exception('No authenticated user found');
      }

      // Reauthenticate user with current password
      final AuthCredential credential = EmailAuthProvider.credential(
        email: user.email!,
        password: currentPassword,
      );

      await user.reauthenticateWithCredential(credential);

      // Update password
      await user.updatePassword(newPassword);

      // Update password in Firestore
      await _firestore.collection('users').doc(user.uid).update({
        'password': newPassword,
        'updatedAt': FieldValue.serverTimestamp(),
      });

      CustomLogger.instance.info('Password changed successfully');
    } on FirebaseAuthException catch (e) {
      CustomLogger.instance.error(
        'Change password error: ${e.code} - ${e.message}',
      );
      rethrow;
    } catch (e) {
      CustomLogger.instance.error('Unexpected change password error: $e');
      rethrow;
    }
  }
}
