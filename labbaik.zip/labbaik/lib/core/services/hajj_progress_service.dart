import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:labbaik/core/services/auth_service.dart';
import 'package:labbaik/core/utilities/custom_logger.dart';

/// Service for managing Hajj progress in Firebase
class HajjProgressService {
  static final HajjProgressService _instance = HajjProgressService._internal();
  factory HajjProgressService() => _instance;
  HajjProgressService._internal();

  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final AuthService _authService = AuthService();

  /// Collection name for Hajj progress
  static const String _collectionName = 'hajj_progress';

  /// Get current user ID
  String? get _userId => _authService.currentUser?.uid;

  /// Check if user is authenticated
  bool get isAuthenticated => _userId != null;

  /// Fetch user's Hajj progress from Firebase
  Future<Map<String, bool>> fetchProgress() async {
    if (!isAuthenticated) {
      CustomLogger.instance.warning(
        'User not authenticated, returning empty progress',
      );
      return {};
    }

    try {
      final doc = await _firestore
          .collection(_collectionName)
          .doc(_userId)
          .get();

      if (doc.exists && doc.data() != null) {
        final data = doc.data()!;
        final progress = data['completedSteps'] as Map<String, dynamic>? ?? {};

        // Convert dynamic values to bool
        final Map<String, bool> result = {};
        progress.forEach((key, value) {
          if (value is bool) {
            result[key] = value;
          }
        });

        CustomLogger.instance.info('Fetched Hajj progress for user: $_userId');
        return result;
      }

      CustomLogger.instance.info('No Hajj progress found for user: $_userId');
      return {};
    } catch (e) {
      CustomLogger.instance.error('Error fetching Hajj progress: $e');
      return {};
    }
  }

  /// Save user's Hajj progress to Firebase
  Future<void> saveProgress(Map<String, bool> completedSteps) async {
    if (!isAuthenticated) {
      CustomLogger.instance.warning(
        'User not authenticated, cannot save progress',
      );
      return;
    }

    try {
      await _firestore.collection(_collectionName).doc(_userId).set({
        'completedSteps': completedSteps,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      CustomLogger.instance.info('Hajj progress saved for user: $_userId');
    } catch (e) {
      CustomLogger.instance.error('Error saving Hajj progress: $e');
      rethrow;
    }
  }

  /// Mark a step as completed
  Future<void> markStepCompleted(int dayNumber, int stepNumber) async {
    if (!isAuthenticated) {
      CustomLogger.instance.warning(
        'User not authenticated, cannot mark step completed',
      );
      return;
    }

    try {
      final currentProgress = await fetchProgress();
      final key = '${dayNumber}_$stepNumber';
      currentProgress[key] = true;
      await saveProgress(currentProgress);
      CustomLogger.instance.info('Hajj Step $key marked as completed');
    } catch (e) {
      CustomLogger.instance.error('Error marking Hajj step completed: $e');
      rethrow;
    }
  }

  /// Reset all progress
  Future<void> resetProgress() async {
    if (!isAuthenticated) {
      CustomLogger.instance.warning(
        'User not authenticated, cannot reset progress',
      );
      return;
    }

    try {
      await _firestore.collection(_collectionName).doc(_userId).set({
        'completedSteps': <String, bool>{},
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      CustomLogger.instance.info('Hajj progress reset for user: $_userId');
    } catch (e) {
      CustomLogger.instance.error('Error resetting Hajj progress: $e');
      rethrow;
    }
  }

  /// Fetch dialog preference
  Future<bool> fetchDialogPreference() async {
    if (!isAuthenticated) {
      CustomLogger.instance.warning(
        'User not authenticated, returning default dialog preference',
      );
      return true;
    }

    try {
      final doc = await _firestore
          .collection(_collectionName)
          .doc(_userId)
          .get();

      if (doc.exists && doc.data() != null) {
        final val = doc.data()!['showCompletionDialog'] as bool? ?? true;
        CustomLogger.instance.info('Fetched dialog preference: $val');
        return val;
      }
      CustomLogger.instance.info('No dialog preference found, returning true');
      return true;
    } catch (e) {
      CustomLogger.instance.error('Error fetching dialog preference: $e');
      return true;
    }
  }

  /// Save dialog preference
  Future<void> saveDialogPreference(bool show) async {
    if (!isAuthenticated) {
      CustomLogger.instance.warning(
        'User not authenticated, cannot save dialog preference',
      );
      return;
    }

    try {
      CustomLogger.instance.info('Saving dialog preference: $show');
      await _firestore.collection(_collectionName).doc(_userId).set({
        'showCompletionDialog': show,
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
      CustomLogger.instance.info('Dialog preference saved');
    } catch (e) {
      CustomLogger.instance.error('Error saving dialog preference: $e');
    }
  }
}
