import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../generated/l10n.dart';

class LocaleService extends ChangeNotifier {
  static const String _localeKey = 'language';
  static LocaleService? _instance;

  static LocaleService get instance {
    _instance ??= LocaleService._();
    return _instance!;
  }

  LocaleService._();

  Locale _locale = const Locale('en');

  Locale get locale => _locale;

  bool get isArabic => _locale.languageCode == 'ar';
  bool get isEnglish => _locale.languageCode == 'en';

  /// Initialize locale from saved preferences
  Future<void> init() async {
    final prefs = await SharedPreferences.getInstance();
    final savedLocale = prefs.getString(_localeKey);

    if (savedLocale != null && (savedLocale == 'ar' || savedLocale == 'en')) {
      _locale = Locale(savedLocale);
      await S.load(_locale);
    } else {
      // Default to English if no saved locale
      _locale = const Locale('en');
      await S.load(_locale);
    }
    notifyListeners();
  }

  /// Set locale and save to preferences
  Future<void> setLocale(Locale locale) async {
    if (locale.languageCode != 'ar' && locale.languageCode != 'en') {
      return; // Only support ar and en
    }

    _locale = locale;
    await S.load(locale);
    notifyListeners();

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_localeKey, locale.languageCode);
  }

  /// Toggle between Arabic and English
  Future<void> toggleLanguage(bool isArabic) async {
    final newLocale = isArabic ? const Locale('ar') : const Locale('en');
    await setLocale(newLocale);
  }
}




