import 'package:flutter/material.dart';

import '../services/theme_service.dart';
import '../utilities/color_util.dart';
import '../resources/app_styles.dart';

class ThemeToggleWidget extends StatefulWidget {
  final bool showLabel;
  final bool showSystemOption;
  final ThemeService themeService;

  const ThemeToggleWidget({
    super.key,
    required this.themeService,
    this.showLabel = true,
    this.showSystemOption = true,
  });

  @override
  State<ThemeToggleWidget> createState() => _ThemeToggleWidgetState();
}

class _ThemeToggleWidgetState extends State<ThemeToggleWidget> {
  @override
  void initState() {
    super.initState();
    widget.themeService.addListener(_onThemeChanged);
  }

  @override
  void dispose() {
    widget.themeService.removeListener(_onThemeChanged);
    super.dispose();
  }

  void _onThemeChanged() {
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        if (widget.showLabel)
          Padding(
            padding: const EdgeInsets.only(bottom: 8.0),
            child: Text(
              'Theme Mode',
              style: getMediumStyle(
                color:
                    Theme.of(context).textTheme.titleMedium?.color ??
                    ColorUtil.darkGrey,
                fontSize: 16,
              ),
            ),
          ),
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Theme.of(context).dividerColor, width: 1),
          ),
          child: Column(
            children: [
              _buildThemeOption(
                context,
                widget.themeService,
                ThemeMode.light,
                'Light Mode',
                Icons.light_mode,
              ),
              Divider(height: 1, color: Theme.of(context).dividerColor),
              _buildThemeOption(
                context,
                widget.themeService,
                ThemeMode.dark,
                'Dark Mode',
                Icons.dark_mode,
              ),
              if (widget.showSystemOption) ...[
                Divider(height: 1, color: Theme.of(context).dividerColor),
                _buildThemeOption(
                  context,
                  widget.themeService,
                  ThemeMode.system,
                  'System Default',
                  Icons.settings_system_daydream,
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildThemeOption(
    BuildContext context,
    ThemeService themeService,
    ThemeMode mode,
    String title,
    IconData icon,
  ) {
    final isSelected = themeService.themeMode == mode;

    return ListTile(
      leading: Icon(
        icon,
        color: isSelected
            ? ColorUtil.primaryColor
            : Theme.of(context).iconTheme.color,
      ),
      title: Text(
        title,
        style: getRegularStyle(
          color: isSelected
              ? ColorUtil.primaryColor
              : Theme.of(context).textTheme.bodyLarge?.color ??
                    ColorUtil.darkGrey,
          fontSize: 14,
        ),
      ),
      trailing: isSelected
          ? Icon(Icons.check_circle, color: ColorUtil.primaryColor)
          : null,
      onTap: () => themeService.setThemeMode(mode),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    );
  }
}

class ThemeToggleButton extends StatefulWidget {
  final ThemeService themeService;

  const ThemeToggleButton({super.key, required this.themeService});

  @override
  State<ThemeToggleButton> createState() => _ThemeToggleButtonState();
}

class _ThemeToggleButtonState extends State<ThemeToggleButton> {
  @override
  void initState() {
    super.initState();
    widget.themeService.addListener(_onThemeChanged);
  }

  @override
  void dispose() {
    widget.themeService.removeListener(_onThemeChanged);
    super.dispose();
  }

  void _onThemeChanged() {
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return IconButton(
      icon: Icon(
        widget.themeService.isDarkMode ? Icons.light_mode : Icons.dark_mode,
      ),
      onPressed: () => widget.themeService.toggleTheme(),
      tooltip: widget.themeService.isDarkMode
          ? 'Switch to Light Mode'
          : 'Switch to Dark Mode',
    );
  }
}

class ThemeCycleButton extends StatefulWidget {
  final ThemeService themeService;

  const ThemeCycleButton({super.key, required this.themeService});

  @override
  State<ThemeCycleButton> createState() => _ThemeCycleButtonState();
}

class _ThemeCycleButtonState extends State<ThemeCycleButton> {
  @override
  void initState() {
    super.initState();
    widget.themeService.addListener(_onThemeChanged);
  }

  @override
  void dispose() {
    widget.themeService.removeListener(_onThemeChanged);
    super.dispose();
  }

  void _onThemeChanged() {
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    IconData icon;
    String tooltip;

    switch (widget.themeService.themeMode) {
      case ThemeMode.light:
        icon = Icons.light_mode;
        tooltip = 'Light Mode (tap to switch to Dark)';
        break;
      case ThemeMode.dark:
        icon = Icons.dark_mode;
        tooltip = 'Dark Mode (tap to switch to System)';
        break;
      case ThemeMode.system:
        icon = Icons.settings_system_daydream;
        tooltip = 'System Mode (tap to switch to Light)';
        break;
    }

    return IconButton(
      icon: Icon(icon),
      onPressed: () => widget.themeService.cycleTheme(),
      tooltip: tooltip,
    );
  }
}
