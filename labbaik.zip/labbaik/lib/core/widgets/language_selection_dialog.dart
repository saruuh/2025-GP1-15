import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:labbaik/core/utilities/color_util.dart';
import 'package:labbaik/generated/l10n.dart';
import 'package:labbaik/core/services/locale_service.dart';

/// Language selection dialog
/// Allows users to switch between English and Arabic
class LanguageSelectionDialog extends StatelessWidget {
  const LanguageSelectionDialog({super.key});

  static Future<void> show(BuildContext context) {
    return showDialog(
      context: context,
      builder: (context) => const LanguageSelectionDialog(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final localeService = LocaleService.instance;
    final currentLanguage = localeService.locale.languageCode;

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20).r),
      child: Container(
        padding: EdgeInsets.all(24).r,
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(20).r,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Title
            Text(
              S.of(context).appLanguage,
              style: TextStyle(
                fontSize: 18.sp,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).textTheme.headlineLarge?.color,
              ),
            ),
            20.verticalSpace,

            // English Option
            _LanguageOption(
              language: 'en',
              title: S.of(context).english,
              isSelected: currentLanguage == 'en',
              onTap: () async {
                await localeService.setLocale(const Locale('en'));
                if (context.mounted) {
                  Navigator.of(context).pop();
                }
              },
            ),

            12.verticalSpace,

            // Arabic Option
            _LanguageOption(
              language: 'ar',
              title: S.of(context).arabic,
              isSelected: currentLanguage == 'ar',
              onTap: () async {
                await localeService.setLocale(const Locale('ar'));
                if (context.mounted) {
                  Navigator.of(context).pop();
                }
              },
            ),

            20.verticalSpace,

            // Cancel Button
            Align(
              alignment: Alignment.centerRight,
              child: TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text(
                  S.of(context).cancel,
                  style: TextStyle(
                    fontSize: 14.sp,
                    color: ColorUtil.primaryColor,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LanguageOption extends StatelessWidget {
  final String language;
  final String title;
  final bool isSelected;
  final VoidCallback onTap;

  const _LanguageOption({
    required this.language,
    required this.title,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12).r,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12).r,
        decoration: BoxDecoration(
          color: isSelected
              ? ColorUtil.primaryColor.withValues(alpha: 0.1)
              : Theme.of(context).brightness == Brightness.dark
              ? DarkThemeColors.card
              : Colors.grey[50],
          borderRadius: BorderRadius.circular(12).r,
          border: Border.all(
            color: isSelected
                ? ColorUtil.primaryColor
                : Colors.grey.withValues(alpha: 0.2),
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            Icon(
              isSelected ? Icons.radio_button_checked : Icons.radio_button_off,
              color: isSelected ? ColorUtil.primaryColor : Colors.grey,
              size: 24.spMin,
            ),
            16.horizontalSpace,
            Expanded(
              child: Text(
                title,
                style: TextStyle(
                  fontSize: 16.sp,
                  fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                  color: isSelected
                      ? ColorUtil.primaryColor
                      : Theme.of(context).textTheme.bodyLarge?.color,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
