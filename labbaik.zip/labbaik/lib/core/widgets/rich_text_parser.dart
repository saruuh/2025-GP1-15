import 'package:flutter/material.dart';
import 'package:labbaik/core/utilities/color_util.dart';

/// A widget that parses markdown-like syntax and renders rich text
///
/// Supports:
/// - `**text**` for bold text
/// - `<red>text</red>` for red colored text
/// - `<gold>text</gold>` for gold/brown colored text
/// - Nested formatting (e.g., `**<red>text</red>**`)
class RichTextParser extends StatelessWidget {
  final String text;
  final TextStyle? defaultStyle;
  final TextAlign? textAlign;
  final int? maxLines;
  final TextOverflow? overflow;

  const RichTextParser({
    super.key,
    required this.text,
    this.defaultStyle,
    this.textAlign,
    this.maxLines,
    this.overflow,
  });

  @override
  Widget build(BuildContext context) {
    final defaultTextStyle =
        defaultStyle ??
        Theme.of(context).textTheme.bodyMedium ??
        const TextStyle();

    final textSpans = _parseText(text, defaultTextStyle);

    return Text.rich(
      TextSpan(children: textSpans),
      style: defaultTextStyle,
      textAlign: textAlign,
      maxLines: maxLines,
      overflow: overflow,
    );
  }

  /// Parses the text and returns a list of TextSpan objects
  /// Handles both bold markers (**text**) and color tags (<red>text</red>)
  List<TextSpan> _parseText(String text, TextStyle defaultStyle) {
    if (text.isEmpty) {
      return [TextSpan(text: '', style: defaultStyle)];
    }

    final List<TextSpan> spans = [];
    int currentIndex = 0;

    while (currentIndex < text.length) {
      // Find the next formatting marker (bold or color tag)
      final boldStart = text.indexOf('**', currentIndex);
      final tagStart = text.indexOf('<', currentIndex);

      // Determine which marker comes first
      int? nextMarkerIndex;
      bool isBold = false;

      if (boldStart != -1 && tagStart != -1) {
        if (boldStart < tagStart) {
          nextMarkerIndex = boldStart;
          isBold = true;
        } else {
          nextMarkerIndex = tagStart;
          isBold = false;
        }
      } else if (boldStart != -1) {
        nextMarkerIndex = boldStart;
        isBold = true;
      } else if (tagStart != -1) {
        nextMarkerIndex = tagStart;
        isBold = false;
      }

      if (nextMarkerIndex != null) {
        // Add text before the marker
        if (nextMarkerIndex > currentIndex) {
          spans.add(
            TextSpan(
              text: text.substring(currentIndex, nextMarkerIndex),
              style: defaultStyle,
            ),
          );
        }

        if (isBold) {
          // Handle bold: **text**
          final boldEnd = text.indexOf('**', boldStart + 2);
          if (boldEnd != -1) {
            final boldText = text.substring(boldStart + 2, boldEnd);
            // Recursively parse nested formatting (colors, nested bold)
            spans.addAll(
              _parseText(
                boldText,
                defaultStyle.copyWith(fontWeight: FontWeight.bold),
              ),
            );
            currentIndex = boldEnd + 2;
          } else {
            // No closing **, treat as regular text
            spans.add(
              TextSpan(text: text.substring(boldStart), style: defaultStyle),
            );
            break;
          }
        } else {
          // Handle color tag: <red>text</red> or <gold>text</gold>
          final tagEnd = text.indexOf('>', tagStart);
          if (tagEnd != -1) {
            final tagName = text.substring(tagStart + 1, tagEnd);
            final closingTag = '</$tagName>';
            final closingTagIndex = text.indexOf(closingTag, tagEnd + 1);

            if (closingTagIndex != -1) {
              // Found closing tag
              final tagContent = text.substring(tagEnd + 1, closingTagIndex);
              final color = _getColorForTag(tagName);

              // Recursively parse nested formatting (bold, nested color tags)
              spans.addAll(
                _parseText(tagContent, defaultStyle.copyWith(color: color)),
              );
              currentIndex = closingTagIndex + closingTag.length;
            } else {
              // No closing tag, treat as regular text
              spans.add(
                TextSpan(text: text.substring(tagStart), style: defaultStyle),
              );
              break;
            }
          } else {
            // Malformed tag, treat as regular text
            spans.add(
              TextSpan(text: text.substring(tagStart), style: defaultStyle),
            );
            break;
          }
        }
      } else {
        // No more markers, add remaining text
        spans.add(
          TextSpan(text: text.substring(currentIndex), style: defaultStyle),
        );
        break;
      }
    }

    return spans.isEmpty ? [TextSpan(text: text, style: defaultStyle)] : spans;
  }

  /// Returns the color for a given tag name
  Color _getColorForTag(String tagName) {
    switch (tagName.toLowerCase()) {
      case 'red':
        return ColorUtil.errorColor;
      case 'green':
        return ColorUtil.primaryColor;
      case 'gold':
        return ColorUtil.accentColor; // Gold color from ColorUtil
      default:
        // Unknown tag, return default color (will be overridden by style)
        return Colors.black;
    }
  }
}
