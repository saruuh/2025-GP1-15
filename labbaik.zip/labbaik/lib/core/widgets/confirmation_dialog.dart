import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:labbaik/core/utilities/color_util.dart';
import 'package:labbaik/core/utilities/extensions.dart';
import 'package:labbaik/generated/l10n.dart';

import '../../features/ritual_guidance/providers/umrah_progress_provider.dart'
    show UmrahProgressProvider;
import '../../features/ritual_guidance/providers/hijj_provider.dart'
    show HijjProvider;

/// Reusable confirmation dialog component
/// Follows the app's design guidelines and localization requirements
class ConfirmationDialog extends StatelessWidget {
  final String title;
  final String message;
  final String confirmText;
  final String cancelText;
  final VoidCallback? onConfirm;
  final VoidCallback? onCancel;
  final Color? confirmColor;
  final Color? cancelColor;
  final bool isDestructive;
  final Widget? content;

  const ConfirmationDialog({
    super.key,
    required this.title,
    required this.message,
    this.confirmText = '',
    this.cancelText = '',
    this.onConfirm,
    this.onCancel,
    this.confirmColor,
    this.cancelColor,
    this.isDestructive = false,
    this.content,
  });

  /// Show confirmation dialog for resetting progress
  static Future<bool?> showResetProgressDialog(BuildContext context) {
    return showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (context) => ConfirmationDialog(
        title: S.of(context).resetProgress,
        message: S.of(context).resetProgressConfirmation,
        confirmText: S.of(context).reset,
        cancelText: S.of(context).cancel,
        isDestructive: true,
        onConfirm: () => Navigator.of(context).pop(true),
        onCancel: () => Navigator.of(context).pop(false),
      ),
    );
  }

  /// Show confirmation dialog for step completion
  /// Updates progress in Firebase when user confirms
  static Future<bool?> showStepCompletionDialog({
    required BuildContext context,
    required String stepName,
    required int stepNumber,
    required UmrahProgressProvider progressProvider,
  }) {
    return showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => _StepCompletionDialogContent(
        stepName: stepName,
        stepNumber: stepNumber,
        progressProvider: progressProvider,
      ),
    );
  }

  static Future<bool?> showHajjStepCompletionDialog({
    required BuildContext context,
    required String stepName,
    required int dayNumber,
    required int stepNumber,
    required HijjProvider progressProvider,
  }) {
    return showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => _HajjStepCompletionDialogContent(
        stepName: stepName,
        dayNumber: dayNumber,
        stepNumber: stepNumber,
        progressProvider: progressProvider,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final effectiveConfirmText = confirmText.isEmpty
        ? S.of(context).reset
        : confirmText;
    final effectiveCancelText = cancelText.isEmpty
        ? S.of(context).cancel
        : cancelText;

    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20).r),
      child: Container(
        padding: EdgeInsets.all(24).r,
        decoration: BoxDecoration(
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(20).r,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Title
            Text(
              title,
              style: TextStyle(
                fontSize: 16.spMin,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).textTheme.headlineLarge?.color,
              ),
            ),
            16.verticalSpace,
            // Message
            Text(
              message,
              style: TextStyle(
                fontSize: 12.spMin,
                color: Theme.of(context).textTheme.bodyLarge?.color,
                height: 1.5,
              ),
            ),
            if (content != null) ...[16.verticalSpace, content!],
            24.verticalSpace,
            // Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                // Cancel Button
                TextButton(
                  onPressed: onCancel ?? () => Navigator.of(context).pop(false),
                  style: TextButton.styleFrom(
                    padding: EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 2,
                    ).r,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10).r,
                    ),
                  ),
                  child: Text(
                    effectiveCancelText,
                    style: TextStyle(
                      fontSize: 12.spMin,
                      color:
                          cancelColor ??
                          (context.isDarkTheme
                              ? ColorUtil.white
                              : Colors.black54),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                12.horizontalSpace,
                // Confirm Button
                ElevatedButton(
                  onPressed: onConfirm ?? () => Navigator.of(context).pop(true),
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                        confirmColor ??
                        (isDestructive ? Colors.red : ColorUtil.primaryColor),
                    padding: EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 2,
                    ).r,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10).r,
                    ),
                    elevation: 0,
                  ),
                  child: Text(
                    effectiveConfirmText,
                    style: TextStyle(
                      fontSize: 12.spMin,
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Internal StatefulWidget for step completion dialog with async progress update
class _StepCompletionDialogContent extends StatefulWidget {
  final String stepName;
  final int stepNumber;
  final UmrahProgressProvider progressProvider;

  const _StepCompletionDialogContent({
    required this.stepName,
    required this.stepNumber,
    required this.progressProvider,
  });

  @override
  State<_StepCompletionDialogContent> createState() =>
      _StepCompletionDialogContentState();
}

class _StepCompletionDialogContentState
    extends State<_StepCompletionDialogContent> {
  bool _isUpdating = false;
  bool _doNotShowAgain = false;

  Future<void> _handleConfirm() async {
    setState(() => _isUpdating = true);
    try {
      if (_doNotShowAgain) {
        await widget.progressProvider.setDialogPreference(false);
      }
      await widget.progressProvider.markStepCompleted(widget.stepNumber);
      if (mounted) {
        Navigator.of(context).pop(true);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(S.of(context).stepMarkedAsCompleted),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      setState(() => _isUpdating = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(S.of(context).failedToSaveProgress),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _handleCancel() async {
    if (_doNotShowAgain) {
      await widget.progressProvider.setDialogPreference(false);
    }
    if (mounted) {
      Navigator.of(context).pop(false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ConfirmationDialog(
      title: S.of(context).stepCompletedConfirmation,
      message: S.of(context).stepCompletedConfirmationMessage(widget.stepName),
      confirmText: S.of(context).yesCompleted,
      cancelText: S.of(context).noNotYet,
      isDestructive: false,
      onConfirm: _isUpdating ? null : _handleConfirm,
      onCancel: _isUpdating ? null : _handleCancel,
      content: Row(
        children: [
          SizedBox(
            height: 24.r,
            width: 24.r,
            child: Checkbox(
              value: _doNotShowAgain,
              onChanged: (value) {
                setState(() {
                  _doNotShowAgain = value ?? false;
                });
              },
              activeColor: ColorUtil.primaryColor,
            ),
          ),
          8.horizontalSpace,
          Expanded(
            child: Text(
              S.of(context).doNotShowAgain,
              style: TextStyle(
                fontSize: 12.spMin,
                color: context.isDarkTheme ? ColorUtil.white : Colors.black87,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _HajjStepCompletionDialogContent extends StatefulWidget {
  final String stepName;
  final int dayNumber;
  final int stepNumber;
  final HijjProvider progressProvider;

  const _HajjStepCompletionDialogContent({
    required this.stepName,
    required this.dayNumber,
    required this.stepNumber,
    required this.progressProvider,
  });

  @override
  State<_HajjStepCompletionDialogContent> createState() =>
      _HajjStepCompletionDialogContentState();
}

class _HajjStepCompletionDialogContentState
    extends State<_HajjStepCompletionDialogContent> {
  bool _isUpdating = false;
  bool _doNotShowAgain = false;

  Future<void> _handleConfirm() async {
    setState(() => _isUpdating = true);
    try {
      if (_doNotShowAgain) {
        await widget.progressProvider.setDialogPreference(false);
      }
      widget.progressProvider.markStepCompleted(
        widget.dayNumber,
        widget.stepNumber,
      );
      if (mounted) {
        Navigator.of(context).pop(true);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(S.of(context).stepMarkedAsCompleted),
            backgroundColor: Colors.green,
          ),
        );
      }
    } catch (e) {
      setState(() => _isUpdating = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(S.of(context).failedToSaveProgress),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _handleCancel() async {
    if (_doNotShowAgain) {
      await widget.progressProvider.setDialogPreference(false);
    }
    if (mounted) {
      Navigator.of(context).pop(false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return ConfirmationDialog(
      title: S.of(context).stepCompletedConfirmation,
      message: S.of(context).stepCompletedConfirmationMessage(widget.stepName),
      confirmText: S.of(context).yesCompleted,
      cancelText: S.of(context).noNotYet,
      isDestructive: false,
      onConfirm: _isUpdating ? null : _handleConfirm,
      onCancel: _isUpdating ? null : _handleCancel,
      content: Row(
        children: [
          SizedBox(
            height: 24.r,
            width: 24.r,
            child: Checkbox(
              value: _doNotShowAgain,
              onChanged: (value) {
                setState(() {
                  _doNotShowAgain = value ?? false;
                });
              },
              activeColor: ColorUtil.primaryColor,
            ),
          ),
          8.horizontalSpace,
          Expanded(
            child: Text(
              S.of(context).doNotShowAgain,
              style: TextStyle(
                fontSize: 12.spMin,
                color: context.isDarkTheme ? ColorUtil.white : Colors.black87,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
