import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart' show SvgPicture;
import 'package:go_router/go_router.dart';
import 'package:labbaik/core/utilities/extensions.dart';
import 'package:labbaik/core/utilities/path_util.dart';

import '../../features/home/presentation/screens/home.dart' show MainAppScreen;
import '../../features/home/presentation/widgets/custom_bottom_nav_bar.dart'
    show CustomBottomNavBar;
import '../../features/home/presentation/widgets/home_drawer.dart'
    show HomeDrawer;
import '../utilities/color_util.dart' show ColorUtil;

import 'package:provider/provider.dart';

class GlobalScaffold<T extends ChangeNotifier?> extends StatefulWidget {
  final Widget child;
  final T Function(BuildContext context)? create;
  final bool withBackButton;
  final int? bottomNavBarIndex;

  const GlobalScaffold({
    super.key,
    required this.child,
    this.create,
    this.withBackButton = false,
    this.bottomNavBarIndex,
  });

  @override
  State<GlobalScaffold<T>> createState() => _GlobalScaffoldState<T>();
}

class _GlobalScaffoldState<T extends ChangeNotifier?>
    extends State<GlobalScaffold<T>> {
  late bool withBackButton;
  late int currentIndex;

  @override
  void initState() {
    super.initState();
    withBackButton = widget.withBackButton;
    currentIndex = widget.bottomNavBarIndex ?? -1;
  }

  @override
  Widget build(BuildContext context) {
    void onNavItemTapped(int index) {
      // switch case
      switch (index) {
        case 0:
          MainAppScreen.goHome(context: context, index: index);
          break;
        case 1:
          MainAppScreen.goHome(context: context, index: index);
          break;
        case 2:
          MainAppScreen.goHome(context: context, index: index);
          break;
        case 3:
          MainAppScreen.goHome(context: context, index: index);
          break;
        case 4:
          MainAppScreen.goHome(context: context, index: index);
          break;
      }
    }

    final scaffold = Scaffold(
      drawer: const HomeDrawer(),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: 8, horizontal: 16).r,
          child: Column(
            children: [
              Builder(
                builder: (context) => Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    if (withBackButton)
                      GestureDetector(
                        onTap: () => context.pop(),
                        child: Container(
                          alignment: Alignment.center,
                          width: 40.spMin,
                          height: 40.spMin,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(12).r,
                            border: Border.all(
                              color: ColorUtil.grey3,
                              width: 1,
                            ),
                          ),
                          child: Center(
                            child: Padding(
                              padding: EdgeInsetsDirectional.only(start: 6.r),
                              child: Icon(
                                Icons.arrow_back_ios,
                                color: context.isDarkTheme
                                    ? ColorUtil.white
                                    : ColorUtil.black,
                                size: 18.spMin,
                              ),
                            ),
                          ),
                        ),
                      )
                    else
                      GestureDetector(
                        onTap: () => Scaffold.of(context).openDrawer(),
                        child: Icon(
                          Icons.menu,
                          color: ColorUtil.black,
                          size: 30.spMin,
                        ),
                      ),

                    SvgPicture.asset(
                      PathUtil.logoLight,
                      width: 40.spMin,
                      height: 40.spMin,
                      fit: BoxFit.scaleDown,
                    ),
                  ],
                ),
              ),
              Expanded(child: widget.child),
            ],
          ),
        ),
      ),
      bottomNavigationBar: CustomBottomNavBar(
        currentIndex: currentIndex,
        onTap: onNavItemTapped,
      ),
    );

    if (widget.create != null) {
      return ChangeNotifierProvider<T>(create: widget.create!, child: scaffold);
    }

    return scaffold;
  }
}
