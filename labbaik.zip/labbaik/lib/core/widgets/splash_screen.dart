import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:go_router/go_router.dart';
import 'package:labbaik/core/utilities/color_util.dart';
import 'package:labbaik/core/utilities/path_util.dart';
import 'package:labbaik/features/auth/presentation/screens/auth_screen.dart';
import 'package:labbaik/features/home/presentation/screens/home.dart';
import 'package:labbaik/core/services/auth_service.dart';
import 'package:provider/provider.dart';
import 'package:labbaik/features/auth/controller/auth_provider.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:labbaik/core/widgets/custom_transition_page.dart'
    show CustomTransitionPageBuilder;

/// Splash screen that checks authentication state
/// Navigates to home if authenticated, otherwise to login
class SplashScreen extends StatefulWidget {
  static const String routeName = 'splash';
  static const String path = '/';

  static CustomTransitionPageBuilder page(
    BuildContext context,
    GoRouterState state,
  ) => CustomTransitionPageBuilder(
    key: state.pageKey,
    page: const SplashScreen(),
    name: routeName,
  );

  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _checkAuthState();
  }

  Future<void> _checkAuthState() async {
    // Wait for splash animation (2 seconds)
    await Future.delayed(const Duration(seconds: 2));

    if (!mounted) return;

    final authProvider = context.read<AuthProvider>();
    final authService = AuthService();

    // Check if user is authenticated
    final currentUser = authService.currentUser;

    if (currentUser != null) {
      // User is authenticated, load user data
      try {
        final userData = await authService.getUserData(currentUser.uid);
        if (userData != null) {
          authProvider.setUser(userData);
          if (mounted) {
            context.go(MainAppScreen.path);
          }
        } else {
          // User data not found, go to login
          if (mounted) {
            context.go(AuthScreen.path);
          }
        }
      } catch (e) {
        // Error loading user data, go to login
        if (mounted) {
          context.go(AuthScreen.path);
        }
      }
    } else {
      // No authenticated user, go to login
      if (mounted) {
        context.go(AuthScreen.path);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SplashContent(logoPath: PathUtil.logoLight, appName: 'Labbaik'),
    );
  }
}

/// Reusable splash content widget
/// Can be used in different contexts with customizable logo and app name
class SplashContent extends StatelessWidget {
  final String logoPath;
  final String appName;
  final Color? backgroundColor;
  final Color? textColor;

  const SplashContent({
    super.key,
    required this.logoPath,
    required this.appName,
    this.backgroundColor,
    this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    final bgColor =
        backgroundColor ??
        (Theme.of(context).brightness == Brightness.dark
            ? ColorUtil.primaryW700
            : ColorUtil.primaryColor);

    final txtColor = textColor ?? Colors.white;

    return Container(
      width: double.infinity,
      height: double.infinity,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [bgColor, ColorUtil.primaryW500],
        ),
      ),
      child: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Logo
            SvgPicture.asset(logoPath, width: 120.spMin, height: 120.spMin),
            32.verticalSpace,
            // App Name
            Text(
              appName,
              style: TextStyle(
                fontSize: 32.spMin,
                fontWeight: FontWeight.bold,
                color: txtColor,
              ),
            ),
            16.verticalSpace,
            // Loading indicator
            SizedBox(
              width: 40.spMin,
              height: 40.spMin,
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(txtColor),
                strokeWidth: 3,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
