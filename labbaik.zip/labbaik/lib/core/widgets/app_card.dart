import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:labbaik/core/utilities/extensions.dart';
import 'package:labbaik/generated/l10n.dart';

import '../utilities/color_util.dart' show ColorUtil;

class AppCard extends StatelessWidget {
  final String title;
  final int stepNumber;
  final String? stepTitle;
  final String icon;
  const AppCard({
    super.key,
    required this.title,
    this.stepNumber = -1,
    this.stepTitle,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(20).r,
      decoration: BoxDecoration(
        color: context.isDarkTheme ? ColorUtil.black : ColorUtil.white,
        borderRadius: BorderRadius.circular(20).r,
        border: Border.all(
          color: context.isDarkTheme
              ? ColorUtil.black.withValues(alpha: 0.1)
              : ColorUtil.accentColor.withValues(alpha: 0.1),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: context.isDarkTheme
                ? Colors.black.withValues(alpha: 0.08)
                : ColorUtil.black.withValues(alpha: 0.08),
            blurRadius: 12,
            offset: const Offset(0, 6),
            spreadRadius: 0,
          ),
          BoxShadow(
            color: context.isDarkTheme
                ? ColorUtil.black.withValues(alpha: 0.05)
                : ColorUtil.accentColor.withValues(alpha: 0.05),
            blurRadius: 20,
            offset: const Offset(0, 2),
            spreadRadius: 2,
          ),
        ],
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (stepTitle != null || stepNumber != -1)
                  Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: 12.r,
                      vertical: 6.r,
                    ),
                    decoration: BoxDecoration(
                      color: ColorUtil.accentColor.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(20).r,
                    ),
                    child: Text(
                      stepNumber == -1 && stepTitle != null
                          ? stepTitle!
                          : '${S.of(context).step} $stepNumber',
                      style: TextStyle(
                        fontSize: 12.sp,
                        color: ColorUtil.accentColor,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ),

                12.verticalSpace,
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 22.sp,
                    fontWeight: FontWeight.bold,
                    color: context.isDarkTheme
                        ? ColorUtil.white
                        : ColorUtil.darkGrey,
                    height: 1.2,
                  ),
                ),
              ],
            ),
          ),
          16.horizontalSpace,
          // Icon Container
          Container(
            width: 64.r,
            height: 64.r,
            decoration: BoxDecoration(
              color: ColorUtil.primaryColor,
              borderRadius: BorderRadius.circular(20).r,
              boxShadow: [
                BoxShadow(
                  color: ColorUtil.primaryColor.withValues(alpha: 0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: Padding(
              padding: EdgeInsets.all(14).r,
              child: Transform.scale(
                scale: 1.8,
                child: ClipRRect(
                  child: Image.asset(
                    icon,
                    fit: BoxFit.contain,
                    errorBuilder: (context, error, stackTrace) =>
                        Icon(Icons.mosque, color: Colors.white, size: 24.spMin),
                  ),
                ),
              ),
            ),
          ),
          12.horizontalSpace,
          // Enhanced Arrow
          Container(
            padding: EdgeInsets.all(8).r,
            decoration: BoxDecoration(
              color: ColorUtil.accentColor.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12).r,
            ),
            child: Icon(
              Icons.arrow_forward_ios_rounded,
              size: 16.spMin,
              color: ColorUtil.accentColor,
            ),
          ),
        ],
      ),
    );
  }
}
