import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:labbaik/core/utilities/color_util.dart';

/// Reusable loading indicator widget
/// Displays a circular progress indicator with customizable size and color
class LoadingIndicator extends StatelessWidget {
  final double? size;
  final Color? color;
  final double? strokeWidth;
  final bool center;

  const LoadingIndicator({
    super.key,
    this.size,
    this.color,
    this.strokeWidth,
    this.center = true,
  });

  @override
  Widget build(BuildContext context) {
    final indicator = SizedBox(
      height: size ?? 24.spMin,
      width: size ?? 24.spMin,
      child: CircularProgressIndicator(
        strokeWidth: strokeWidth ?? 3,
        valueColor: AlwaysStoppedAnimation<Color>(
          color ?? ColorUtil.accentColor,
        ),
      ),
    );

    if (center) {
      return Center(
        child: Padding(
          padding: EdgeInsets.all(16).r,
          child: indicator,
        ),
      );
    }

    return Padding(
      padding: EdgeInsets.all(16).r,
      child: indicator,
    );
  }
}

