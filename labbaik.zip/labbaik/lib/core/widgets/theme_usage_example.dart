import 'package:flutter/material.dart';

import '../services/theme_service.dart';
import 'theme_toggle_widget.dart';

/// Example of how to use the theme system in your app
class ThemeUsageExample extends StatefulWidget {
  const ThemeUsageExample({super.key});

  @override
  State<ThemeUsageExample> createState() => _ThemeUsageExampleState();
}

class _ThemeUsageExampleState extends State<ThemeUsageExample> {
  late final ThemeService _themeService;

  @override
  void initState() {
    super.initState();
    _themeService = ThemeService.instance;
    _themeService.init();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Theme Example'),
        actions: [
          // Simple toggle button in app bar
          ThemeToggleButton(themeService: _themeService),
          // Or use the cycle button
          ThemeCycleButton(themeService: _themeService),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Theme Settings',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),

            // Full theme selector widget
            ThemeToggleWidget(
              themeService: _themeService,
              showLabel: true,
              showSystemOption: true,
            ),

            const SizedBox(height: 30),

            // Example content to show theme changes
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Sample Content',
                      style: Theme.of(context).textTheme.headlineSmall,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'This content will change appearance based on the selected theme.',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: () {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Button pressed!')),
                        );
                      },
                      child: const Text('Sample Button'),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// How to access theme service from anywhere in your app
class ThemeServiceProvider extends InheritedWidget {
  final ThemeService themeService;

  const ThemeServiceProvider({
    super.key,
    required this.themeService,
    required super.child,
  });

  static ThemeServiceProvider? of(BuildContext context) {
    return context.dependOnInheritedWidgetOfExactType<ThemeServiceProvider>();
  }

  @override
  bool updateShouldNotify(ThemeServiceProvider oldWidget) {
    return themeService != oldWidget.themeService;
  }
}

/// Extension to easily access theme service from context
extension ThemeServiceExtension on BuildContext {
  ThemeService? get themeService => ThemeServiceProvider.of(this)?.themeService;
}
