import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:labbaik/core/widgets/custom_transition_page.dart'
    show CustomTransitionPageBuilder;
import 'package:labbaik/generated/l10n.dart' show S;
import 'package:lottie/lottie.dart';

import '../utilities/path_util.dart';

class PageNotFoundView extends StatelessWidget {
  final String? errorMsg;
  final bool homeButtonEnabled;

  const PageNotFoundView({
    super.key,
    this.errorMsg,
    this.homeButtonEnabled = true,
  });

  static const String routeName = "not-found";
  static const String path = '/not-found';

  static GoRouterWidgetBuilder widgetBuilder = (context, state) =>
      PageNotFoundView(errorMsg: state.error.toString());

  static GoRouterPageBuilder pageBuilder = (context, state) =>
      CustomTransitionPageBuilder(
        key: state.pageKey,
        name: routeName,
        page: PageNotFoundView(errorMsg: state.error.toString()),
      );

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Lottie.asset(
            theme.brightness == Brightness.light
                ? PathUtil.notFoundBlackLottie
                : PathUtil.notFoundWhiteLottie,
            fit: BoxFit.scaleDown,
          ),
          Text(
            S.of(context).pageNotFoundMsg,
            textAlign: TextAlign.center,
            maxLines: 2,
          ),
          if (errorMsg != null)
            Text(errorMsg!, textAlign: TextAlign.center, maxLines: 15),
        ],
      ),
    );
  }
}
