import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import '../../generated/l10n.dart';
import '../utilities/color_util.dart';

enum ValidationState {
  initial, // Grey state
  valid, // Green state
  invalid, // Red state
}

class PasswordValidationRule {
  final String text;
  final ValidationState state;
  final bool Function(String) validator;

  const PasswordValidationRule({
    required this.text,
    required this.state,
    required this.validator,
  });

  PasswordValidationRule copyWith({
    String? text,
    ValidationState? state,
    bool Function(String)? validator,
  }) {
    return PasswordValidationRule(
      text: text ?? this.text,
      state: state ?? this.state,
      validator: validator ?? this.validator,
    );
  }
}

class PasswordValidationStepper extends StatefulWidget {
  final String password;
  final bool hasValidated;
  final VoidCallback? onValidationChanged;

  const PasswordValidationStepper({
    super.key,
    required this.password,
    this.hasValidated = false,
    this.onValidationChanged,
  });

  @override
  State<PasswordValidationStepper> createState() =>
      _PasswordValidationStepperState();
}

class _PasswordValidationStepperState extends State<PasswordValidationStepper> {
  late List<PasswordValidationRule> validationRules;

  @override
  void initState() {
    super.initState();
    _initializeRules();
  }

  @override
  void didUpdateWidget(PasswordValidationStepper oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.password != widget.password ||
        oldWidget.hasValidated != widget.hasValidated) {
      _updateValidationStates();
    }
  }

  void _initializeRules() {
    validationRules = [
      PasswordValidationRule(
        text: S.current.mustBeAtLeast8CharactersLong,
        state: ValidationState.initial,
        validator: (password) => password.length >= 8,
      ),
      PasswordValidationRule(
        text: S.current.mustIncludeAtLeastOneUppercaseLetter,
        state: ValidationState.initial,
        validator: (password) => password.contains(RegExp(r'[A-Z]')),
      ),
      PasswordValidationRule(
        text: S.current.mustIncludeAtLeastOneLowercaseLetter,
        state: ValidationState.initial,
        validator: (password) => password.contains(RegExp(r'[a-z]')),
      ),
      PasswordValidationRule(
        text: S.current.mustIncludeAtLeastOneDigit,
        state: ValidationState.initial,
        validator: (password) => password.contains(RegExp(r'[0-9]')),
      ),
      PasswordValidationRule(
        text: S.current.mustIncludeAtLeastOneSpecialCharacter,
        state: ValidationState.initial,
        validator: (password) => password.contains(RegExp(r'[!@#$%^&*()_+]')),
      ),
      PasswordValidationRule(
        text: S.current.mustNotContainSpaces,
        state: ValidationState.initial,
        validator: (password) => !password.contains(' '),
      ),
    ];
    _updateValidationStates();
  }

  void _updateValidationStates() {
    setState(() {
      for (int i = 0; i < validationRules.length; i++) {
        final rule = validationRules[i];
        final isValid = rule.validator(widget.password);

        ValidationState newState;
        if (widget.hasValidated) {
          // After validation attempt, show red for invalid, green for valid
          newState = isValid ? ValidationState.valid : ValidationState.invalid;
        } else {
          // Before validation, show green for valid, grey for invalid
          newState = isValid ? ValidationState.valid : ValidationState.initial;
        }

        validationRules[i] = rule.copyWith(state: newState);
      }
    });

    // Notify parent about validation changes
    widget.onValidationChanged?.call();
  }

  Color _getStateColor(ValidationState state) {
    switch (state) {
      case ValidationState.initial:
        return ColorUtil.lightGrey;
      case ValidationState.valid:
        return ColorUtil.successColor;
      case ValidationState.invalid:
        return ColorUtil.errorColor;
    }
  }

  IconData _getStateIcon(ValidationState state) {
    switch (state) {
      case ValidationState.initial:
        return Icons.radio_button_unchecked;
      case ValidationState.valid:
        return Icons.check_circle;
      case ValidationState.invalid:
        return Icons.cancel;
    }
  }

  bool get isPasswordValid {
    return validationRules.every((rule) => rule.validator(widget.password));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(8).r,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            S.current.passwordRequirements,
            style: TextStyle(
              fontSize: 14.spMin,
              fontWeight: FontWeight.w700,
              color: ColorUtil.darkGrey,
            ),
          ),
          12.verticalSpace,
          ...validationRules.map((rule) => _buildValidationItem(rule)),
        ],
      ),
    );
  }

  Widget _buildValidationItem(PasswordValidationRule rule) {
    final color = _getStateColor(rule.state);
    final icon = _getStateIcon(rule.state);

    return Padding(
      padding: EdgeInsets.only(bottom: 4.spMin),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 15.spMin, color: color),
          8.horizontalSpace,
          Expanded(
            child: Text(
              rule.text,
              style: TextStyle(fontSize: 11.spMin, color: color, height: 1.3),
            ),
          ),
        ],
      ),
    );
  }
}

// Helper class to validate password with all rules
class PasswordValidationHelper {
  static bool isPasswordValid(String password) {
    return password.length >= 8 &&
        password.contains(RegExp(r'[A-Z]')) &&
        password.contains(RegExp(r'[a-z]')) &&
        password.contains(RegExp(r'[0-9]')) &&
        password.contains(RegExp(r'[!@#$%^&*()_+]')) &&
        !password.contains(' ');
  }

  static String? validatePasswordWithRules(String? value) {
    if (value == null || value.isEmpty) {
      return S.current.passwordRequired;
    }

    if (!isPasswordValid(value)) {
      return S.current.passwordDoesNotMeetAllRequirements;
    }

    return null;
  }

  static List<String> getFailedRules(String password) {
    List<String> failedRules = [];

    if (password.length < 8) {
      failedRules.add(S.current.mustBeAtLeast8CharactersLong);
    }
    if (!password.contains(RegExp(r'[A-Z]'))) {
      failedRules.add(S.current.mustIncludeAtLeastOneUppercaseLetter);
    }
    if (!password.contains(RegExp(r'[a-z]'))) {
      failedRules.add(S.current.mustIncludeAtLeastOneLowercaseLetter);
    }
    if (!password.contains(RegExp(r'[0-9]'))) {
      failedRules.add(S.current.mustIncludeAtLeastOneDigit);
    }
    if (!password.contains(RegExp(r'[!@#$%^&*()_+]'))) {
      failedRules.add(S.current.mustIncludeAtLeastOneSpecialCharacter);
    }
    if (password.contains(' ')) {
      failedRules.add(S.current.mustNotContainSpaces);
    }

    return failedRules;
  }
}
