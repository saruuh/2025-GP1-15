import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:labbaik/core/utilities/color_util.dart';

class ResetButton extends StatelessWidget {
  final VoidCallback onTap;
  const ResetButton({super.key, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 36.spMin,
        height: 36.spMin,
        decoration: BoxDecoration(
          color: ColorUtil.accentColor,
          shape: BoxShape.circle,
        ),
        child: Center(child: Icon(Icons.refresh, color: ColorUtil.white)),
      ),
    );
  }
}
