import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart' show SvgPicture;
import 'package:labbaik/core/utilities/extensions.dart';

import '../../generated/l10n.dart';
import '../utilities/app_util.dart';
import '../utilities/color_util.dart' show ColorUtil;
import '../utilities/path_util.dart' show PathUtil;
import 'global_card.dart';
import 'waiting.dart';

const kAppTextFieldHeight = 48.0;

class AppTextField extends StatefulWidget {
  final bool ignoreHeight;
  final bool hidePassword;
  final bool isPassword;
  final Widget? prefixWidget;
  final Widget? suffixWidget;
  final int? maxLines;
  final TextAlign textAlignment;
  final TextInputType keyBoardType;
  final Function()? changeObscuring;
  final bool readOnly;
  final ValueChanged<String>? onChanged;
  final FormFieldValidator<String>? validator;
  final Function()? onEditSubmitted;
  final String? hintText;
  final String? errorText;
  final String? subLabelText;
  final String? labelHelperText;
  final Widget? labelLeadingWidget;
  final double? spaceBetweenLabelAndField;
  final List<TextInputFormatter>? formatters;
  final EdgeInsets? margin;
  final FocusNode? focusNode;
  final bool autoFocus;
  final bool showError;
  final String? labelText;
  final Color? borderColor;
  final BorderRadius? borderRadius;
  final Function()? onTap;
  final bool isBusy;
  final Color? cursorColor;
  final Color? fillColor;
  final String? initialValue;
  final Function(String?)? onSaved;
  final TextDirection? textDirection;
  final TextEditingController? textEditingController;
  final CrossAxisAlignment labelAxisAlignment;
  final TextStyle? labelStyle;
  final TextStyle? subLabelStyle;
  final TextStyle? style;
  final TextStyle? hintStyle;
  final TextStyle? labelHelperStyle;
  final EdgeInsets? contentPadding;
  final double? suffixWidth;
  final double? prefixWidth;
  final int? minLines;
  final Function(String)? onFieldSubmitted;
  final double height;
  final Widget? labelTrailing;
  final List<String>? autoFillHints;
  final bool labelOnBorder;
  final bool? hasAllOption;
  final bool? allValue;
  final Function(bool)? onChangedAllOption;
  final double? allOptionGap;
  final bool isDisabled;
  final AutovalidateMode? autoValidateMode;
  final bool? isMandatory;
  final bool isCurrency;

  const AppTextField({
    super.key,
    this.height = kAppTextFieldHeight,
    this.showError = true,
    this.ignoreHeight = false,
    this.autoFocus = false,
    this.hidePassword = false,
    this.isPassword = false,
    this.textAlignment = TextAlign.start,
    this.keyBoardType = TextInputType.text,
    this.readOnly = false,
    this.isBusy = false,
    this.labelOnBorder = false,
    this.maxLines,
    this.autoFillHints,
    this.labelAxisAlignment = CrossAxisAlignment.start,
    this.errorText,
    this.formatters,
    this.minLines,
    this.contentPadding,
    this.suffixWidth,
    this.prefixWidth,
    this.prefixWidget,
    this.suffixWidget,
    this.onChanged,
    this.fillColor,
    this.hintText,
    this.labelStyle,
    this.hintStyle,
    this.labelHelperStyle,
    this.style,
    this.subLabelText,
    this.subLabelStyle,
    this.labelHelperText,
    this.cursorColor,
    this.spaceBetweenLabelAndField,
    this.changeObscuring,
    this.margin,
    this.labelText,
    this.labelLeadingWidget,
    this.borderRadius,
    this.borderColor,
    this.focusNode,
    this.textDirection,
    this.validator,
    this.onTap,
    this.textEditingController,
    this.initialValue,
    this.onSaved,
    this.onEditSubmitted,
    this.onFieldSubmitted,
    this.labelTrailing,
    this.hasAllOption,
    this.allValue,
    this.onChangedAllOption,
    this.allOptionGap,
    this.isDisabled = false,
    this.autoValidateMode,
    this.isMandatory = false,
    this.isCurrency = false,
  });

  factory AppTextField.transparentWithBorder({
    Key? key,
    double height = kAppTextFieldHeight,
    bool hidePassword = false,
    bool ignoreHeight = false,
    bool isPassword = false,
    bool readOnly = false,
    bool autoFocus = false,
    bool showError = true,
    bool isBusy = false,
    bool labelOnBorder = false,
    int? maxLines,
    TextAlign textAlignment = TextAlign.start,
    TextInputType keyBoardType = TextInputType.text,
    CrossAxisAlignment labelAxisAlignment = CrossAxisAlignment.start,
    Widget? prefixWidget,
    double? prefixWidth,
    Widget? suffixWidget,
    Function()? changeObscuring,
    ValueChanged<String>? onChanged,
    FormFieldValidator<String>? validator,
    Function()? onEditSubmitted,
    String? hintText,
    String? errorText,
    String? subLabelText,
    TextStyle? subLabelStyle,
    String? labelHelperText,
    double? spaceBetweenLabelAndField,
    List<TextInputFormatter>? formatters,
    List<String>? autoFillHints,
    EdgeInsets? margin,
    FocusNode? focusNode,
    String? labelText,
    Widget? labelWidget,
    Color? borderColor,
    BorderRadius? borderRadius,
    Function()? onTap,
    Color? cursorColor,
    Color? fillColor,
    String? initialValue,
    Function(String?)? onSaved,
    TextDirection? textDirection,
    TextEditingController? textEditingController,
    TextStyle? labelStyle,
    TextStyle? style,
    TextStyle? hintStyle,
    TextStyle? labelHelperStyle,
    EdgeInsets? contentPadding,
    double? suffixWidth,
    int? minLines,
    Function(String)? onFieldSubmitted,
    Widget? labelTrailing,
    bool? hasAllOption,
    bool? allValue,
    Function(bool)? onChangedAllOption,
    double? allOptionGap,
    bool isDisabled = false,
    AutovalidateMode? autoValidateMode,
    bool? isMandatory,
    bool isCurrency = false,
  }) => AppTextField(
    key: key,
    height: height,
    isDisabled: isDisabled,
    ignoreHeight: ignoreHeight,
    showError: showError,
    autoFocus: autoFocus,
    hidePassword: hidePassword,
    isPassword: isPassword,
    textAlignment: textAlignment,
    keyBoardType: keyBoardType,
    readOnly: readOnly,
    isBusy: isBusy,
    maxLines: maxLines,
    labelAxisAlignment: labelAxisAlignment,
    labelOnBorder: labelOnBorder,
    errorText: errorText,
    formatters: formatters,
    autoFillHints: autoFillHints,
    minLines: minLines,
    contentPadding: contentPadding,
    suffixWidth: suffixWidth,
    prefixWidget: prefixWidget,
    suffixWidget: suffixWidget,
    onChanged: onChanged,
    hintText: hintText,
    labelStyle: labelStyle,
    hintStyle: hintStyle,
    labelHelperStyle: labelHelperStyle,
    style: style,
    subLabelText: subLabelText,
    subLabelStyle: subLabelStyle,
    labelHelperText: labelHelperText,
    cursorColor: cursorColor,
    spaceBetweenLabelAndField: spaceBetweenLabelAndField,
    changeObscuring: changeObscuring,
    margin: margin,
    labelText: labelText,
    labelLeadingWidget: labelWidget,
    borderRadius: borderRadius,
    fillColor: fillColor ?? Colors.transparent,
    borderColor: borderColor ?? ColorUtil.blueGreyColor,
    focusNode: focusNode,
    textDirection: textDirection,
    validator: validator,
    onTap: onTap,
    textEditingController: textEditingController,
    initialValue: initialValue,
    onSaved: onSaved,
    onEditSubmitted: onEditSubmitted,
    onFieldSubmitted: onFieldSubmitted,
    labelTrailing: labelTrailing,
    hasAllOption: hasAllOption,
    allValue: allValue,
    onChangedAllOption: onChangedAllOption,
    allOptionGap: allOptionGap,
    autoValidateMode: autoValidateMode,
    isMandatory: isMandatory,
    isCurrency: isCurrency,
    prefixWidth: prefixWidth,
  );

  @override
  State<AppTextField> createState() => _AppTextFieldState();
}

class _AppTextFieldState extends State<AppTextField> {
  String? _initialValue;
  late TextEditingController _controller;

  void _controllerListener() {
    if (!widget.readOnly) return;
    if (mounted) {
      setState(() => _initialValue = _controller.text);
    }
  }

  @override
  void initState() {
    _initialValue = widget.initialValue;

    if (widget.textEditingController != null) {
      _controller = widget.textEditingController!;
      _initialValue ??= widget.textEditingController!.text;
      _controller.text = _initialValue!;
    } else {
      _controller = TextEditingController(text: _initialValue);
    }

    // Only add listener if the field is read-only
    if (widget.readOnly) {
      _controller.addListener(_controllerListener);
    }
    super.initState();
  }

  @override
  void dispose() {
    if (widget.textEditingController == null) {
      _controller.removeListener(_controllerListener);
      _controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return AbsorbPointer(
      absorbing: widget.isDisabled,
      child: Container(
        foregroundDecoration: widget.isDisabled
            ? BoxDecoration(
                color: Colors.grey,
                backgroundBlendMode: context.isDarkTheme
                    ? BlendMode.darken
                    : BlendMode.lighten,
              )
            : const BoxDecoration(
                color: Colors.transparent,
                backgroundBlendMode: BlendMode.saturation,
              ),
        child: Padding(
          padding: widget.margin ?? EdgeInsets.zero,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: widget.labelAxisAlignment,
            children: [
              if (widget.labelLeadingWidget != null) ...[
                widget.labelLeadingWidget!,
                SizedBox(height: widget.spaceBetweenLabelAndField ?? 8.0),
              ],
              if (!widget.labelOnBorder && widget.labelText != null) ...[
                Row(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Text(
                              widget.labelText!,
                              style: theme.textTheme.labelSmall
                                  ?.copyWith(
                                    fontWeight: FontWeight.w600,
                                    letterSpacing: -0.25,
                                  )
                                  .merge(widget.labelStyle),
                              textAlign: TextAlign.start,
                            ),
                            if (widget.isMandatory == true) ...[
                              SizedBox(width: 4.0),
                              Text(
                                '*',
                                style: theme.textTheme.labelSmall?.copyWith(
                                  color: theme.colorScheme.error,
                                ),
                              ),
                            ],
                            if (widget.hasAllOption != null &&
                                widget.hasAllOption == true)
                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  SizedBox(width: widget.allOptionGap ?? 8.0),
                                  Text(
                                    S.of(context).all,
                                    style: theme.textTheme.bodySmall?.copyWith(
                                      color: theme.hintColor,
                                      letterSpacing: -0.50,
                                    ),
                                  ),
                                  Transform.scale(
                                    scale: 0.7,
                                    child: Switch.adaptive(
                                      activeThumbColor: theme.primaryColor,
                                      value: widget.allValue ?? false,
                                      onChanged: widget.onChangedAllOption,
                                    ),
                                  ),
                                ],
                              ),
                          ],
                        ),
                        if (widget.labelHelperText != null) ...[
                          Text(
                            widget.labelHelperText!,
                            style: theme.textTheme.bodySmall
                                ?.copyWith(
                                  color: theme.hintColor,
                                  letterSpacing: -0.50,
                                  fontSize: 10.0,
                                )
                                .merge(widget.labelHelperStyle),
                            textAlign: TextAlign.start,
                          ),
                        ],
                      ],
                    ),
                    if (widget.subLabelText != null)
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 5.0),
                          child: Text(
                            widget.subLabelText!,
                            style:
                                widget.subLabelStyle ??
                                theme.textTheme.bodySmall?.copyWith(
                                  color: theme.hintColor,
                                  letterSpacing: -0.50,
                                ),
                            textAlign: TextAlign.start,
                          ),
                        ),
                      )
                    else
                      const Spacer(),
                    if (widget.labelTrailing != null) widget.labelTrailing!,
                  ],
                ),
                SizedBox(height: widget.spaceBetweenLabelAndField ?? 8.0),
              ],
              FormField<String>(
                initialValue: _initialValue,
                validator: widget.validator,
                autovalidateMode: widget.autoValidateMode,
                forceErrorText: widget.errorText,
                onSaved: widget.onSaved,
                enabled: !widget.readOnly || widget.onTap == null,
                builder: (FormFieldState<String> state) => Stack(
                  children: [
                    Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: widget.ignoreHeight ? null : widget.height,
                          child: WaitingShimmer(
                            loading: widget.isBusy,
                            borderRadius:
                                widget.borderRadius ?? AppUtil.borderRadius15,
                            child: GlobalCard(
                              onTap: widget.isBusy ? null : widget.onTap,
                              borderRadius:
                                  widget.borderRadius ?? AppUtil.borderRadius15,
                              color: widget.fillColor ?? theme.cardColor,
                              margin: EdgeInsets.zero,
                              elevation: 0.0,
                              borderColor:
                                  state.hasError || widget.errorText != null
                                  ? theme.colorScheme.error
                                  : widget.borderColor,
                              child: TextFormField(
                                autofillHints: widget.autoFillHints,
                                onFieldSubmitted: widget.onFieldSubmitted,
                                controller: _controller,
                                autofocus: widget.autoFocus,
                                onEditingComplete: widget.onEditSubmitted,
                                onChanged: (value) {
                                  widget.onChanged?.call(value);
                                  state.didChange(value);
                                },
                                readOnly:
                                    widget.readOnly || widget.onTap != null,
                                textAlign: widget.textAlignment,
                                textInputAction: TextInputAction.done,
                                cursorColor:
                                    widget.cursorColor ?? theme.primaryColor,
                                keyboardType: widget.keyBoardType,
                                maxLines: widget.hidePassword
                                    ? 1
                                    : widget.maxLines,
                                minLines: widget.minLines,
                                obscureText: widget.hidePassword,
                                style: theme.textTheme.bodyMedium
                                    ?.copyWith(fontWeight: FontWeight.w500)
                                    .merge(widget.style),
                                inputFormatters: widget.formatters,
                                focusNode: widget.focusNode,
                                textDirection:
                                    widget.textDirection ??
                                    (AppUtil.isLtr
                                        ? TextDirection.ltr
                                        : TextDirection.rtl),
                                decoration: InputDecoration(
                                  filled: true,
                                  fillColor: Colors.transparent,
                                  hintText: widget.hintText,
                                  hoverColor: widget.readOnly
                                      ? Colors.transparent
                                      : null,
                                  hintStyle: theme.textTheme.bodyMedium
                                      ?.copyWith(color: theme.hintColor)
                                      .merge(widget.hintStyle),
                                  labelText: widget.labelOnBorder
                                      ? widget.labelText
                                      : null,
                                  labelStyle: widget.labelOnBorder
                                      ? theme.textTheme.labelSmall
                                            ?.copyWith(
                                              fontWeight: FontWeight.w600,
                                              letterSpacing: -0.25,
                                            )
                                            .merge(widget.labelStyle)
                                      : null,
                                  contentPadding:
                                      widget.contentPadding ??
                                      EdgeInsets.symmetric(
                                        vertical: 5.0,
                                        horizontal:
                                            widget.suffixWidget != null ||
                                                widget.prefixWidget != null
                                            ? 12.0
                                            : 16.0,
                                      ),
                                  prefixIcon: widget.prefixWidget,
                                  suffixIconConstraints:
                                      BoxConstraints.tightFor(
                                        width: widget.suffixWidth ?? 56.0,
                                      ),
                                  prefixIconConstraints:
                                      BoxConstraints.tightFor(
                                        width: widget.prefixWidth ?? 56.0,
                                      ),
                                  suffixIcon:
                                      widget.suffixWidget == null &&
                                          !widget.isPassword
                                      ? null
                                      : widget.isCurrency
                                      ? SvgPicture.asset(
                                          PathUtil.saudiRiyalSVG,
                                          width: 12.0,
                                          height: 12.0,
                                          colorFilter: ColorFilter.mode(
                                            theme.canvasColor,
                                            BlendMode.srcIn,
                                          ),
                                        )
                                      : widget.suffixWidget ??
                                            (widget.isPassword
                                                ? InkWell(
                                                    onTap:
                                                        widget.changeObscuring,
                                                    borderRadius:
                                                        widget.borderRadius,
                                                    child: Padding(
                                                      padding:
                                                          const EdgeInsets.symmetric(
                                                            vertical: 7.0,
                                                            horizontal: 12.0,
                                                          ),
                                                      child: Icon(
                                                        widget.hidePassword
                                                            ? CupertinoIcons.eye
                                                            : CupertinoIcons
                                                                  .eye_slash,
                                                        size: 24.0,
                                                        color: theme
                                                            .primaryColor
                                                            .withValues(
                                                              alpha: 0.6,
                                                            ),
                                                      ),
                                                    ),
                                                  )
                                                : null),
                                  enabledBorder: AppUtil.outLineInputBorder(
                                    color: Colors.transparent,
                                    borderRadius: widget.borderRadius,
                                  ),
                                  disabledBorder: AppUtil.outLineInputBorder(
                                    color: Colors.transparent,
                                    borderRadius: widget.borderRadius,
                                  ),
                                  focusedBorder: AppUtil.outLineInputBorder(
                                    color: Colors.transparent,
                                    borderRadius: widget.borderRadius,
                                  ),
                                  border: AppUtil.outLineInputBorder(
                                    color: Colors.transparent,
                                    borderRadius: widget.borderRadius,
                                  ),
                                  errorBorder: AppUtil.errorOutLineInputBorder(
                                    context,
                                    borderRadius: widget.borderRadius,
                                  ),
                                  errorMaxLines: 5,
                                ),
                              ),
                            ),
                          ),
                        ),
                        if ((state.hasError && widget.showError) ||
                            (widget.errorText != null && widget.showError)) ...[
                          SizedBox(height: 4.0),
                          Text(
                            state.errorText ?? widget.errorText!,
                            style: theme.textTheme.bodySmall?.copyWith(
                              fontWeight: FontWeight.w500,
                              fontSize: 12.0,
                              letterSpacing: -0.15,
                              color: theme.colorScheme.error,
                            ),
                            maxLines: 3,
                            softWrap: true,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.start,
                          ),
                        ],
                      ],
                    ),
                    if (widget.readOnly && widget.onTap != null)
                      Positioned.fill(
                        child: InkWell(
                          onTap: () async {
                            if (widget.isBusy) return;

                            await widget.onTap!.call();
                            state.reset();
                            state.didChange(_controller.text);
                          },
                          borderRadius: widget.borderRadius,
                          child: const SizedBox.expand(),
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
