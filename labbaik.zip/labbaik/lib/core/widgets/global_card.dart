import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class GlobalCard extends StatelessWidget {
  final Widget child;
  final Color? color;
  final Color? borderColor;
  final BorderRadius? borderRadius;
  final EdgeInsets? margin;
  final EdgeInsets? padding;
  final double? elevation;
  final VoidCallback? onTap;
  final bool enableShadow;

  const GlobalCard({
    super.key,
    required this.child,
    this.color,
    this.borderColor,
    this.borderRadius,
    this.margin,
    this.padding,
    this.elevation,
    this.onTap,
    this.enableShadow = true,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    Widget card = Container(
      margin: margin,
      padding: padding,
      decoration: BoxDecoration(
        color: color ?? theme.cardColor,
        borderRadius: borderRadius ?? BorderRadius.circular(15.r),
        border: borderColor != null
            ? Border.all(color: borderColor!, width: 1.0)
            : null,
        boxShadow: enableShadow
            ? [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, 2),
                ),
              ]
            : null,
      ),
      child: child,
    );

    if (onTap != null) {
      return InkWell(
        onTap: onTap,
        borderRadius: borderRadius ?? BorderRadius.circular(15.r),
        child: card,
      );
    }

    return card;
  }
}
