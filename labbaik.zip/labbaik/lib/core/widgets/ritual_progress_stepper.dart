import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:labbaik/core/utilities/color_util.dart';
import 'package:labbaik/core/utilities/extensions.dart';
import 'package:labbaik/generated/l10n.dart';
import 'package:labbaik/core/models/ritual_guidance.dart';

/// A reusable progress stepper widget for displaying step progress
class RitualProgressStepper extends StatelessWidget {
  final List<RitualGuidance> steps;
  final int currentStepNumber;
  final Map<int, bool> progress;

  const RitualProgressStepper({
    super.key,
    required this.steps,
    required this.currentStepNumber,
    required this.progress,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(20).r,
      decoration: BoxDecoration(
        color: context.isDarkTheme ? ColorUtil.black : ColorUtil.white,
        borderRadius: BorderRadius.circular(20).r,
        border: Border.all(
          color: context.isDarkTheme
              ? ColorUtil.black.withValues(alpha: 0.3)
              : ColorUtil.white.withValues(alpha: 0.3),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: context.isDarkTheme
                ? Colors.black.withValues(alpha: 0.1)
                : ColorUtil.black.withValues(alpha: 0.1),
            blurRadius: 20,
            offset: const Offset(0, 10),
            spreadRadius: 0,
          ),
        ],
      ),
      child: Column(
        children: [
          // Progress Title with Icon
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: EdgeInsets.all(6).r,
                decoration: BoxDecoration(
                  color: ColorUtil.accentColor.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8).r,
                ),
                child: Icon(
                  Icons.timeline_rounded,
                  size: 16.spMin,
                  color: ColorUtil.accentColor,
                ),
              ),
              8.horizontalSpace,
              Text(
                S.of(context).progress,
                style: TextStyle(
                  fontSize: 16.sp,
                  fontWeight: FontWeight.bold,
                  color: ColorUtil.darkGrey,
                ),
              ),
            ],
          ),
          20.verticalSpace,
          Row(
            children: steps.asMap().entries.map((entry) {
              final index = entry.key;
              final step = entry.value;
              final isActive = step.stepNumber == currentStepNumber;
              final isCompleted = progress[step.stepNumber] ?? false;
              final isLast = index == steps.length - 1;

              return Expanded(
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        children: [
                          // Step Circle
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 300),
                            width: isActive ? 44.r : 40.r,
                            height: isActive ? 44.r : 40.r,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              gradient: isCompleted || isActive
                                  ? LinearGradient(
                                      begin: Alignment.topLeft,
                                      end: Alignment.bottomRight,
                                      colors: [
                                        ColorUtil.accentColor,
                                        ColorUtil.accentColor.withValues(
                                          alpha: 0.8,
                                        ),
                                      ],
                                    )
                                  : null,
                              color: isCompleted || isActive
                                  ? null
                                  : Colors.grey.shade100,
                              border: Border.all(
                                color: isCompleted || isActive
                                    ? ColorUtil.accentColor
                                    : ColorUtil.accentColor.withValues(
                                        alpha: 0.3,
                                      ),
                                width: isActive ? 3 : 2,
                              ),
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: (isCompleted || isActive)
                                      ? ColorUtil.accentColor.withValues(
                                          alpha: 0.4,
                                        )
                                      : Colors.black.withValues(alpha: 0.05),
                                  blurRadius: isActive ? 12 : 8,
                                  offset: const Offset(0, 2),
                                  spreadRadius: isActive ? 1 : 0,
                                ),
                              ],
                            ),
                            child: isCompleted
                                ? Icon(
                                    Icons.check_rounded,
                                    size: 20.spMin,
                                    color: Colors.white,
                                  )
                                : isActive
                                ? Container(
                                    width: 16.r,
                                    height: 16.r,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      shape: BoxShape.circle,
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.black.withValues(
                                            alpha: 0.1,
                                          ),
                                          blurRadius: 4,
                                          offset: const Offset(0, 1),
                                        ),
                                      ],
                                    ),
                                  )
                                : Text(
                                    '${step.stepNumber}',
                                    style: TextStyle(
                                      fontSize: 14.sp,
                                      fontWeight: FontWeight.bold,
                                      color: ColorUtil.accentColor.withValues(
                                        alpha: 0.6,
                                      ),
                                    ),
                                  ),
                          ),
                          8.verticalSpace,
                          // Step Title
                          Text(
                            step.title,
                            style: TextStyle(
                              fontSize: 12.sp,
                              fontWeight: isActive
                                  ? FontWeight.bold
                                  : FontWeight.w500,
                              color: isActive
                                  ? ColorUtil.accentColor
                                  : ColorUtil.blueGreyColor,
                            ),
                            textAlign: TextAlign.center,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                    // Connector Line
                    if (!isLast)
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 500),
                        height: 3,
                        width: 20.w,
                        margin: EdgeInsets.only(bottom: 20.r),
                        decoration: BoxDecoration(
                          gradient: isCompleted
                              ? LinearGradient(
                                  colors: [
                                    ColorUtil.accentColor,
                                    ColorUtil.accentColor.withValues(
                                      alpha: 0.7,
                                    ),
                                  ],
                                )
                              : null,
                          color: isCompleted
                              ? null
                              : ColorUtil.accentColor.withValues(alpha: 0.2),
                          borderRadius: BorderRadius.circular(2),
                          boxShadow: isCompleted
                              ? [
                                  BoxShadow(
                                    color: ColorUtil.accentColor.withValues(
                                      alpha: 0.3,
                                    ),
                                    blurRadius: 4,
                                    offset: const Offset(0, 1),
                                  ),
                                ]
                              : null,
                        ),
                      ),
                  ],
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}
