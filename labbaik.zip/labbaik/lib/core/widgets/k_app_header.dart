import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:go_router/go_router.dart';
import 'package:labbaik/core/utilities/extensions.dart';

import '../utilities/path_util.dart';

class KAppHeader extends StatelessWidget {
  final String? title;
  final Widget? leading;
  final bool showBackButton;
  final Widget? trailing;
  final bool showTrailing;
  const KAppHeader({
    super.key,
    this.title,
    this.leading,
    this.trailing,
    this.showBackButton = true,
    this.showTrailing = true,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.max,
          children: [
            if (showBackButton)
              IconButton(
                onPressed: () => context.pop(),
                icon: const Icon(Icons.arrow_back_ios),
              ),
            if (showTrailing)
              trailing ??
                  SvgPicture.asset(PathUtil.logoLight, width: 30, height: 30),
          ],
        ),

        if (title != null)
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            child: Center(
              child: Text(
                title!,
                style: context.isDarkTheme
                    ? Theme.of(
                        context,
                      ).textTheme.headlineMedium?.copyWith(color: Colors.white)
                    : Theme.of(
                        context,
                      ).textTheme.headlineMedium?.copyWith(color: Colors.black),
              ),
            ),
          ),
      ],
    );
  }
}
