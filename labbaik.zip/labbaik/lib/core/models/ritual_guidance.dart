import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';

import '../../../core/utilities/path_util.dart';
import '../../../generated/l10n.dart';
import 'ritual_guidance_sub_step.dart';

enum RitualGuidanceStatus { completed, active, pending, none }

enum RitualGuidanceStatusString {
  completed("completed"),
  active("active"),
  pending("pending"),
  none("none");

  final String value;

  const RitualGuidanceStatusString(this.value);

  @override
  String toString() {
    switch (this) {
      case RitualGuidanceStatusString.completed:
        return S.current.completed;
      case RitualGuidanceStatusString.active:
        return S.current.active;
      case RitualGuidanceStatusString.pending:
        return S.current.pending;
      case RitualGuidanceStatusString.none:
        return S.current.none;
    }
  }
}

class RitualGuidance extends Equatable {
  final int stepNumber;
  final String? stepTitle;
  final String title;
  final String? subtitle;
  final String description;
  final List<String>? subDescriptions;
  final String icon;
  final RitualGuidanceStatus status;
  final List<RitualGuidanceSubStep>? subSteps;
  final List<RitualGuidance>? nestedSteps;

  const RitualGuidance({
    required this.stepNumber,
    this.stepTitle,
    required this.title,
    this.subtitle,
    required this.description,
    this.subDescriptions = const [],
    required this.icon,
    this.status = RitualGuidanceStatus.none,
    this.subSteps = const [],
    this.nestedSteps = const [],
  });

  @override
  List<Object?> get props => [
    stepNumber,
    title,
    icon,
    status,
    subSteps,
    nestedSteps,
  ];
}

List<RitualGuidance> getUmrahGuidance(
  BuildContext context, {
  Map<int, bool>? progress,
}) {
  final progressMap = progress ?? {};

  return [
    RitualGuidance(
      stepNumber: 1,
      title: S.of(context).ihram,
      description: S.of(context).step1GuidanceDescription,
      icon: PathUtil.step1,
      status: progressMap[1] == true
          ? RitualGuidanceStatus.completed
          : RitualGuidanceStatus.pending,
      subSteps: [
        RitualGuidanceSubStep(
          title: S.of(context).enteringIhramAtMiqat,
          description: S.of(context).enteringIhramAtMiqatDescription,
        ),

        RitualGuidanceSubStep(
          title: S.of(context).enteringIhramFromAirplane,
          description: S.of(context).enteringIhramFromAirplaneDescription,
        ),
        RitualGuidanceSubStep(
          title: S.of(context).mensIhramGarments,
          description: S.of(context).mensIhramGarmentsDescription,
          images: [PathUtil.ihramGarment1, PathUtil.ihramGarment2],
        ),
        RitualGuidanceSubStep(
          title: S.of(context).womensIhramGarments,
          description: S.of(context).womensIhramGarmentsDescription,
          images: [PathUtil.ihramGarment3, PathUtil.ihramGarment4],
        ),

        RitualGuidanceSubStep(
          title: S.of(context).prohibitionsOfIhram,
          steps: [
            S.of(context).prohibitionWearingStitchedClothing,
            S.of(context).prohibitionCoveringHead,
            S.of(context).prohibitionShavingHair,
            S.of(context).prohibitionHunting,
            S.of(context).prohibitionCuttingNails,
            S.of(context).prohibitionApplyingPerfume,
            S.of(context).prohibitionNiqabGloves,
            S.of(context).prohibitionMarriageContract,
            S.of(context).prohibitionSexualIntercourse,
          ],
        ),
      ],
    ),
    RitualGuidance(
      stepNumber: 2,
      title: S.of(context).tawaf,
      status: progressMap[2] == true
          ? RitualGuidanceStatus.completed
          : RitualGuidanceStatus.pending,
      description: S.of(context).step2GuidanceDescription,
      subDescriptions: [
        S.of(context).tawafSubDesc1,
        S.of(context).tawafSubDesc2,
        S.of(context).tawafSubDesc3,
        S.of(context).tawafSubDesc4,
        S.of(context).tawafSubDesc5,
        S.of(context).tawafSubDesc6,
        S.of(context).tawafSubDesc7,
      ],
      icon: PathUtil.step2,
    ),
    RitualGuidance(
      stepNumber: 3,
      title: S.of(context).saee,
      description: S.of(context).step3Description,
      subDescriptions: [
        S.of(context).saeeSubDesc1,
        S.of(context).saeeSubDesc2,
        S.of(context).saeeSubDesc3,
        S.of(context).saeeSubDesc4,
      ],
      icon: PathUtil.step3,
      status: progressMap[3] == true
          ? RitualGuidanceStatus.completed
          : RitualGuidanceStatus.pending,
    ),
    RitualGuidance(
      stepNumber: 4,
      title: S.of(context).tahallul,
      description: S.of(context).step4Description,
      icon: PathUtil.step4,
      status: progressMap[4] == true
          ? RitualGuidanceStatus.completed
          : RitualGuidanceStatus.pending,
    ),
  ];
}

Function() dummyInitalStep = () => RitualGuidance(
  stepNumber: -1,
  // Beginning
  stepTitle: S.current.beginning,
  // Your Hajj Journey
  title: S.current.yourHajjJourney,
  description: '',
  icon: PathUtil.step1,
  status: RitualGuidanceStatus.none,
  subSteps: [
    RitualGuidanceSubStep(
      // Hajj al-Ifrad
      title: S.current.hajjAlIfradTitle,
      isListTile: true,
      description: S.current.hajjAlIfradDescription,
    ),
    RitualGuidanceSubStep(
      // Hajj al-Qiran
      title: S.current.hajjAlQiranTitle,
      isListTile: true,
      description: S.current.hajjAlQiranDescription,
    ),
    RitualGuidanceSubStep(
      // Hajj al-Tamattu
      title: S.current.hajjAlTamattuTitle,
      isListTile: true,
      description: S.current.hajjAlTamattuDescription,
    ),
  ],
);

Function() dummyHijjProgressSteps = () => [
  RitualGuidance(
    stepNumber: 1,
    stepTitle: S.current.eighthDhulHijjah,
    title: S.current.dayOfTarwiyah,
    description: S.current.hajjDay8Description,
    icon: PathUtil.dayOfTarwiyah,
    status: RitualGuidanceStatus.pending,
    nestedSteps: [
      RitualGuidance(
        stepNumber: 1,
        title: S.current.hajjStepIhram,
        description: S.current.hajjStepIhramDescription,
        icon: PathUtil.step1,
        subSteps: [
          RitualGuidanceSubStep(
            title: S.current.enteringIhramAtMiqat,
            isListTile: true,
            description: S.current.enteringIhramAtMiqatDescription,
          ),
          RitualGuidanceSubStep(
            title: S.current.enteringIhramFromAirplane,
            isListTile: true,
            description: S.current.enteringIhramFromAirplaneDescription,
          ),
          RitualGuidanceSubStep(
            title: S.current.mensIhramGarments,
            isListTile: true,
            description: S.current.mensIhramGarmentsDescription,
            images: [PathUtil.ihramGarment1, PathUtil.ihramGarment2],
          ),
          RitualGuidanceSubStep(
            title: S.current.womensIhramGarments,
            isListTile: true,
            description: S.current.womensIhramGarmentsDescription,
            images: [PathUtil.ihramGarment3, PathUtil.ihramGarment4],
          ),
          RitualGuidanceSubStep(
            title: S.current.prohibitionsOfIhram,
            isListTile: true,
            steps: [
              S.current.prohibitionWearingStitchedClothing,
              S.current.prohibitionCoveringHead,
              S.current.prohibitionShavingHair,
              S.current.prohibitionHunting,
              S.current.prohibitionCuttingNails,
              S.current.prohibitionApplyingPerfume,
              S.current.prohibitionNiqabGloves,
              S.current.prohibitionMarriageContract,
              S.current.prohibitionSexualIntercourse,
            ],
          ),
        ],
      ),
      RitualGuidance(
        stepNumber: 2,
        title: S.current.hajjStepTawafAlQudum,
        description: S.current.hajjStepTawafAlQudumDescription,
        icon: PathUtil.step2,
      ),
      RitualGuidance(
        stepNumber: 3,
        title: S.current.hajjStepMina,
        description: S.current.hajjStepMinaDescription,
        icon: PathUtil.mina,
      ),
    ],
  ),
  RitualGuidance(
    stepNumber: 2,
    stepTitle: S.current.ninthDhulHijjah,
    title: S.current.day1,
    subtitle: S.current.dayOfArafah,
    description: S.current.hajjDay9Description,
    icon: PathUtil.dayOfTarwiyah,
    status: RitualGuidanceStatus.pending,
    nestedSteps: [
      RitualGuidance(
        stepNumber: 1,
        title: S.current.hajjStepArafat,
        description: S.current.hajjStepArafatDescription,
        icon: PathUtil.step1,
        subSteps: [
          RitualGuidanceSubStep(title: S.current.hajjStepArafatSubStep1),
          RitualGuidanceSubStep(title: S.current.hajjStepArafatSubStep2),
          RitualGuidanceSubStep(title: S.current.hajjStepArafatSubStep3),
          RitualGuidanceSubStep(title: S.current.hajjStepArafatSubStep4),
          RitualGuidanceSubStep(title: S.current.hajjStepArafatSubStep5),
        ],
      ),
      RitualGuidance(
        stepNumber: 2,
        title: S.current.hajjStepMuzdalifah,
        description: "",
        icon: PathUtil.step2,
        subSteps: [
          RitualGuidanceSubStep(title: S.current.hajjStepMuzdalifahSubStep1),
          RitualGuidanceSubStep(title: S.current.hajjStepMuzdalifahSubStep2),
          RitualGuidanceSubStep(title: S.current.hajjStepMuzdalifahSubStep3),
        ],
      ),
    ],
  ),
  RitualGuidance(
    stepNumber: 3,
    stepTitle: S.current.tenthDhulHijjah,
    title: S.current.day2,
    subtitle: S.current.dayOfNahr,
    description: S.current.hajjDay10Description,
    icon: PathUtil.dayOfTarwiyah,
    status: RitualGuidanceStatus.pending,
    nestedSteps: [
      RitualGuidance(
        stepNumber: 1,
        title: S.current.hajjStepMina,
        description: S.current.hajjStepMinaJamratAlAqabahDescription,
        icon: PathUtil.step1,
        subSteps: [
          RitualGuidanceSubStep(
            title: S.current.hajjStepMinaJamratAlAqabahSubStep1,
          ),
          RitualGuidanceSubStep(
            title: S.current.hajjStepMinaJamratAlAqabahSubStep2,
          ),
          RitualGuidanceSubStep(
            title: S.current.hajjStepMinaJamratAlAqabahSubStep3,
          ),
        ],
      ),
      RitualGuidance(
        stepNumber: 2,
        title: S.current.hajjStepAlHady,
        description: S.current.hajjStepAlHadyDescription,
        icon: PathUtil.step2,
        subSteps: [
          RitualGuidanceSubStep(title: S.current.hajjStepAlHadySubStep1),
          RitualGuidanceSubStep(title: S.current.hajjStepAlHadySubStep2),
        ],
      ),
      RitualGuidance(
        stepNumber: 3,
        title: S.current.hajjStepTahallul,
        description: S.current.hajjStepTahallulDescription,
        icon: PathUtil.step3,
        subSteps: [
          RitualGuidanceSubStep(title: S.current.hajjStepTahallulSubStep1),
          RitualGuidanceSubStep(title: S.current.hajjStepTahallulSubStep2),
        ],
      ),
      RitualGuidance(
        stepNumber: 4,
        title: S.current.hajjStepTawafAlIfadah,
        description: S.current.hajjStepTawafAlIfadahDescription,
        icon: PathUtil.step4,
        subSteps: [
          RitualGuidanceSubStep(title: S.current.hajjStepTawafAlIfadahSubStep1),
          RitualGuidanceSubStep(title: S.current.hajjStepTawafAlIfadahSubStep2),
          RitualGuidanceSubStep(title: S.current.hajjStepTawafAlIfadahSubStep3),
        ],
      ),
      RitualGuidance(
        stepNumber: 5,
        title: S.current.hajjStepStayingInMina,
        description: S.current.hajjStepStayingInMinaDescription,
        icon: PathUtil.step1,
        subSteps: [
          RitualGuidanceSubStep(title: S.current.hajjStepStayingInMinaSubStep1),
          RitualGuidanceSubStep(title: S.current.hajjStepStayingInMinaSubStep2),
        ],
      ),
    ],
  ),
  RitualGuidance(
    stepNumber: 4,
    // from 11 to 13
    stepTitle: S.current.elevensToThirteenthDhulHijjah,
    title: S.current.day3To5,
    subtitle: S.current.daysOfTashreeq,
    description: S.current.hajjDay11_13Description,
    icon: PathUtil.dayOfTarwiyah,
    status: RitualGuidanceStatus.pending,
    nestedSteps: [
      RitualGuidance(
        stepNumber: 1,
        title: S.current.hajjStepJamarat,
        description: S.current.hajjStepJamaratDescription,
        icon: PathUtil.step1,
        subSteps: [
          RitualGuidanceSubStep(
            title: S.current.hajjStepJamaratSubStep1,
            isListTile: false,
          ),
          RitualGuidanceSubStep(
            title: S.current.hajjStepJamaratSubStep2,
            isListTile: false,
          ),
          RitualGuidanceSubStep(
            title: S.current.hajjStepJamaratSubStep3,
            isListTile: false,
          ),
          RitualGuidanceSubStep(
            title: S.current.hajjStepJamaratSubStep4,
            isListTile: false,
          ),
          RitualGuidanceSubStep(
            title: S.current.hajjStepJamaratSubStep5,
            isListTile: false,
          ),
          RitualGuidanceSubStep(
            title: S.current.hajjStepJamaratSubStep6,
            isListTile: false,
          ),
        ],
      ),
      RitualGuidance(
        stepNumber: 2,
        title: S.current.hajjStepTawafAlWada,
        description: S.current.hajjStepTawafAlWadaDescription,
        icon: PathUtil.step2,
        subSteps: [
          RitualGuidanceSubStep(title: S.current.hajjStepTawafAlWadaSubStep1),
          RitualGuidanceSubStep(title: S.current.hajjStepTawafAlWadaSubStep2),
          RitualGuidanceSubStep(title: S.current.hajjStepTawafAlWadaSubStep3),
          RitualGuidanceSubStep(title: S.current.hajjStepTawafAlWadaSubStep4),
        ],
      ),
    ],
  ),
];
