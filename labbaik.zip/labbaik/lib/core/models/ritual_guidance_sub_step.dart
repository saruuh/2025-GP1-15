import 'package:equatable/equatable.dart';

class RitualGuidanceSubStep extends Equatable {
  final String title;
  final bool isListTile;
  final String? description;
  final List<String> images;
  final List<String> steps;

  const RitualGuidanceSubStep({
    required this.title,
    this.isListTile = false,
    this.description,
    this.images = const [],
    this.steps = const [],
  });

  @override
  List<Object?> get props => [title, isListTile, description, images, steps];
}
