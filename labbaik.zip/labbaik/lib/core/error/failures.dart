import 'package:equatable/equatable.dart';

import '../../generated/l10n.dart';

sealed class Failure extends Equatable {}

final class CacheFailure extends Failure {
  @override
  List<Object?> get props => [];
}

final class ServerFailure extends Failure {
  @override
  List<Object?> get props => [];
}

final class MissingDataFailure extends Failure {
  @override
  List<Object?> get props => [];
}

final class CancelFailure extends Failure {
  @override
  List<Object?> get props => [];
}

final class NoConnectionFailure extends Failure {
  @override
  List<Object?> get props => [];
}

final class FormatFailure extends Failure {
  @override
  List<Object?> get props => [];
}

final class ResponseFailure extends Failure {
  final String? message;

  ResponseFailure({this.message});

  @override
  List<Object?> get props => [message];
}

String mapFailureToException(Failure failure) => switch (failure.runtimeType) {
      const (ServerFailure) => S.current.httpException,
      const (CacheFailure) => S.current.cacheException,
      const (FormatFailure) => S.current.formatException,
      const (CancelFailure) => S.current.cancelException,
      const (NoConnectionFailure) => S.current.socketException,
      const (MissingDataFailure) => S.current.dataNotCompleted,
      const (ResponseFailure) =>
        (failure as ResponseFailure).message ?? S.current.error,
      _ => S.current.error,
    };
