import 'package:flutter/material.dart';
import 'package:labbaik/app/app.dart';
import 'package:provider/provider.dart'
    show MultiProvider, ChangeNotifierProvider;

import '../../features/auth/controller/auth_provider.dart';
import '../../features/home/controller/prayer_times_provider.dart';
import '../../features/settings/controller/settings_controller.dart';

/// Provider configuration utility
/// This class handles the setup of providers for the app
/// and can be used in both development and production environments
class ProviderConfig {
  /// Get the configured MultiProvider widget
  /// This includes all the providers needed for the app
  static Widget getProviderWidget() {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (context) => AuthProvider()),
        ChangeNotifierProvider(create: (context) => PrayerTimesProvider()),
        ChangeNotifierProvider(create: (context) => SettingsController()),
      ],
      child: const MyApp(),
    );
  }
}
