import 'dart:ui';

import 'package:flutter/material.dart' show BuildContext, Theme;
import 'package:flutter/widgets.dart' show MediaQuery;
import 'dart:math' as math;

import '../../generated/l10n.dart' show S;
import '../../core/services/locale_service.dart';

extension ThemeExtension on BuildContext {
  bool get isDarkTheme => Theme.of(this).brightness == Brightness.dark;

  Color get hintColor => Theme.of(this).hintColor;
  Color get primaryColor => Theme.of(this).primaryColor;
  Color get cardColor => Theme.of(this).cardColor;
  Color get canvasColor => Theme.of(this).canvasColor;
  Color get secondaryColor => Theme.of(this).colorScheme.secondary;
}

extension Capitalizing on String {
  String get capitalized {
    if (isEmpty) return '';
    return replaceFirst(this[0], this[0].toUpperCase());
  }
}

extension ContextExtension on BuildContext {
  // SettingsCubit get settingsCubit => read<SettingsCubit>();
  bool get isArabic => LocaleService.instance.isArabic;

  /// Returns the screen height
  double get screenHeight => MediaQuery.of(this).size.height;

  /// Returns the screen width
  double get screenWidth => MediaQuery.of(this).size.width;
}

// Create a new file: datetime_extensions.dart
extension DateTimeExtensions on DateTime {
  /// Returns a human-readable string representing how long ago this DateTime was
  /// Example: "قبل 15 ساعة", "قبل يوم", "قبل 3 أيام"
  String timeAgo({bool isShort = false}) {
    final now = DateTime.now();
    final localDate = toLocal();
    final nowLocal = now.toLocal();

    final diff = nowLocal.difference(localDate);

    int value;
    String pattern;

    if (diff.inDays >= 365) {
      value = diff.inDays ~/ 365;
      pattern = isShort
          ? S.current.timeAgoShort(value, S.current.unit_yearShort)
          : S.current.timeAgoYears(value);
    } else if (diff.inDays >= 30) {
      value = diff.inDays ~/ 30;
      pattern = isShort
          ? S.current.timeAgoShort(value, S.current.unit_monthShort)
          : S.current.timeAgoMonths(value);
    } else if (diff.inDays >= 1) {
      value = diff.inDays;
      pattern = isShort
          ? S.current.timeAgoShort(value, S.current.unit_dayShort)
          : S.current.timeAgoDays(value);
    } else if (diff.inHours >= 1) {
      value = diff.inHours;
      pattern = isShort
          ? S.current.timeAgoShort(value, S.current.unit_hourShort)
          : S.current.timeAgoHours(value);
    } else if (diff.inMinutes >= 1) {
      value = diff.inMinutes;
      pattern = isShort
          ? S.current.timeAgoShort(value, S.current.unit_minuteShort)
          : S.current.timeAgoMinutes(value);
    } else {
      value = math.max(diff.inSeconds, 1);
      pattern = isShort
          ? S.current.timeAgoShort(value, S.current.unit_secondShort)
          : S.current.timeAgoSeconds(value);
    }

    return pattern;
  }

  /// Returns a short human-readable string representing how long ago this DateTime was
  /// Example: "15س", "1ي", "3أ"
  String timeAgoShort() => timeAgo(isShort: true);

  /// Checks if this DateTime is today
  bool get isToday {
    final now = DateTime.now();
    return year == now.year && month == now.month && day == now.day;
  }

  /// Checks if this DateTime is yesterday
  bool get isYesterday {
    final yesterday = DateTime.now().subtract(Duration(days: 1));
    return year == yesterday.year &&
        month == yesterday.month &&
        day == yesterday.day;
  }

  /// Checks if this DateTime is within the last week
  bool get isThisWeek {
    final now = DateTime.now();
    final weekAgo = now.subtract(Duration(days: 7));
    return isAfter(weekAgo);
  }

  /// Returns the number of days between this DateTime and now
  int get daysAgo {
    final now = DateTime.now();
    final difference = now.difference(this);
    return difference.inDays;
  }

  /// Returns the number of hours between this DateTime and now
  int get hoursAgo {
    final now = DateTime.now();
    final difference = now.difference(this);
    return difference.inHours;
  }

  /// Returns the number of minutes between this DateTime and now
  int get minutesAgo {
    final now = DateTime.now();
    final difference = now.difference(this);
    return difference.inMinutes;
  }
}
