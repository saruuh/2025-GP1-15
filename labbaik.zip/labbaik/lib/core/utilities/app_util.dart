import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class AppUtil {
  // Border radius constants
  static BorderRadius get borderRadius15 => BorderRadius.circular(15.r);
  static BorderRadius get borderRadius12 => BorderRadius.circular(12.r);
  static BorderRadius get borderRadius8 => BorderRadius.circular(8.r);

  // Language direction
  static bool get isLtr => true; // You can implement proper RTL detection here

  // Input border methods
  static OutlineInputBorder outLineInputBorder({
    required Color color,
    BorderRadius? borderRadius,
    double width = 1.0,
  }) {
    return OutlineInputBorder(
      borderRadius: borderRadius ?? borderRadius15,
      borderSide: BorderSide(color: color, width: width),
    );
  }

  static OutlineInputBorder errorOutLineInputBorder(
    BuildContext context, {
    BorderRadius? borderRadius,
    double width = 1.0,
  }) {
    return OutlineInputBorder(
      borderRadius: borderRadius ?? borderRadius15,
      borderSide: BorderSide(
        color: Theme.of(context).colorScheme.error,
        width: width,
      ),
    );
  }
}
