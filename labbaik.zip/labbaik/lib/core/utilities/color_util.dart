import 'package:flutter/material.dart';

// Light Theme Colors
class LightThemeColors {
  static Color scaffold = const Color(0xffffffff);
  static Color surface = const Color(0xffffffff);
  static Color background = const Color(0xfff9fbfb);
  static Color card = const Color(0xffEFEFEF);
  static Color textPrimary = Colors.black;
  static Color textSecondary = const Color(0xff525252);
  static Color textHint = const Color(0xff737477);
  static Color border = const Color(0xffEEEEEE);
  static Color inputFill = const Color(0xfff6fbfb);
  static Color inputBorder = const Color(0xfff9f9f9);
  static Color shadow = const Color(0xff737477);
  static Color divider = const Color(0xffd9d9d9);
}

// Dark Theme Colors
class DarkThemeColors {
  static Color scaffold = const Color(0xff121212);
  static Color surface = const Color(0xff1e1e1e);
  static Color background = const Color(0xff181818);
  static Color card = const Color(0xff2d2d2d);
  static Color textPrimary = Colors.white;
  static Color textSecondary = const Color(0xffb3b3b3);
  static Color textHint = const Color(0xff666666);
  static Color border = const Color(0xff333333);
  static Color inputFill = const Color(0xff2d2d2d);
  static Color inputBorder = const Color(0xff404040);
  static Color shadow = Colors.black54;
  static Color divider = const Color(0xff333333);
}

class ColorUtil {
  // Primary colors - Dark green theme
  static const Color primaryColor = Color(0xFF2D5A3D); // Dark green
  static const Color accentColor = Color(0xFFD4AF37); // Gold
  static const Color secondaryColor = Color(0xFFF5E6A3); // Light gold

  // Primary Color Variants - Dark green palette
  static const Color primaryW700 = Color(0xFF1A2E1F);
  static const Color primaryW600 = Color(0xFF2D5A3D);
  static const Color primaryW500 = Color(0xFF3D6B4F);
  static const Color primaryW400 = Color(0xFF4A7C5A);
  static const Color primaryW300 = Color(0xFF5A8C6A);
  static const Color primaryW200 = Color(0xFF7BA68B);
  static const Color primaryW100 = Color(0xFFB8D4C1);
  static const Color primaryW50 = Color(0xFFE8F5E8);

  // Secondary Colors - Gold/Beige theme
  static const Color secondary = Color(0xFFD4AF37); // Gold
  static const Color secondaryPrimary = Color(0xFFF5E6A3); // Light gold
  static const Color secondaryPrimaryDark = Color(0xFFB8941F); // Dark gold
  static const Color secondaryPrimaryLight = Color(
    0xFFF9F0C7,
  ); // Very light gold

  // Design-specific colors for UI elements
  static const Color selectedTabBg = Color(
    0xFFF5E6A3,
  ); // Light gold/beige for selected tabs
  static const Color selectedTabText = Color(
    0xFF333333,
  ); // Dark gray for selected tab text
  static const Color unselectedTabBg = Color(
    0xFFFFFFFF,
  ); // White for unselected tabs
  static const Color unselectedTabText = Color(
    0xFF737477,
  ); // Light gray for unselected tab text
  static const Color languageButtonBg = Color(
    0xFF2D5A3D,
  ); // Dark green for language button
  static const Color languageButtonText = Color(
    0xFFFFFFFF,
  ); // White text for language button
  static const Color linkColor = Color(
    0xFF266CB2,
  ); // Blue for links like "Forgot Password?"

  // Basic Colors
  static const Color transparent = Colors.transparent;
  static const Color black = Colors.black;
  static const Color white = Colors.white;

  // Background colors
  static const Color scaffoldBGColor = Color.fromARGB(
    255,
    248,
    248,
    248,
  ); // White background

  // Text colors
  static const Color darkGrey = Color(0xFF333333); // Dark gray for main text
  static const Color lightGrey = Color.fromARGB(
    255,
    178,
    178,
    179,
  ); // Light gray for secondary text
  static const Color blueGreyColor = Color(0xFF525252); // Medium gray

  // Status colors
  static const Color availableColor = Color(0xFF0ED646);
  static const Color unavailableColor = Color(0xFFB8B8B8);
  static const Color errorColor = Color(0xFFE53E3E);
  static const Color successColor = Color(0xFF38A169);
  static const Color warningColor = Color(0xFFED8936);

  // Icon colors
  static const Color iconPrimaryColor = primaryColor; // Dark green for icons

  // Legacy colors (keeping for backward compatibility)
  static const Color primaryWithObesity = Color(0xffdff6f9);
  static const Color chatBgColor = Color(0xfff9f9f9);
  static const Color fromPrimarySearchBg = Color(0xfff2f5f6);
  static const Color splash = Color(0xff021F4A);
  static const Color containerBgColor = Color(0xff51a1a8);
  static const Color borderColor = Color(0xffEEEEEE);
  static const Color txtFiledBorderColor = Color(0xfff9f9f9);
  static const Color txtFiledFillColor = Color(0xfff6fbfb);
  static const Color pinPutFillColor = Color(0xfff6fbfb);
  static const Color accountTypeColor = Color(0x0ff8f8f9);
  static const Color subTitleColor = Color(0xff000000);
  static const Color catTextColor = Color(0xffc3dadc);
  static const Color yellow = Colors.yellow;
  static const Color star = Colors.amber;
  static const Color darkGreyLegacy = Color(0xff525252);
  static const Color grey = Color(0xff737477);
  static const Color grey3 = Color(0xffd9d9d9);
  static const Color lightBlack = Color(0x86000000);
  static const Color blueGray = Color(0xff3c5767);
  static const Color blue = Color(0xff021F4A);
  static const Color red = Color(0xffe61f34);
  static const Color linkBlue = Color(0xff266cb2);
  static const Color chatFriendBubbleColor = Color(0xff37494b);
  static const Color textForm = Color(0xffE1DFDF);
  static const Color textFiled = Color(0xffeeefee);
  static const Color card = Color(0xffEFEFEF);
  static const Color homeScaffoldColor = Color(0xfff9fbfb);
  static const Color selectWeekColor = Color(0xffe7f2f3);
  static const Color selectDayColor = Color(0xffdcecec);
  static const Color eventCircleColor = Color(0xffc4dfe4);
  static const Color eventCircleBorderColor = Color(0xffd1d0d0);
  static const Color eventTitleColor = Color(0xff565656);
  static const Color story = Color(0xff1C96A7);
  static const Color grey1 = Color(0xff707070);
  static const Color grey2 = Color(0xff797979);
  static const Color green = Color(0xff06D81E);
}
