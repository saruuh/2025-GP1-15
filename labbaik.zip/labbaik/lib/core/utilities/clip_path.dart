// import 'package:flutter/material.dart';
import 'dart:math';

import 'package:flutter/material.dart';

class CenterCutClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    double xFactor = 18, yFactor = 15;
    double height = size.height;
    double startY = (height / 2) - yFactor; // Adjusted startY to center

    double xVal = size.width;
    double yVal = 0;
    final path = Path();

    path.lineTo(xVal, yVal);

    yVal = startY;
    path.lineTo(xVal, yVal);

    double scale = 1.4;
    path.cubicTo(
      xVal,
      yVal,
      xVal,
      yVal + yFactor * scale,
      xVal - xFactor * scale,
      yVal + yFactor * scale,
    );
    xVal = xVal - xFactor * scale;
    yVal = yVal + yFactor * scale;

    double scale1 = 1;
    path.cubicTo(
      xVal,
      yVal,
      xVal - xFactor * scale1,
      yVal,
      xVal - scale1 * xFactor,
      yVal + yFactor * scale1,
    );
    xVal = xVal - scale1 * xFactor;
    yVal = yVal + scale1 * yFactor;
    double scale2 = 1.2;
    path.cubicTo(
      xVal,
      yVal,
      xVal,
      yVal + yFactor * scale2,
      xVal + xFactor * scale2,
      yVal + yFactor * scale2,
    );
    xVal = xVal + xFactor * scale2;
    yVal = yVal + yFactor * scale2;

    scale = 1.6;

    path.cubicTo(
      xVal,
      yVal,
      xVal + xFactor * scale,
      yVal,
      xVal + xFactor * scale,
      yVal + yFactor * scale,
    );
    xVal = xVal + xFactor * scale;
    yVal = yVal + yFactor * scale;

    path.lineTo(xVal, height);
    path.lineTo(0, height);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    return true;
  }
}

class BottomHalfCircleClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    double radius = 50.0; // Adjust the radius as needed
    double centerY = size.height;
    // double centerX = size.width / 2;

    final path = Path();

    path.moveTo(0, 0);
    path.lineTo(size.width, 0);
    path.lineTo(size.width, centerY - radius);

    path.quadraticBezierTo(
      size.width / 2,
      centerY,
      0,
      centerY - radius,
    );

    path.close();

    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    return true;
  }
}

class SideHalfCircleClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    double radius = 50.0; // Adjust the radius as needed
    double centerY = size.height / 2;
    // double centerX = size.width / 2;

    final path = Path();

    path.moveTo(0, 0);
    path.lineTo(size.width - radius, 0);

    // Draw the right side with a half-circle
    path.arcTo(
      Rect.fromCircle(
        center: Offset(size.width - radius, centerY),
        radius: radius,
      ),
      -pi / 2, // Start angle
      pi, // Sweep angle
      false, // Counter-clockwise
    );

    path.lineTo(0, size.height);
    path.close();

    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) {
    return true;
  }
}
