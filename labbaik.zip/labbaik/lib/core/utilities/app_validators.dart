import '../../generated/l10n.dart' show S;
import '../widgets/password_validation_stepper.dart';

class AppValidator {
  static String? validateEmail(String? value) {
    if (value == null || value.isEmpty) {
      return S.current.emailRequired;
    }
    if (!value.contains('@')) {
      return S.current.emailInvalid;
    }
    return null;
  }

  static String? validateDateOfBirth(String? value) {
    if (value == null || value.isEmpty) {
      return S.current.dateOfBirthRequired;
    }
    return null;
  }

  static String? validatePhoneNumber(String? value) {
    if (value == null || value.isEmpty) {
      return S.current.phoneNumberRequired;
    }
    if (value.length != 9) {
      return S.current.phoneNumberLength;
    }
    return null;
  }

  static String? validatePassword(String? value) {
    return PasswordValidationHelper.validatePasswordWithRules(value);
  }

  static String? validateConfirmPassword(String? value, password) {
    if (value == null || value.isEmpty) {
      return S.current.passwordRequired;
    }
    if (value.length < 8) {
      return S.current.passwordLength;
    }
    if (value != password) {
      return S.current.confirmPasswordNotMatch;
    }
    return null;
  }

  static String? validateName(String? value) {
    if (value == null || value.isEmpty) {
      return S.current.nameRequired;
    }

    return null;
  }

  static String? validateFName(String? value) {
    if (value == null || value.isEmpty) {
      return S.current.fNameRequired;
    }
    if (value.length < 3) {
      return S.current.fNameInvalid;
    }
    return null;
  }

  static String? validateLName(String? value) {
    if (value == null || value.isEmpty) {
      return S.current.lNameRequired;
    }
    if (value.length < 3) {
      return S.current.lNameInvalid;
    }
    return null;
  }

  static String? validateAddress(String? value) {
    if (value == null || value.isEmpty) {
      return S.current.addressRequired;
    }
    if (value.length < 3) {
      return S.current.addressInvalid;
    }
    return null;
  }

  // validate the empty field
  static String? validateEmpty(String? value) {
    if (value == null || value.isEmpty) {
      return S.current.fieldRequired;
    }
    return null;
  }
}
