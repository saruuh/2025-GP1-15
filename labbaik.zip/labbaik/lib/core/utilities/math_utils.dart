import "package:intl/intl.dart" show DateFormat;
import "../../generated/l10n.dart" show S;

class MathUtils {
  static int getRandomNumber(int min, int max) {
    return min +
        (max - min) * (DateTime.now().microsecondsSinceEpoch % 1000) ~/ 1000;
  }

  // return string from int index if it is 1 return 1st if it is 2 return 2nd if it is 3 return 3rd else return indexth
  static String getOrdinal(int index) {
    if (index == 1) {
      return "1st";
    } else if (index == 2) {
      return "2nd";
    } else if (index == 3) {
      return "3rd";
    } else {
      return "${index}th";
    }
  }

// Helper function for cleaner formatting
  static String formatDuration(
    int value,
    String singularLabel,
    String pluralLabel,
  ) {
    final translatedLabel = value == 1 ? singularLabel : pluralLabel;
    return "${S.current.ago} $value $translatedLabel ";
  }

  static String formatNumber(int number) {
    if (number >= 1000000) {
      final double result = number / 1000000;
      return "${result.toStringAsFixed(result.truncateToDouble() == result ? 0 : 1)} ${S.current.millionShort}";
    } else if (number >= 1000) {
      final double result = number / 1000;
      return "${result.toStringAsFixed(result.truncateToDouble() == result ? 0 : 1)} ${S.current.thousandShort}";
    } else {
      return number.toString();
    }
  }

  static String formatMonthYearRange(DateTime? startDate, DateTime? endDate) {
    final DateFormat monthYearFormat = DateFormat("MMM y");

    // if any of them is null return the other one formatted
    if (startDate == null || endDate == null) {
      return startDate != null
          ? monthYearFormat.format(startDate)
          : endDate != null
              ? monthYearFormat.format(endDate)
              : "";
    }

    // if both are the same return one of them
    if (startDate == endDate) {
      return monthYearFormat.format(startDate);
    }

    return "${monthYearFormat.format(startDate)} - ${monthYearFormat.format(endDate)}";
  }

  static String formatDurationDifference(
    DateTime? startDate,
    DateTime? endDate,
  ) {
    // if any of them is null return empty string
    if (startDate == null || endDate == null) {
      return "";
    } else if (startDate == endDate) {
      return "";
    }

    final Duration duration = endDate.difference(startDate);

    if (duration.inDays >= 365) {
      final int years = (duration.inDays / 365).floor();
      return "$years ${years == 1 ? S.current.year : S.current.years}";
    } else if (duration.inDays >= 30) {
      final int months = (duration.inDays / 30).floor();
      return "$months ${months == 1 ? S.current.month : S.current.months}";
    } else {
      return "${duration.inDays} ${duration.inDays == 1 ? S.current.day : S.current.days}";
    }
  }
}
