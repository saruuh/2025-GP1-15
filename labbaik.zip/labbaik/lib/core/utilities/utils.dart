import 'dart:developer';
import 'dart:io';

import 'package:device_info_plus/device_info_plus.dart';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:labbaik/core/utilities/custom_logger.dart' show CustomLogger;
import 'package:labbaik/core/utilities/extensions.dart';
import 'package:mime/mime.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_thumbnail/video_thumbnail.dart'
    show ImageFormat, VideoThumbnail;

import 'package:intl/intl.dart' show DateFormat;

class Utils {
  static bool isArabic(String text) {
    if (text.isEmpty) return false;
    // Check if the first character is Arabic
    final int firstChar = text.codeUnitAt(0);
    return (firstChar >= 0x0600 && firstChar <= 0x06FF) || // Arabic
        (firstChar >= 0x0750 && firstChar <= 0x077F) || // Arabic Supplement
        (firstChar >= 0x08A0 && firstChar <= 0x08FF) || // Arabic Extended-A
        (firstChar >= 0xFB50 &&
            firstChar <= 0xFDFF) || // Arabic Presentation Forms-A
        (firstChar >= 0xFE70 &&
            firstChar <= 0xFEFF); // Arabic Presentation Forms-B
  }

  static Future<String?> getMacAddress() async {
    String? macAddress;
    DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();
    // check if the device is android or ios
    if (Platform.isAndroid) {
      AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
      macAddress = androidInfo.id;
      CustomLogger.instance.info('MAC address: ${androidInfo.id}');
    } else if (Platform.isIOS) {
      IosDeviceInfo iosInfo = await deviceInfo.iosInfo;
      macAddress = iosInfo.identifierForVendor;
      CustomLogger.instance.info('MAC address: ${iosInfo.identifierForVendor}');
    }
    return macAddress;
  }

  static bool? checkFileType(File file) {
    bool? isImage;
    final mimeType = lookupMimeType(file.path);

    if (mimeType != null) {
      if (mimeType.startsWith('image/')) {
        CustomLogger.instance.info('This is an image file.');
        isImage = true;
      } else if (mimeType.startsWith('video/')) {
        CustomLogger.instance.info('This is a video file.');
        isImage = false;
      } else {
        CustomLogger.instance.info(
          'This is neither an image nor a video file.',
        );
      }
    } else {
      CustomLogger.instance.info('Could not determine the file type.');
    }
    return isImage;
  }

  // pick image or video from gallery or camera
  static Future<File?> pickImageOrVideo() async {
    final ImagePicker picker = ImagePicker();
    final XFile? media = await picker.pickMedia();
    if (media != null) {
      // convert image to file
      File file = File(media.path);
      return file;
    } else {
      return null;
    }
  }

  // open google maps with lat and long
  static Future<void> openGoogleMaps({
    required double lat,
    required double long,
  }) async {
    Uri googleUrl = Uri.parse(
      'https://www.google.com/maps/search/?api=1&query=$lat,$long',
    );
    // convert googleUrl to apple URI scheme

    // apple maps
    // Uri appleUrl = Uri.parse(
    //   'https://maps.apple.com/?sll=$lat,$long&z=10&t=s&dirflg=d&showlabs=1',
    // );
    if (Platform.isIOS) {
      // for iOS phone
      if (await canLaunchUrl(googleUrl)) {
        await launchUrl(googleUrl).onError((error, stackTrace) {
          log(error.toString());
          throw 'Could not open the map.';
        });
      } else {
        throw 'Could not open the map.';
      }
    } else {
      // for Android phone
      if (await canLaunchUrl(googleUrl)) {
        await launchUrl(googleUrl).onError((error, stackTrace) {
          log(error.toString());
          throw 'Could not open the map.';
        });
      } else {
        throw 'Could not open the map.';
      }
    }
  }

  static String decodeOrgType(int val) {
    String type;
    switch (val) {
      case 1:
        type = "Hospital";
        break;
      case 2:
        type = "Lab";
        break;
      case 3:
        type = "Pharmacy";
        break;
      case 4:
        type = "Ambulance";
        break;
      default: // default is hospital
        type = "hospital";
    }
    return type;
  }

  static int encodeOrgType(String val) {
    int type;
    switch (val) {
      case "Hospital":
        type = 1;
        break;
      case "Lab":
        type = 2;
        break;
      case "Pharmacy":
        type = 3;
        break;
      case "Ambulance":
        type = 4;
        break;
      default: // default is hospital
        type = 1;
    }
    return type;
  }

  static String encodeDummyOrgType(int val) {
    String type;
    switch (val) {
      case 1:
        type = "hospital";
        break;
      case 2:
        type = "doctor";
        break;
      case 3:
        type = "clinic";
        break;
      case 4:
        type = "lab";
        break;
      case 5:
        type = "pharmacy";
        break;
      default: // default is hospital
        type = "hospital";
    }
    return type;
  }

  static String decodeUserGender(int val) {
    String type;
    switch (val) {
      case 1:
        type = "Male";
        break;
      case 2:
        type = "Female";
        break;

      default:
        type = "Male";
    }
    return type;
  }

  static String decodeUserBloodType(int val) {
    String type;
    switch (val) {
      case 1:
        type = "A+";
        break;
      case 2:
        type = "A-";
        break;
      case 3:
        type = "B+";
        break;
      case 4:
        type = "B-";
        break;
      case 5:
        type = "AB+";
        break;
      case 6:
        type = "AB-";
        break;
      case 7:
        type = "O+";
        break;
      case 8:
        type = "O-";
        break;
      default:
        type = "O-";
    }
    return type;
  }

  static int encodeUserBloodType(String val) {
    int type;
    switch (val) {
      case "A+":
        type = 1;
        break;
      case "A-":
        type = 2;
        break;
      case "B+":
        type = 3;
        break;
      case "B-":
        type = 4;
        break;
      case "AB+":
        type = 5;
        break;
      case "AB-":
        type = 6;
        break;
      case "O+":
        type = 7;
        break;
      case "O-":
        type = 8;
        break;
      default:
        type = 8;
    }
    return type;
  }

  static Future<void> launchPhoneDialer({required String phoneNumber}) async {
    final Uri phoneUri = Uri(scheme: 'tel', path: phoneNumber);

    if (await canLaunchUrl(phoneUri)) {
      await launchUrl(phoneUri);
    } else {
      throw 'Could not launch $phoneNumber';
    }
  }

  //url
  static Future<void> openUrl(String url, {bool? whatsApp}) async {
    final Uri androidURI = whatsApp == true
        ? Uri.parse('whatsapp://send?phone=$url')
        : Uri.parse(url);

    final Uri iosURI = whatsApp == true
        ? Uri.parse('https://wa.me/$url')
        : Uri.parse(url);

    if (Platform.isIOS) {
      if (await canLaunchUrl(iosURI)) {
        await launchUrl(iosURI).onError((error, stackTrace) {
          log(error.toString());
          throw 'Could not open the url.';
        });
      } else {
        throw 'Could not open the url.';
      }
    } else {
      if (await canLaunchUrl(androidURI)) {
        await launchUrl(androidURI).onError((error, stackTrace) {
          log(error.toString());
          throw 'Could not open the url.';
        });
      } else {
        throw 'Could not open the url.';
      }
    }
  }

  static bool isImage(String filePath) {
    final mimeType = lookupMimeType(filePath);
    return mimeType != null && mimeType.startsWith('image/');
  }

  static Future<String> generateThumbnail({
    required String videoPath,
    required String attachmentId,
  }) async {
    try {
      final uint8list = await VideoThumbnail.thumbnailData(
        video: videoPath,
        imageFormat: ImageFormat.PNG,
        maxWidth: 128,
        quality: 50,
      );

      final directory = await getApplicationDocumentsDirectory();
      final thumbnailFile = File(
        '${directory.path}/$attachmentId/thumbnail.png',
      );

      // Ensure the directory exists
      await thumbnailFile.parent.create(recursive: true);

      await thumbnailFile.writeAsBytes(uint8list!);
      return thumbnailFile.path;
    } catch (e) {
      debugPrint('Error generating thumbnail: $e');
      rethrow;
    }
  }

  static String formatTime(BuildContext context, String date) {
    String formattedDate = DateFormat(
      'hh:mm a',
      context.isArabic ? 'ar' : 'en',
    ).format(DateTime.parse(date));
    return convertArabicNumeralsToEnglish(formattedDate);
  }

  static String formatDate(BuildContext context, String date) {
    String formattedDate = DateFormat(
      'dd MMMM yyyy',
      context.isArabic ? 'ar' : 'en',
    ).format(DateTime.parse(date));
    return convertArabicNumeralsToEnglish(formattedDate);
  }

  /// Converts Arabic numerals (٠١٢٣٤٥٦٧٨٩) to English numerals (0123456789)
  static String convertArabicNumeralsToEnglish(String input) {
    return input
        .replaceAll('٠', '0')
        .replaceAll('١', '1')
        .replaceAll('٢', '2')
        .replaceAll('٣', '3')
        .replaceAll('٤', '4')
        .replaceAll('٥', '5')
        .replaceAll('٦', '6')
        .replaceAll('٧', '7')
        .replaceAll('٨', '8')
        .replaceAll('٩', '9');
  }
}
