import 'dart:developer';

import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';

class LocationService {
  Future<Position?> getCurrentLocation() async {
    // Check if location permission is granted
    if (await _checkLocationPermission()) {
      try {
        // Get current location
        return await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high,
        );
      } catch (e) {
        log("Error getting location: $e");
        return null;
      }
    } else {
      // Location permission not granted, request permission
      await _requestLocationPermission();
      return null;
    }
  }

  Future<bool> _checkLocationPermission() async {
    var status = await Permission.location.status;
    return status == PermissionStatus.granted;
  }

  Future<void> _requestLocationPermission() async {
    var status = await Permission.location.request();
    if (status != PermissionStatus.granted) {
      // Handle the case when the user denies location permission
      log("Location permission denied");
    }
  }
}
