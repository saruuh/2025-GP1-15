const String iconsPath = 'assets/icons';
const String imagesPath = 'assets/images';
const String svgPath = 'assets/svgs';
const String lottiePath = 'assets/lottie';

class PathUtil {
  ///* ******************************** icons ********************************
  ///assets/icons/star.png
  static const star = '$iconsPath/star.png';
  // assets/icons/darkMode.png
  static const darkMode = '$iconsPath/darkMode.png';
  // assets/icons/changePassword.png
  static const changePassword = '$iconsPath/changePassword.png';
  // assets/icons/appLanguage.png
  static const appLanguage = '$iconsPath/appLanguage.png';
  // assets/icons/location.png
  static const location = '$iconsPath/location.png';
  // assets/icons/technicalSupport.png
  static const technicalSupport = '$iconsPath/technicalSupport.png';
  // assets/icons/shareApp.png
  static const shareApp = '$iconsPath/shareApp.png';
  // assets/icons/personIcon.png
  static const personIcon = '$iconsPath/personIcon.png';
  // assets/icons/emailIcon.png
  static const emailIcon = '$iconsPath/emailIcon.png';
  // assets/icons/phoneIcon.png
  static const phoneIcon = '$iconsPath/phoneIcon.png';
  // assets/icons/manageCompanions.png
  static const manageCompanions = '$iconsPath/manageCompanions.png';
  // assets/icons/calender.png
  static const calendar = '$iconsPath/calender.png';
  // assets/icons/rateUs.png
  static const rateUs = '$iconsPath/rateUs.png';
  // assets/icons/step1.png
  static const step1 = '$iconsPath/step1.png';
  // assets/icons/step2.png
  static const step2 = '$iconsPath/step2.png';
  // assets/icons/step3.png
  static const step3 = '$iconsPath/step3.png';
  // assets/icons/step4.png
  static const step4 = '$iconsPath/step4.png';

  ///* ******************************** images ********************************
  //assets/images/authBg.png
  static const authBg = '$imagesPath/authBg.png';
  // assets/images/splash.png
  static const splash = '$imagesPath/splash.png';
  // homeBg
  static const homeBg = '$imagesPath/homeBg.png';
  // 1.png
  static const ihramGarment1 = '$imagesPath/1.png';
  // 2.png
  static const ihramGarment2 = '$imagesPath/2.png';
  // 3.png
  static const ihramGarment3 = '$imagesPath/3.png';
  // 4.png
  static const ihramGarment4 = '$imagesPath/4.png';
  // assets/images/step1.png
  static const step1Image = '$imagesPath/step1.png';
  // assets/images/step2.png
  static const step2Image = '$imagesPath/step2.png';
  // assets/images/step3.png
  static const step3Image = '$imagesPath/step3.png';
  // assets/images/step4.png
  static const step4Image = '$imagesPath/step4.png';
  //assets/images/hajj.png
  static const hajj = '$imagesPath/hajj.png';
  //assets/images/umrah.png
  static const umrah = '$imagesPath/umrah.png';
  //assets/images/day_of_tarwiyah.png
  static const dayOfTarwiyah = '$imagesPath/day_of_tarwiyah.png';
  //assets/images/Dhul-Hijjah.png
  static const dhulHijjah = '$imagesPath/Dhul-Hijjah.png';
  //assets/images/10-Dhul-Hijjah.png
  static const dhulHijjah10 = '$imagesPath/10-Dhul-Hijjah.png';
  //assets/images/11-13-Dhul-Hijjah.png
  static const dhulHijjah11To13 = '$imagesPath/11-13-Dhul-Hijjah.png';
  //assets/images/mina.png
  static const mina = '$imagesPath/mina.png';
  //assets/images/Muzdalifah.png
  static const muzdalifah = '$imagesPath/Muzdalifah.png';
  //assets/images/sub-mina-1.png
  static const subMina1 = '$imagesPath/sub-mina-1.png';

  ///* ******************************** svg ********************************
  //assets/svgs/logo_light.svg
  static const logoLight = '$svgPath/logo_light.svg';
  //assets/svgs/logo_dark.svg
  static const logoDark = '$svgPath/logo_dark.svg';
  // assets/svgs/saudi_riyal.svg
  static const saudiRiyalSVG = '$svgPath/saudi_riyal.svg';
  // assets/svgs/chatBot.svg
  static const chatBot = '$svgPath/chatBot.svg';
  // assets/svgs/home.svg
  static const home = '$svgPath/home.svg';
  // assets/svgs/lapscounter.svg
  static const lapscounter = '$svgPath/lapscounter.svg';
  // assets/svgs/map.svg
  static const map = '$svgPath/map.svg';
  // assets/svgs/steppes.svg
  static const steppes = '$svgPath/steppes.svg';
  // assets/svgs/booklet.svg
  static const booklet = '$svgPath/booklet.svg';
  // assets/svgs/homeBtn.svg
  static const homeBtn = '$svgPath/homeBtn.svg';

  ///* ******************************** lottie ********************************
  static const notFoundBlackLottie = '$lottiePath/not-found-black.json';
  static const notFoundWhiteLottie = '$lottiePath/not-found-white.json';
}
