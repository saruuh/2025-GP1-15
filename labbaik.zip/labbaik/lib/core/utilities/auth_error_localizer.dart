import 'package:labbaik/generated/l10n.dart';

/// Utility class to localize authentication error messages
class AuthErrorLocalizer {
  /// Get localized error message from error key
  static String getLocalizedError(String? errorKey, S localization) {
    if (errorKey == null || errorKey.isEmpty) {
      return localization.errorOccurred;
    }

    // Map error keys to localization getters
    switch (errorKey) {
      case 'weakPassword':
        return localization.weakPassword;
      case 'emailAlreadyInUse':
        return localization.emailAlreadyInUse;
      case 'invalidEmail':
        return localization.invalidEmail;
      case 'userDisabled':
        return localization.userDisabled;
      case 'userNotFound':
        return localization.userNotFound;
      case 'wrongPassword':
        return localization.wrongPassword;
      case 'tooManyRequests':
        return localization.tooManyRequests;
      case 'operationNotAllowed':
        return localization.operationNotAllowed;
      case 'unexpectedErrorOccurred':
        return localization.unexpectedErrorOccurred;
      case 'failedToSendVerificationEmail':
        return localization.failedToSendVerificationEmail;
      case 'failedToSignOut':
        return localization.failedToSignOut;
      case 'failedToResendEmail':
        return localization.failedToResendEmail;
      case 'signInFailed':
        return localization.signInFailed;
      case 'signUpFailed':
        return localization.signUpFailed;
      case 'errorOccurred':
      default:
        return localization.errorOccurred;
    }
  }
}

