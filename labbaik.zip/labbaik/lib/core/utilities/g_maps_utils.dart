import 'package:dio/dio.dart';

import '../resources/app_constant.dart';

class GMapsUtils {
  static final Dio dio = Dio();
  static String getStaticMapUrl(
    double lat,
    double lng, {
    int zoom = 15,
    int width = 600,
    int height = 400,
  }) {
    return "https://maps.googleapis.com/maps/api/staticmap?center=$lat,$lng&zoom=$zoom&size=${width}x$height&key=${AppConstant.gMapsAPIKey}";
  }

  static String generateLocationUrl(double latitude, double longitude) {
    return 'https://www.google.com/maps/search/?api=1&query=$latitude,$longitude';
  }

  static String generateStaticMapImageUrl(double latitude, double longitude) {
    String baseUrl = 'https://staticmap.openstreetmap.de/staticmap.php?';
    String marker = 'center=$latitude,$longitude&zoom=12&size=400x300';

    return baseUrl + marker;
  }

  static String yandexStaticMapImage({double? altitude, longitude}) {
    // String imagePreview =
    //     'https://maps.googleapis.com/maps/api/staticmap?center=30.22,-92.02&zoom=12&size=400x400&markers=color:red%7Clabel:A%7C30.19,-91.98&markers=color:red%7Clabel:B%7C30.17,-92.03&markers=color:red%7Clabel:C%7C30.21,-92.03&key=$apiKey';
    // return imagePreview;
    return 'https://static-maps.yandex.ru/1.x/?size=500,350&l=map&ll=$longitude,$altitude&z=15&pt=$longitude,$altitude,round';
  }

  static Future<void> osmStaticMapImage(
    double latitude,
    double longitude,
  ) async {
    String baseUrl = 'https://staticmap.openstreetmap.de/staticmap.php?';
    String marker = 'center=$latitude,$longitude&zoom=12&size=400x300';

    String staticMapImageUrl = baseUrl + marker;

    // Replace 'your-app-domain.com' with the actual domain of your application
    String referrer = 'https://your-app-domain.com';

    Map<String, String> headers = {'Referer': referrer};

    // Make an HTTP GET request with the specified headers
    final response = await dio.get(
      staticMapImageUrl,
      options: Options(headers: headers),
    );

    if (response.statusCode == 200) {
      // Handle the response, e.g., save the image to a file or display it
      print('Static Map Image successfully retrieved.');
    } else {
      // Handle errors, e.g., print an error message
      print(
        'Failed to retrieve Static Map Image. Status Code: ${response.statusCode}',
      );
    }
  }
}
