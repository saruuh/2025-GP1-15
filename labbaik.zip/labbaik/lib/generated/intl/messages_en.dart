// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a en locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'en';

  static String m0(completedSteps, totalSteps, stepsCount) =>
      "${completedSteps}/${totalSteps} ${Intl.plural(stepsCount, one: 'step', other: 'steps')}";

  static String m1(stepName) => "Did you complete the ${stepName} step?";

  static String m10(value, unit) =>
      "${Intl.plural(value, zero: 'Just now', one: '1 ${unit} ago', other: '${value} ${unit}s ago')}";

  static String m2(value) =>
      "${Intl.plural(value, zero: 'now', one: '1 day ago', other: '${value} days ago')}";

  static String m3(value) =>
      "${Intl.plural(value, zero: 'now', one: '1 hour ago', other: '${value} hours ago')}";

  static String m4(value) =>
      "${Intl.plural(value, zero: 'now', one: '1 minute ago', other: '${value} minutes ago')}";

  static String m5(value) =>
      "${Intl.plural(value, zero: 'now', one: '1 month ago', other: '${value} months ago')}";

  static String m6(value) =>
      "${Intl.plural(value, zero: 'now', one: '1 second ago', other: '${value} seconds ago')}";

  static String m7(value, unitShort) => "${value}${unitShort}";

  static String m8(value) =>
      "${Intl.plural(value, zero: 'now', one: '1 year ago', other: '${value} years ago')}";

  static String m9(email) => "We\'ve sent a verification link to ${email}";

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
    "account": MessageLookupByLibrary.simpleMessage("Account"),
    "active": MessageLookupByLibrary.simpleMessage("Active"),
    "addressInvalid": MessageLookupByLibrary.simpleMessage("Address invalid"),
    "addressLength": MessageLookupByLibrary.simpleMessage(
      "Address must be longer than 3 characters",
    ),
    "addressRequired": MessageLookupByLibrary.simpleMessage("Address required"),
    "ago": MessageLookupByLibrary.simpleMessage("ago"),
    "alMuqayti": MessageLookupByLibrary.simpleMessage("Al Muqayti"),
    "alUsaylah": MessageLookupByLibrary.simpleMessage("AL\'USAYLAH"),
    "album": MessageLookupByLibrary.simpleMessage("Album"),
    "all": MessageLookupByLibrary.simpleMessage("All"),
    "alreadyHaveAnAccount": MessageLookupByLibrary.simpleMessage(
      "Already have an account?",
    ),
    "app": MessageLookupByLibrary.simpleMessage("App"),
    "appLanguage": MessageLookupByLibrary.simpleMessage("App language"),
    "arabic": MessageLookupByLibrary.simpleMessage("Arabic"),
    "askMeAnythingAboutUmrah": MessageLookupByLibrary.simpleMessage(
      "Ask me anything about Umrah",
    ),
    "asr": MessageLookupByLibrary.simpleMessage("Asr"),
    "backToLogin": MessageLookupByLibrary.simpleMessage("Back to Login"),
    "backToLoginQuestion": MessageLookupByLibrary.simpleMessage(
      "Don\'t have an account?",
    ),
    "badRequestException": MessageLookupByLibrary.simpleMessage(
      "Bad request error",
    ),
    "bathaQuraish": MessageLookupByLibrary.simpleMessage("Batha Quraish"),
    "beginning": MessageLookupByLibrary.simpleMessage("Beginning"),
    "cacheException": MessageLookupByLibrary.simpleMessage("Cache error"),
    "calendar": MessageLookupByLibrary.simpleMessage("Calendar"),
    "cancel": MessageLookupByLibrary.simpleMessage("Cancel"),
    "cancelException": MessageLookupByLibrary.simpleMessage(
      "Operation cancelled",
    ),
    "changePassword": MessageLookupByLibrary.simpleMessage("Change password"),
    "clickTheLinkInYourEmail": MessageLookupByLibrary.simpleMessage(
      "Click the verification link in your email to verify your account",
    ),
    "complete": MessageLookupByLibrary.simpleMessage("Complete"),
    "completed": MessageLookupByLibrary.simpleMessage("Completed"),
    "confirmNewPassword": MessageLookupByLibrary.simpleMessage(
      "Confirm New Password",
    ),
    "confirmPassword": MessageLookupByLibrary.simpleMessage("Confirm password"),
    "confirmPasswordNotMatch": MessageLookupByLibrary.simpleMessage(
      "Confirm password does not match",
    ),
    "currentPassword": MessageLookupByLibrary.simpleMessage("Current Password"),
    "darkMode": MessageLookupByLibrary.simpleMessage("Dark mode"),
    "dataNotCompleted": MessageLookupByLibrary.simpleMessage(
      "Data not completed",
    ),
    "dateOfBirth": MessageLookupByLibrary.simpleMessage("Date of birth"),
    "dateOfBirthRequired": MessageLookupByLibrary.simpleMessage(
      "Date of birth required",
    ),
    "day": MessageLookupByLibrary.simpleMessage("day"),
    "day1": MessageLookupByLibrary.simpleMessage("Day 1"),
    "day2": MessageLookupByLibrary.simpleMessage("Day 2"),
    "day3To5": MessageLookupByLibrary.simpleMessage("Day 3 To 5"),
    "dayOfArafah": MessageLookupByLibrary.simpleMessage("Day of Arafah"),
    "dayOfNahr": MessageLookupByLibrary.simpleMessage("Day of Nahr"),
    "dayOfTarwiyah": MessageLookupByLibrary.simpleMessage("Day of Tarwiyah"),
    "dayShort": MessageLookupByLibrary.simpleMessage("d"),
    "days": MessageLookupByLibrary.simpleMessage("days"),
    "daysOfTashreeq": MessageLookupByLibrary.simpleMessage("Days of Tashreeq"),
    "daysShort": MessageLookupByLibrary.simpleMessage("d"),
    "deleteComment": MessageLookupByLibrary.simpleMessage("Delete Comment"),
    "deleteCommentMsg": MessageLookupByLibrary.simpleMessage(
      "Are you sure you want to delete this comment?",
    ),
    "description": MessageLookupByLibrary.simpleMessage("Description"),
    "dhuhr": MessageLookupByLibrary.simpleMessage("Dhuhr"),
    "doNotShowAgain": MessageLookupByLibrary.simpleMessage(
      "Do not show this message again",
    ),
    "donTworryItHappensPleaseEnterTheEmailAssociatedWithYourAccount":
        MessageLookupByLibrary.simpleMessage(
          "Don\'t worry! It happens. Please enter the email associated with your account.",
        ),
    "downloadedSuccessfully": MessageLookupByLibrary.simpleMessage(
      "Downloaded successfully",
    ),
    "eighthDhulHijjah": MessageLookupByLibrary.simpleMessage(
      "Eighth Dhul Hijjah",
    ),
    "elevensToThirteenthDhulHijjah": MessageLookupByLibrary.simpleMessage(
      "from 11 to 13 Dhul-Hijjah",
    ),
    "email": MessageLookupByLibrary.simpleMessage("Email"),
    "emailAlreadyInUse": MessageLookupByLibrary.simpleMessage(
      "An account already exists for that email.",
    ),
    "emailInvalid": MessageLookupByLibrary.simpleMessage("Email invalid"),
    "emailRequired": MessageLookupByLibrary.simpleMessage("Email required"),
    "english": MessageLookupByLibrary.simpleMessage("English"),
    "enterCode": MessageLookupByLibrary.simpleMessage("Enter the code"),
    "enterYourEmail": MessageLookupByLibrary.simpleMessage(
      "Enter your email address and we\'ll send you a link to reset your password",
    ),
    "enteringIhramAtMiqat": MessageLookupByLibrary.simpleMessage(
      "Entering Ihram at Miqat",
    ),
    "enteringIhramAtMiqatDescription": MessageLookupByLibrary.simpleMessage(
      "Upon arriving at the miqat, the pilgrim makes the intention in the heart to perform ʿUmrah. This intention must be made at or before crossing the miqat. After forming the intention internally, the pilgrim verbally declares: \"Labbayka Umrah\", and then begins reciting the Talbiyah.\n<gold>The Prophet ﷺ used to:</gold>\nPerform ghusl (bath) and clean yourself.\n\t•\tRecommended for both men and women.\n\t•\tIf not possible at the miqāt, it\'s permissible to delay; bathing on arrival\n•Apply perfume to the body before putting on the ihram garments. <red>After entering ihram, applying perfume is forbidden.</red>\n\nMaking a Condition in Ihram\nIf a pilgrim **fears that they may not be able to complete their ʿUmrah** due to illness or any legitimate obstacle, it is permissible to **make a condition** when entering ihram. After declaring: \"Labbayka ʿUmrah,\" the pilgrim says: \"If I am prevented by anything, then my place of release is where I am held up.\" If something occurs that prevents the pilgrim from completing the ʿUmrah, they may exit the state of ihram and stop the pilgrimage without any sin or penalty.",
    ),
    "enteringIhramFromAirplane": MessageLookupByLibrary.simpleMessage(
      "Entering Ihram from an Airplane",
    ),
    "enteringIhramFromAirplaneDescription": MessageLookupByLibrary.simpleMessage(
      "A pilgrim traveling by plane may enter the state of **ihram while still on the aircraft**, before reaching the city of Jeddah, when the plane reaches the vicinity of the miqat. Anyone intending to perform Umrah should be **ready with the ihram garments** and **avoid the prohibitions of ihram** before the announcement, allowing sufficient time to enter the state properly.",
    ),
    "error": MessageLookupByLibrary.simpleMessage("Error"),
    "errorOccurred": MessageLookupByLibrary.simpleMessage(
      "An error occurred. Please try again.",
    ),
    "fName": MessageLookupByLibrary.simpleMessage("First name"),
    "fNameInvalid": MessageLookupByLibrary.simpleMessage("First name invalid"),
    "fNameRequired": MessageLookupByLibrary.simpleMessage(
      "First name required",
    ),
    "failedToResendEmail": MessageLookupByLibrary.simpleMessage(
      "Failed to resend email",
    ),
    "failedToResetProgress": MessageLookupByLibrary.simpleMessage(
      "Failed to reset progress. Please try again.",
    ),
    "failedToSaveProgress": MessageLookupByLibrary.simpleMessage(
      "Failed to save progress. Please try again.",
    ),
    "failedToSendVerificationEmail": MessageLookupByLibrary.simpleMessage(
      "Failed to send verification email. Please try again.",
    ),
    "failedToSignOut": MessageLookupByLibrary.simpleMessage(
      "Failed to sign out. Please try again.",
    ),
    "fajr": MessageLookupByLibrary.simpleMessage("Fajr"),
    "fatwaChatbot": MessageLookupByLibrary.simpleMessage("Fatwa Chatbot"),
    "fieldInvalid": MessageLookupByLibrary.simpleMessage("Field invalid"),
    "fieldRequired": MessageLookupByLibrary.simpleMessage("Field required"),
    "findYourLocationAndNavigate": MessageLookupByLibrary.simpleMessage(
      "Find your location and navigate to important places",
    ),
    "forbiddenException": MessageLookupByLibrary.simpleMessage(
      "Forbidden exception",
    ),
    "forgotPassword": MessageLookupByLibrary.simpleMessage("Forgot password?"),
    "formatException": MessageLookupByLibrary.simpleMessage("Format error"),
    "general": MessageLookupByLibrary.simpleMessage("General"),
    "getStartedNow": MessageLookupByLibrary.simpleMessage("Get started now"),
    "hajj": MessageLookupByLibrary.simpleMessage("Hajj"),
    "hajjAlIfradDescription": MessageLookupByLibrary.simpleMessage(
      "You enter ihram with the intention of Hajj only, saying: “Labbaik Allahumma Hajjan” (O Allah, I respond to You for Hajj). You are **not required** to offer a sacrificial animal (hady) in this type of Hajj.\nHowever, if you wish to offer a **voluntary Hady**, you may do so —**<green>just make sure to arrange it in advance through a Hady coupon or an official authorized service.</green>**",
    ),
    "hajjAlIfradTitle": MessageLookupByLibrary.simpleMessage("Hajj al-Ifrad"),
    "hajjAlQiranDescription": MessageLookupByLibrary.simpleMessage(
      "For those performing both Hajj and Umrah in one ihram. You make the intention for both together, saying: “Labbaik Allahumma Hajjan wa ‘Umrah” (O Allah, I respond to You for Hajj and Umrah). You remain in ihram until both are completed, and you perform the same actions as in Hajj al-Ifrad, but **you are required** to offer a sacrificial animal — **<green>so don’t forget to arrange it in advance through a Hady coupon or an authorized service.</green>**",
    ),
    "hajjAlQiranTitle": MessageLookupByLibrary.simpleMessage("Hajj al-Qiran"),
    "hajjAlTamattuDescription": MessageLookupByLibrary.simpleMessage(
      "You enter ihram for Umrah only, saying: “Labbaik Allahumma ‘Umrah” (O Allah, I respond to You for Umrah). You then perform your Umrah completely — by doing tawaf, sa’ee, trimming or shaving your hair, and exiting ihram. When the time for Hajj comes (on the 8th of Dhul Hijjah), you enter ihram again from Makkah for Hajj. This type is considered the best form of Hajj and **requires** a sacrificial animal (hady) — **<green>so don’t forget to arrange it in advance through a Hady coupon or an authorized service.</green>**\n\nThe time for entering Ihram for Hajj al-Tamattu is limited to the months of Hajj: Shawwal, Dhul Qadah, and the first ten days of Dhul Hijjah.",
    ),
    "hajjAlTamattuTitle": MessageLookupByLibrary.simpleMessage(
      "Hajj al-Tamattu",
    ),
    "hajjDay10Description": MessageLookupByLibrary.simpleMessage(
      "On the **Day of Nahr**, you will go to Mina to stone Jamrat al-Aqabah, offer your Hady, perform Tawaf al-Ifadah, and exit Ihram (Tahallul). After this, you return to Mina to spend the Nights of Tashreeq. **This sequence is the preferred Sunnah order, though the steps may be done in a different order if needed**, as The Prophet ﷺ said: \'No one was asked on that day about what they did first or last except that he said: Do it, and there is no harm.\'",
    ),
    "hajjDay11_13Description": MessageLookupByLibrary.simpleMessage(
      "On the **Days of Tashreeq**, you will stone the three Jamarat after midday. At the end of Hajj, you will perform Tawaf al-Wada\' before departing.",
    ),
    "hajjDay8Description": MessageLookupByLibrary.simpleMessage(
      "On the **Day of Tarwiyah**, you will enter ihram, perform Tawaf al-Qudum, then head to Mina to spend the night there both **Sunnah practices of The Prophet ﷺ**.",
    ),
    "hajjDay9Description": MessageLookupByLibrary.simpleMessage(
      "On the **Day of Arafah** you will go from Mina to Arafah after sunrise, make duaa, and pray Dhuhr and Asr shortened and combined. You will stay there until sunset. After sunset, you will head to Muzdalifah, pray Maghrib and \'Isha together, rest, and collect your pebbles for Rami.",
    ),
    "hajjStepAlHady": MessageLookupByLibrary.simpleMessage("Al-Hady"),
    "hajjStepAlHadyDescription": MessageLookupByLibrary.simpleMessage(
      "The sacrificial offering (Hady) is **required for pilgrims performing Hajj Tamattu\' or Hajj Qiran.** Those performing Hajj al-Ifrad are **not obligated** to offer the hady but are highly recommended to do so. The sacrifice for those who are required to do it must be performed **between the 10th, and 13th** of Dhul Hijjah, after stoning the pillars. If done on the 13th, it must be completed before sunset.",
    ),
    "hajjStepAlHadySubStep1": MessageLookupByLibrary.simpleMessage(
      "After you complete **Rami al-Aqabah**, your Hady will be slaughtered on your behalf through the service you arranged. If you used a coupon or an official program, the sacrifice is carried out automatically, and you may receive a confirmation message. **<red>You do not need to be present at the slaughter site,</red>** as the entire process is handled for you.",
    ),
    "hajjStepAlHadySubStep2": MessageLookupByLibrary.simpleMessage(
      "Once your sacrifice is completed, the meat is distributed to the poor and needy. **The official Hady program manages this distribution** so that it reaches those who need it most. **<red>You are not required to collect or handle any of the meat yourself.</red>**",
    ),
    "hajjStepArafat": MessageLookupByLibrary.simpleMessage("Arafat"),
    "hajjStepArafatDescription": MessageLookupByLibrary.simpleMessage(
      "The Day of \'Arafah is **one of the most important days** for Muslims around the world. Allah (SWT) refers to this day in Surah Al-Ma\'idah as the day on which He perfected His religion, completed His favors upon the Prophet Muhammad ﷺ , and approved Islam as a way of life.\n\n**The Prophet ﷺ said:** \"There is no day on which Allah frees more people from the Fire than the Day of \'Arafah. He draws close to them, then He says to the angels: \'What are these people seeking?\'\" (Hadith, Muslim).",
    ),
    "hajjStepArafatSubStep1": MessageLookupByLibrary.simpleMessage(
      "You should head to Arafah, pray **Dhuhr and Asr together**, performing Asr early along with Dhuhr (Jam\' Taqdim).",
    ),
    "hajjStepArafatSubStep2": MessageLookupByLibrary.simpleMessage(
      "On this day, the official Khutbah of \'Arafah will be delivered **from Masjid al-Nimrah**. Try to listen to the sermon if possible. Your group may also facilitate an English translation.",
    ),
    "hajjStepArafatSubStep3": MessageLookupByLibrary.simpleMessage(
      "You should remain in **Arafah until sunset**.",
    ),
    "hajjStepArafatSubStep4": MessageLookupByLibrary.simpleMessage(
      "**Dedicate this entire day to worship and supplication.** Stand on the plains of \'Arafah, focus your heart on Allah, and make plenty of duaa. **Ask for forgiveness, mercy, and blessings for yourself, your family, and all Muslims.**",
    ),
    "hajjStepArafatSubStep5": MessageLookupByLibrary.simpleMessage(
      "Try to recite comprehensive prophetic supplications, as **The Prophet ﷺ said:**\n\"The best supplication is the supplication on the Day of Arafah, and the best of what I and the prophets before me have said is: **La ilaha illallahu wahdahu la sharika lahu, lahul-mulku wa lahul-hamdu, yuhyi wa yumitu, wa huwa \'ala kulli shay\'in qadir.**",
    ),
    "hajjStepIhram": MessageLookupByLibrary.simpleMessage("Ihram"),
    "hajjStepIhramDescription": MessageLookupByLibrary.simpleMessage(
      "It is Sunnah to enter the state of ihram on the Day of Tarwiyah from the place specified by Islamic law. However, it may also be done **earlier or postponed until reaching Arafah** – both are permissible according to one\'s situation. When entering Ihram, a Muslim must avoid all the prohibitions that apply during this sacred state.",
    ),
    "hajjStepJamarat": MessageLookupByLibrary.simpleMessage("Jamarat"),
    "hajjStepJamaratDescription": MessageLookupByLibrary.simpleMessage(
      "Stoning the Jamarat is performed on the days of Tashreeq (11th, 12th, and 13th). It involves throwing seven pebbles at each of the three pillars (Jamarat) starting from the Small, then Middle, then Large (Aqabah).",
    ),
    "hajjStepJamaratSubStep1": MessageLookupByLibrary.simpleMessage(
      "Collect 21 small pebbles, about the size of date stones. It\'s recommended to carry a few extra in case one falls or misses the target — it\'s better to have more than to run short.\n**If you already collected yours in Muzdalifah, you will not need to collect any more here.**",
    ),
    "hajjStepJamaratSubStep2": MessageLookupByLibrary.simpleMessage(
      "**After the sun passes the zenith** (after Zawal), head toward the Jamarat.\nContinue making thikr and reciting the Talbiyah until you begin stoning.\n\nIt is permissible to perform the stoning before zawal on this day in cases of severe crowding. You may follow this opinion **if there is extreme congestion** at the Jamarat.",
    ),
    "hajjStepJamaratSubStep3": MessageLookupByLibrary.simpleMessage(
      "First start with the smallest Jamarah (closest to Masjid al-Khif).\nThrow 7 small pebbles, one at a time, saying \"Allahu Akbar\" with each throw and ensuring each pebble lands in the stoning area.\n\n<gold>After stoning, move slightly forward, face the Qiblah, keep the Jamarah on your left, and make a long du\'aa.</gold>",
    ),
    "hajjStepJamaratSubStep4": MessageLookupByLibrary.simpleMessage(
      "Then Proceed to the second Jamarah (the middle pillar).\nThrow 7 pebbles, one at a time, saying \"Allahu Akbar\" with each throw.\n\n<gold>After stoning, move aside, face the Qiblah, keep the Jamarah on your right, and make a long du\'aa.</gold>",
    ),
    "hajjStepJamaratSubStep5": MessageLookupByLibrary.simpleMessage(
      "Then move to the third Jamarah (Jamarat al-\'Aqabah).\nThrow 7 pebbles, one at a time, saying \"Allahu Akbar\" with each throw.\n\n**There is no du\'ā after the third Jamarah, continue moving forward with the crowd.**",
    ),
    "hajjStepJamaratSubStep6": MessageLookupByLibrary.simpleMessage(
      "Repeat this same process on each day (the 11th and the 12th, and also the 13th if you stay for the extra day).\n\n<red>Do not rush to perform Rami. The Hajj authorities often assign specific time slots for groups to reduce overcrowding and maintain safety. Follow your group\'s schedule.</red>\n\n<red>Do not throw sandals or valuables out of anger — the pillar does not contain Shaytan, and harming your belongings has no benefit.</red>\n\n**If you wish to leave Mina early (on the 12th of Dhul Hijjah), you must depart before sunset.** If sunset occurs and you are still in Mina, then **you must stay overnight and perform the stoning the next day.**",
    ),
    "hajjStepMina": MessageLookupByLibrary.simpleMessage("Mina"),
    "hajjStepMinaDescription": MessageLookupByLibrary.simpleMessage(
      "You should head to Mina at dawn on the 8th day of Dhul-Hijjah and **stay there in your allocated tent until the dawn of the 9th day.** The Prophet ﷺ **used to:** Spend the night in Mina on the Day of Tarwiyah, it is a Sunnah, not an obligation. If you choose to go directly to Arafah on the 9th day, you are allowed to do so.\n\nHere you will pray: Dhuhr, Asr, Maghrib, \'Isha, and Fajr, **shortening your four-unit prayers to two units each (qasr), <red>without combining them (jam\')</red>**, following how the Prophet ﷺ performed these prayers on the 8th of Dhul-Hijjah in Mina.",
    ),
    "hajjStepMinaJamratAlAqabahDescription": MessageLookupByLibrary.simpleMessage(
      "Depart Muzdalifah and go back towards Mina. Remember to continuously recite the Talbiyah.",
    ),
    "hajjStepMinaJamratAlAqabahSubStep1": MessageLookupByLibrary.simpleMessage(
      "When you arrive to Mina, collect 7 small pebbles, about the size of date stones. It\'s recommended to carry a few extra in case one falls or misses the target — it\'s better to have more than to run short. **If you already collected yours in Muzdalifah, you will not need to collect any more here.**",
    ),
    "hajjStepMinaJamratAlAqabahSubStep2": MessageLookupByLibrary.simpleMessage(
      "Walk toward Jamarat al-Aqabah, the largest pillar. Today, you will only stone this one pillar.",
    ),
    "hajjStepMinaJamratAlAqabahSubStep3": MessageLookupByLibrary.simpleMessage(
      "Throw seven pebbles, one at a time, saying \"Allahu Akbar\" with each throw and making sure each pebble lands inside the stoning area.\n\n**Do not rush to perform Rami.** The Hajj authorities often assign specific time slots for groups to reduce overcrowding and maintain safety. Follow your group\'s schedule.\n\n**<red>Do not throw sandals or valuables out of anger</red>** – the pillar does not contain Shaytan, and harming your belongings has no benefit.",
    ),
    "hajjStepMuzdalifah": MessageLookupByLibrary.simpleMessage("Muzdalifah"),
    "hajjStepMuzdalifahDescription": MessageLookupByLibrary.simpleMessage(
      "After sunset, leave Arafah and head to Muzdalifah. Upon arrival, pray Maghrib and Isha combined (delayed). Pray Maghrib as three Rak\'ahs as usual, then Isha as two Rak\'ahs. Abdullah bin Umar (may Allah be pleased with them) said: \'The Prophet ﷺ combined Maghrib and Isha in Muzdalifah, with one Iqamah for each, and did not pray anything between them or after them.\'",
    ),
    "hajjStepMuzdalifahSubStep1": MessageLookupByLibrary.simpleMessage(
      "You can collect pebbles for Jamarat (stoning in the following days of Hajj). It is recommended that the pebbles be small, about the size of a date stone. You will need:\n• 49 pebbles if you stay in Mina for only two days.\n• 70 pebbles if you stay in Mina for three days.\nIt is recommended to collect some extra pebbles in case you miss the target. You can also collect pebbles later from Mina if you wish.",
    ),
    "hajjStepMuzdalifahSubStep2": MessageLookupByLibrary.simpleMessage(
      "You can collect pebbles for Jamarat (stoning in the following days of Hajj). It is recommended that the pebbles be small, about the size of a date stone. You will need:\n• 49 pebbles if you stay in Mina for only two days.\n• 70 pebbles if you stay in Mina for three days.\nIt is recommended to collect some extra pebbles in case you miss the target. You can also collect pebbles later from Mina if you wish.",
    ),
    "hajjStepMuzdalifahSubStep3": MessageLookupByLibrary.simpleMessage(
      "Stay overnight in Muzdalifah. You can rest or engage in dhikr and worship quietly. The Prophet ﷺ slept in Muzdalifah until shortly before Fajr. So ensure you get good rest in preparation for the important day ahead.\n\nIt is permissible for pilgrims to leave Muzdalifah after midnight, as the Prophet ﷺ permitted women and the weak. For men not accompanying families, it is better to stay until Fajr prayer.",
    ),
    "hajjStepStayingInMina": MessageLookupByLibrary.simpleMessage(
      "Staying in Mina",
    ),
    "hajjStepStayingInMinaDescription": MessageLookupByLibrary.simpleMessage(
      "After completing Tawaf al-Ifadah, you should return to Mina to spend the nights of Tashreeq and stone the three Jamarat.",
    ),
    "hajjStepStayingInMinaSubStep1": MessageLookupByLibrary.simpleMessage(
      "The overnight stay in Mina during these days starts from the evening of the 10th (the night of the 11th) until the evening of the 12th (the night of the 13th) of Dhul-Hijjah.",
    ),
    "hajjStepStayingInMinaSubStep2": MessageLookupByLibrary.simpleMessage(
      "During the Days of Tashreeq, it is Sunnah to frequently recite Takbeer, especially after the obligatory prayers.",
    ),
    "hajjStepTahallul": MessageLookupByLibrary.simpleMessage(
      "Tahallul Awwal & Thani",
    ),
    "hajjStepTahallulDescription": MessageLookupByLibrary.simpleMessage(
      "During Hajj, pilgrims **exit the state of ihram** in two stages: **Tahallul Awwal** (the first release) and **Tahallul Thani** (the final release). Each stage becomes valid after completing specific rites of the Day of \'Eid. Understanding these two levels helps the pilgrim know **what becomes permissible at each point** and when full release from ihram is achieved.",
    ),
    "hajjStepTahallulSubStep1": MessageLookupByLibrary.simpleMessage(
      "**Tahallul Awwal** happens when you **complete any two** of the following three actions on the Day of \'Eid (10th of Dhul Hijjah):\n• Stoning Jamarat al-\'Aqabah\n• Shaving or trimming your hair\n• Performing Tawaf al-Ifadah and Sa\'i (if Sa\'i is required)\n\nThis means that if you:\n• stone **and** shave, or\n• stone **and** perform Tawaf/Sa\'i, or\n• perform Tawaf/Sa\'i **and** shave,\n**you will enter Tahallul Awwal.**\n\nAfter this first release, **you may wear normal clothes, apply perfume, and resume all normal activities—<red>except marital relations, which remain prohibited until you complete Tahallul Thani.</red>**\n\n**This is supported by narrations such as the hadith from Aisha (RA), where the Prophet ﷺ said:** \"When he [the pilgrim] has thrown the Jamrah and shaved his head, then everything becomes lawful for him except women.\" (Hadith, Bukhari)",
    ),
    "hajjStepTahallulSubStep2": MessageLookupByLibrary.simpleMessage(
      "**Tahallul Thani** occurs when you complete **all three actions**:\n• stoning Jamarat al-\'Aqabah,\n• shaving or trimming,\n• and performing Tawaf al-Ifadah with Sa\'i (if required).\n\nOnce these are done, the pilgrim achieves **full release** from ihram, and **everything—including marital relations—becomes permissible.**\n\n**This is the complete exit from Ihram** and fulfills all the main rites of the Day of Sacrifice following the practice of the Prophet ﷺ, who stoned, then sacrificed, then shaved, after which \'Aishah (RA) perfumed him — indicating he had completed his full release.",
    ),
    "hajjStepTawafAlIfadah": MessageLookupByLibrary.simpleMessage(
      "Tawaf al-Ifadah",
    ),
    "hajjStepTawafAlIfadahDescription": MessageLookupByLibrary.simpleMessage(
      "Head to the Haram to perform Tawaf al-Ifadah",
    ),
    "hajjStepTawafAlIfadahSubStep1": MessageLookupByLibrary.simpleMessage(
      "Perform tawaf by completing 7 circuits around the Kaaba.",
    ),
    "hajjStepTawafAlIfadahSubStep2": MessageLookupByLibrary.simpleMessage(
      "After completing the tawaf, pray two rak\'ahs behind Maqam Ibrahim, if possible.",
    ),
    "hajjStepTawafAlIfadahSubStep3": MessageLookupByLibrary.simpleMessage(
      "Perform Sa\'ee if you have not done it earlier. **If you already performed Sa\'ee with Tawaf al-Qudum, you do not need to repeat it.**",
    ),
    "hajjStepTawafAlQudum": MessageLookupByLibrary.simpleMessage(
      "Tawaf al-Qudum",
    ),
    "hajjStepTawafAlQudumDescription": MessageLookupByLibrary.simpleMessage(
      "When **The Prophet ﷺ** arrived in Makkah he performed Tawaf al-Qudum, it is Sunnah. After this tawaf, the Sa\'ee may be performed immediately or postponed until after Tawaf al-Ifadah, but **The Prophet ﷺ** performed Sa\'ee right after Tawaf al-Qudum.\n\nPerform **seven counter-clockwise circuits around the Kaaba**, beginning at the Hajar al-Aswad (Black Stone) and completing each round by returning to the same point, **while remaining in a state of wuduu.**\n\n**After completing the Tawaf**, perform two rak\'ahs of prayer. You may pray anywhere in the mosque, though it is recommended to pray behind Maqam Ibrahim if possible.",
    ),
    "hajjStepTawafAlWada": MessageLookupByLibrary.simpleMessage(
      "Tawaf al-Wada\'",
    ),
    "hajjStepTawafAlWadaDescription": MessageLookupByLibrary.simpleMessage(
      "This is the final act of your Hajj journey. You should perform Tawaf al-Wada\' and then depart directly afterward. Performing Tawaf al-Wada\' is obligatory — **<red>if you skip it</red>**, you must offer a sacrificial animal. If a woman begins her menstrual period, she is excused from performing the Farewell Tawaf.",
    ),
    "hajjStepTawafAlWadaSubStep1": MessageLookupByLibrary.simpleMessage(
      "Perform the Farewell Tawaf (7 circuits).",
    ),
    "hajjStepTawafAlWadaSubStep2": MessageLookupByLibrary.simpleMessage(
      "Pray two rak\'ahs behind Maqam Ibrahim.",
    ),
    "hajjStepTawafAlWadaSubStep3": MessageLookupByLibrary.simpleMessage(
      "Drink Zamzam water.",
    ),
    "hajjStepTawafAlWadaSubStep4": MessageLookupByLibrary.simpleMessage(
      "Make a final farewell Dua at the Multazam.",
    ),
    "hello": MessageLookupByLibrary.simpleMessage("Hello"),
    "hijjGuidance": MessageLookupByLibrary.simpleMessage("Hijj guidance"),
    "historicSites": MessageLookupByLibrary.simpleMessage("Historic Sites"),
    "hotels": MessageLookupByLibrary.simpleMessage("Hotels"),
    "hour": MessageLookupByLibrary.simpleMessage("hour"),
    "hourShort": MessageLookupByLibrary.simpleMessage("h"),
    "hours": MessageLookupByLibrary.simpleMessage("hours"),
    "hoursShort": MessageLookupByLibrary.simpleMessage("h"),
    "httpException": MessageLookupByLibrary.simpleMessage(
      "Server connection error",
    ),
    "iconAndIconDataCannotBeNull": MessageLookupByLibrary.simpleMessage(
      "Icon and icon data cannot be null",
    ),
    "ihram": MessageLookupByLibrary.simpleMessage("Ihram"),
    "invalidEmail": MessageLookupByLibrary.simpleMessage(
      "The email address is invalid.",
    ),
    "isha": MessageLookupByLibrary.simpleMessage("Isha"),
    "kaaba": MessageLookupByLibrary.simpleMessage("Kaaba"),
    "lName": MessageLookupByLibrary.simpleMessage("Last name"),
    "lNameInvalid": MessageLookupByLibrary.simpleMessage("Last name invalid"),
    "lNameRequired": MessageLookupByLibrary.simpleMessage("Last name required"),
    "loadingMap": MessageLookupByLibrary.simpleMessage("Loading map..."),
    "location": MessageLookupByLibrary.simpleMessage("Location"),
    "login": MessageLookupByLibrary.simpleMessage("Login"),
    "logout": MessageLookupByLibrary.simpleMessage("Logout"),
    "maghrib": MessageLookupByLibrary.simpleMessage("Maghrib"),
    "main": MessageLookupByLibrary.simpleMessage("Main"),
    "manageCompanions": MessageLookupByLibrary.simpleMessage(
      "Manage companions",
    ),
    "map": MessageLookupByLibrary.simpleMessage("Map"),
    "meccaSaudiArabia": MessageLookupByLibrary.simpleMessage(
      "Mecca, Saudi Arabia",
    ),
    "medinaSaudiArabia": MessageLookupByLibrary.simpleMessage(
      "Medina, Saudi Arabia",
    ),
    "mensIhramGarments": MessageLookupByLibrary.simpleMessage(
      "Men\'s Ihram Garments",
    ),
    "mensIhramGarmentsDescription": MessageLookupByLibrary.simpleMessage(
      "A man is **<red>prohibited from wearing stitched clothing</red>** when entering ihram. He must remove his usual clothes, including head coverings such as hats or turbans, and any tailored clothing that fits the body, such as shirts, pants, socks, gloves, or anything similar. He also **<red>must not wear shoes that cover the entire foot</red>** including the heel.  A man should wear an izar (lower wrap) covering the lower body and a rida (upper wrap) covering the upper body. It is recommended that these garments be white. Sandals that do not cover the entire foot are permissible.",
    ),
    "millionShort": MessageLookupByLibrary.simpleMessage("M"),
    "mina": MessageLookupByLibrary.simpleMessage("Mina"),
    "minute": MessageLookupByLibrary.simpleMessage("minute"),
    "minuteShort": MessageLookupByLibrary.simpleMessage("m"),
    "minutes": MessageLookupByLibrary.simpleMessage("minutes"),
    "minutesShort": MessageLookupByLibrary.simpleMessage("m"),
    "month": MessageLookupByLibrary.simpleMessage("month"),
    "monthShort": MessageLookupByLibrary.simpleMessage("m"),
    "months": MessageLookupByLibrary.simpleMessage("months"),
    "monthsShort": MessageLookupByLibrary.simpleMessage("m"),
    "mosques": MessageLookupByLibrary.simpleMessage("Mosques"),
    "museums": MessageLookupByLibrary.simpleMessage("Museums"),
    "mustBeAtLeast8CharactersLong": MessageLookupByLibrary.simpleMessage(
      "Must be at least 8 characters long",
    ),
    "mustIncludeAtLeastOneDigit": MessageLookupByLibrary.simpleMessage(
      "Must include at least one digit (0–9)",
    ),
    "mustIncludeAtLeastOneLowercaseLetter":
        MessageLookupByLibrary.simpleMessage(
          "Must include at least one lowercase letter (a–z)",
        ),
    "mustIncludeAtLeastOneSpecialCharacter":
        MessageLookupByLibrary.simpleMessage(
          "Must include at least one special character (!@#\$%^&*()_+)",
        ),
    "mustIncludeAtLeastOneUppercaseLetter":
        MessageLookupByLibrary.simpleMessage(
          "Must include at least one uppercase letter (A–Z)",
        ),
    "mustNotContainSpaces": MessageLookupByLibrary.simpleMessage(
      "Must not contain spaces",
    ),
    "muzdalifa": MessageLookupByLibrary.simpleMessage("Muzdalifa"),
    "name": MessageLookupByLibrary.simpleMessage("Name"),
    "nameInvalid": MessageLookupByLibrary.simpleMessage("Name invalid"),
    "nameRequired": MessageLookupByLibrary.simpleMessage("Name required"),
    "newPassword": MessageLookupByLibrary.simpleMessage("New Password"),
    "newPasswordMustBeDifferent": MessageLookupByLibrary.simpleMessage(
      "New password must be different from current password",
    ),
    "ninthDhulHijjah": MessageLookupByLibrary.simpleMessage(
      "Ninth Dhul Hijjah",
    ),
    "noNotYet": MessageLookupByLibrary.simpleMessage("No, not yet"),
    "none": MessageLookupByLibrary.simpleMessage("None"),
    "notFoundException": MessageLookupByLibrary.simpleMessage(
      "Not found exception",
    ),
    "openMap": MessageLookupByLibrary.simpleMessage("Open Map"),
    "operationNotAllowed": MessageLookupByLibrary.simpleMessage(
      "Operation not allowed.",
    ),
    "pageNotFoundMsg": MessageLookupByLibrary.simpleMessage("Page not found"),
    "password": MessageLookupByLibrary.simpleMessage("Password"),
    "passwordChanged": MessageLookupByLibrary.simpleMessage("Password changed"),
    "passwordChangedSuccessfully": MessageLookupByLibrary.simpleMessage(
      "Your password has been changed successfully",
    ),
    "passwordDoesNotMeetAllRequirements": MessageLookupByLibrary.simpleMessage(
      "Password does not meet all requirements",
    ),
    "passwordLength": MessageLookupByLibrary.simpleMessage(
      "Password length must be longer than 8 characters",
    ),
    "passwordRequired": MessageLookupByLibrary.simpleMessage(
      "Password required",
    ),
    "passwordRequirements": MessageLookupByLibrary.simpleMessage(
      "Password Requirements",
    ),
    "pending": MessageLookupByLibrary.simpleMessage("Pending"),
    "phoneInvalid": MessageLookupByLibrary.simpleMessage(
      "Phone number invalid",
    ),
    "phoneLength": MessageLookupByLibrary.simpleMessage(
      "Phone number must be longer than 10 characters",
    ),
    "phoneNumber": MessageLookupByLibrary.simpleMessage("Phone number"),
    "phoneNumberInvalid": MessageLookupByLibrary.simpleMessage(
      "Phone number invalid",
    ),
    "phoneNumberLength": MessageLookupByLibrary.simpleMessage(
      "Phone number must be longer than 10 characters",
    ),
    "phoneNumberRequired": MessageLookupByLibrary.simpleMessage(
      "Phone number required",
    ),
    "pleaseCheckYourEmail": MessageLookupByLibrary.simpleMessage(
      "Please check your email",
    ),
    "pleaseTypeSomethingYoullRemember": MessageLookupByLibrary.simpleMessage(
      "Please type something you\'ll remember",
    ),
    "pleaseVerifyYourEmailFirst": MessageLookupByLibrary.simpleMessage(
      "Please verify your email first",
    ),
    "profile": MessageLookupByLibrary.simpleMessage("Profile"),
    "progress": MessageLookupByLibrary.simpleMessage("Progress"),
    "progressDescription": m0,
    "progressResetSuccessfully": MessageLookupByLibrary.simpleMessage(
      "Progress reset successfully",
    ),
    "prohibitionApplyingPerfume": MessageLookupByLibrary.simpleMessage(
      "Applying perfume",
    ),
    "prohibitionCoveringHead": MessageLookupByLibrary.simpleMessage(
      "Covering the head (for men)",
    ),
    "prohibitionCuttingNails": MessageLookupByLibrary.simpleMessage(
      "Cutting nails",
    ),
    "prohibitionHunting": MessageLookupByLibrary.simpleMessage("Hunting"),
    "prohibitionMarriageContract": MessageLookupByLibrary.simpleMessage(
      "Marriage contract (nikah)",
    ),
    "prohibitionNiqabGloves": MessageLookupByLibrary.simpleMessage(
      "Wearing the niqab or gloves (for women)",
    ),
    "prohibitionSexualIntercourse": MessageLookupByLibrary.simpleMessage(
      "Sexual intercourse",
    ),
    "prohibitionShavingHair": MessageLookupByLibrary.simpleMessage(
      "Shaving or cutting hair during Ihram",
    ),
    "prohibitionWearingStitchedClothing": MessageLookupByLibrary.simpleMessage(
      "Wearing stitched clothing (for men)",
    ),
    "prohibitionsOfIhram": MessageLookupByLibrary.simpleMessage(
      "Prohibitions of Ihram",
    ),
    "prophetsMosque": MessageLookupByLibrary.simpleMessage("Prophet\'s Mosque"),
    "rateUs": MessageLookupByLibrary.simpleMessage("Rate Us"),
    "register": MessageLookupByLibrary.simpleMessage("Register"),
    "remaining": MessageLookupByLibrary.simpleMessage("Remaining"),
    "rememberMe": MessageLookupByLibrary.simpleMessage("Remember me"),
    "rememberPasswordQuestion": MessageLookupByLibrary.simpleMessage(
      "Remember password?",
    ),
    "resendCode": MessageLookupByLibrary.simpleMessage("Resend code"),
    "resendLink": MessageLookupByLibrary.simpleMessage("Resend link"),
    "reset": MessageLookupByLibrary.simpleMessage("Reset"),
    "resetLinkSent": MessageLookupByLibrary.simpleMessage("Reset link sent"),
    "resetLinkSentMessage": MessageLookupByLibrary.simpleMessage(
      "Please check your email to reset your password",
    ),
    "resetPassword": MessageLookupByLibrary.simpleMessage("Reset password"),
    "resetProgress": MessageLookupByLibrary.simpleMessage("Reset Progress"),
    "resetProgressConfirmation": MessageLookupByLibrary.simpleMessage(
      "Are you sure you want to reset your Umrah progress? This action cannot be undone.",
    ),
    "retry": MessageLookupByLibrary.simpleMessage("Retry"),
    "ritualGuidance": MessageLookupByLibrary.simpleMessage("Ritual Guidance"),
    "ritualSites": MessageLookupByLibrary.simpleMessage("Ritual Sites"),
    "saee": MessageLookupByLibrary.simpleMessage("Sa\'ee"),
    "saeeSubDesc1": MessageLookupByLibrary.simpleMessage(
      "Proceed to as-Safa, where the sa\'ee begins toward al-Marwah. <gold>The Prophet ﷺ used to:</gold> jog between the two green markers during Sa\'ee, this Sunnah is specific to men.",
    ),
    "saeeSubDesc2": MessageLookupByLibrary.simpleMessage(
      "When the you reach al-Marwah, one round is completed.",
    ),
    "saeeSubDesc3": MessageLookupByLibrary.simpleMessage(
      "Return to as-Safa for the second round, continuing in this manner until completing seven rounds, ending at al-Marwah.",
    ),
    "saeeSubDesc4": MessageLookupByLibrary.simpleMessage(
      "It is permissible for someone who is unable to walk, or who feels exhausted, ill, or weak, to perform sa\'ee while being carried or transported. However, they must remain awake and attentive, as sa\'ee is an act of worship, and they should make use of their time by supplicating and turning to Allah with humility.",
    ),
    "search": MessageLookupByLibrary.simpleMessage("Search"),
    "second": MessageLookupByLibrary.simpleMessage("second"),
    "secondShort": MessageLookupByLibrary.simpleMessage("s"),
    "seconds": MessageLookupByLibrary.simpleMessage("seconds"),
    "secondsShort": MessageLookupByLibrary.simpleMessage("s"),
    "sendCode": MessageLookupByLibrary.simpleMessage("Send code"),
    "sendResetLink": MessageLookupByLibrary.simpleMessage("Send Reset Link"),
    "services": MessageLookupByLibrary.simpleMessage("Services"),
    "settings": MessageLookupByLibrary.simpleMessage("Settings"),
    "shareApp": MessageLookupByLibrary.simpleMessage("Share App"),
    "showLess": MessageLookupByLibrary.simpleMessage("Show Less"),
    "showMore": MessageLookupByLibrary.simpleMessage("Show More"),
    "signIn": MessageLookupByLibrary.simpleMessage("Sign in"),
    "signInFailed": MessageLookupByLibrary.simpleMessage("Sign in failed"),
    "signInToYourAccount": MessageLookupByLibrary.simpleMessage(
      "Sign in to your account",
    ),
    "signUp": MessageLookupByLibrary.simpleMessage("Sign up"),
    "signUpFailed": MessageLookupByLibrary.simpleMessage("Sign up failed"),
    "socketException": MessageLookupByLibrary.simpleMessage(
      "Socket connection error",
    ),
    "someResourcesAreDownException": MessageLookupByLibrary.simpleMessage(
      "Some resources are down exception",
    ),
    "startYourPathTowardHajjAndUmrahWithPersonalizedGuidance":
        MessageLookupByLibrary.simpleMessage(
          "Start your path toward Hajj and Umrah with personalized guidance",
        ),
    "step": MessageLookupByLibrary.simpleMessage("Step"),
    "step1Description": MessageLookupByLibrary.simpleMessage(
      "A Muslim enters into the state of Ihraam from the place specified for him by Islamic law, and he abstains from the prohibitions which he is prohibited from while in Ihraam.",
    ),
    "step1GuidanceDescription": MessageLookupByLibrary.simpleMessage(
      "A Muslim enters into the state of Ihraam from the place specified for him by Islamic law, and he abstains from the prohibitions which he is prohibited from while in Ihraam.",
    ),
    "step2Description": MessageLookupByLibrary.simpleMessage(
      "An act of worship in which a Muslim circumambulates around the Kaaba **seven times**, worshiping and drawing closer to Allah.",
    ),
    "step2GuidanceDescription": MessageLookupByLibrary.simpleMessage(
      "Tawaf is the first act of worship performed by a pilgrim in the state of ihram. It is a circular movement around the Kaaba, performed counterclockwise, starting from the Black Stone (Hajar al-Aswad).",
    ),
    "step3Description": MessageLookupByLibrary.simpleMessage(
      "During this ritual, the pilgrim worships Allah by walking between as-Safa and al-Marwah seven times, following the practice of the noble The Prophet ﷺ.  Performing sa\'ee without wudu is permissible and carries no sin. Although being in a state of purity is preferable if possible.",
    ),
    "step4Description": MessageLookupByLibrary.simpleMessage(
      "Shortening the hair during Umrah is a required and essential ritual for completing the pilgrimage. It is performed after finishing the Sa\'ee between Safa and Marwah by cutting a portion of the hair on the head. Through this act, the pilgrim exits the state of Ihram and is once again permitted to engage in the activities that were prohibited during Ihram.\n\nFor men, shaving the head is better and more rewarding than simply shortening , as <gold>The Prophet ﷺ supplicated three times for those who shave and only once for those who shorten.</gold> \n\n<gold>\"O Allah! Forgive those who get their heads shaved.\"</gold> The people asked. <gold>\"Also those who get their hair cut short?\"</gold> <gold>The Prophet (ﷺ) said, \"O Allah! Forgive those who have their heads shaved.\"</gold> The people said, <gold>\"Also those who get their hair cut short?\"</gold> <gold>The Prophet (invoke Allah for those who have their heads shaved and) at the third time said, \"also (forgive) those who get their hair cut short.\"</gold> —Sahih al-Bukhari 1728 Book 25, Hadith 206",
    ),
    "stepCompletedConfirmation": MessageLookupByLibrary.simpleMessage(
      "Have you completed this step?",
    ),
    "stepCompletedConfirmationMessage": m1,
    "stepMarkedAsCompleted": MessageLookupByLibrary.simpleMessage(
      "Step marked as completed",
    ),
    "steps": MessageLookupByLibrary.simpleMessage("Steps"),
    "success": MessageLookupByLibrary.simpleMessage("Success"),
    "sunrise": MessageLookupByLibrary.simpleMessage("Sunrise"),
    "tahallul": MessageLookupByLibrary.simpleMessage("Tahallul"),
    "tawaf": MessageLookupByLibrary.simpleMessage("Tawaf"),
    "tawafSubDesc1": MessageLookupByLibrary.simpleMessage(
      " Begin tawaf with the Kaaba on your Left\n start at the Black Stone, facing it, and say \"Bismillah, Allahu Akbar\" as you begin your first circuit.",
    ),
    "tawafSubDesc2": MessageLookupByLibrary.simpleMessage(
      "When you reach the Yemeni corner, If you can touch it with your right hand, do so and say: \"Bismillah, Allahu Akbar.\" <red>Don\'t kiss or point at the Yemeni corner it\'s not from the Sunnah.</red>",
    ),
    "tawafSubDesc3": MessageLookupByLibrary.simpleMessage(
      "When you reach the Black Stone touch and kiss it if possible. If not, point toward it with your hand once and say \"Allahu Akbar.\"",
    ),
    "tawafSubDesc4": MessageLookupByLibrary.simpleMessage(
      "Engage in Duaa and Thikr, There is no specific dua required for each round.",
    ),
    "tawafSubDesc5": MessageLookupByLibrary.simpleMessage(
      "Walk briskly with short quick steps during the first three rounds of Tawaf, specific to men",
    ),
    "tawafSubDesc6": MessageLookupByLibrary.simpleMessage(
      "Keep the right shoulder uncovered by placing the middle of the upper garment under the right arm and the ends over the left shoulder during all rounds of Tawaf al-Qudum.",
    ),
    "tawafSubDesc7": MessageLookupByLibrary.simpleMessage(
      "<gold>The Prophet ﷺ used to:</gold> Recite the dua:\n\"Rabbana ātinā fid-dunyā ḥasanah, wa fil-ākhirati ḥasanah, wa qinā \'adhāban-nār.\" Between the Yemeni Corner and the Black Stone",
    ),
    "technicalSupport": MessageLookupByLibrary.simpleMessage(
      "Technical Support",
    ),
    "tenthDhulHijjah": MessageLookupByLibrary.simpleMessage(
      "Tenth Dhul Hijjah",
    ),
    "tenthToTwelfthDhulHijjah": MessageLookupByLibrary.simpleMessage(
      "Tenth To Twelfth Dhul Hijjah",
    ),
    "thourCave": MessageLookupByLibrary.simpleMessage("Thour Cave"),
    "thousandShort": MessageLookupByLibrary.simpleMessage("K"),
    "timeAgo": m10,
    "timeAgoDays": m2,
    "timeAgoHours": m3,
    "timeAgoMinutes": m4,
    "timeAgoMonths": m5,
    "timeAgoSeconds": m6,
    "timeAgoShort": m7,
    "timeAgoYears": m8,
    "timeOutException": MessageLookupByLibrary.simpleMessage(
      "Timeout exception",
    ),
    "tooManyRequests": MessageLookupByLibrary.simpleMessage(
      "Too many requests. Please try again later.",
    ),
    "tooManyRequestsException": MessageLookupByLibrary.simpleMessage(
      "Too many requests",
    ),
    "typeYourMessage": MessageLookupByLibrary.simpleMessage(
      "Type your message...",
    ),
    "umrah": MessageLookupByLibrary.simpleMessage("Umrah"),
    "umrahGuidance": MessageLookupByLibrary.simpleMessage("Umrah Guidance"),
    "unAuthorized": MessageLookupByLibrary.simpleMessage("Unauthorized"),
    "underMaintenanceException": MessageLookupByLibrary.simpleMessage(
      "Under maintenance",
    ),
    "unexpectedErrorOccurred": MessageLookupByLibrary.simpleMessage(
      "An unexpected error occurred. Please try again.",
    ),
    "unit_day": MessageLookupByLibrary.simpleMessage("day"),
    "unit_dayShort": MessageLookupByLibrary.simpleMessage("d"),
    "unit_hour": MessageLookupByLibrary.simpleMessage("hour"),
    "unit_hourShort": MessageLookupByLibrary.simpleMessage("h"),
    "unit_minute": MessageLookupByLibrary.simpleMessage("minute"),
    "unit_minuteShort": MessageLookupByLibrary.simpleMessage("m"),
    "unit_month": MessageLookupByLibrary.simpleMessage("month"),
    "unit_monthShort": MessageLookupByLibrary.simpleMessage("mo"),
    "unit_second": MessageLookupByLibrary.simpleMessage("second"),
    "unit_secondShort": MessageLookupByLibrary.simpleMessage("s"),
    "unit_year": MessageLookupByLibrary.simpleMessage("year"),
    "unit_yearShort": MessageLookupByLibrary.simpleMessage("y"),
    "uploading": MessageLookupByLibrary.simpleMessage("Uploading"),
    "userDisabled": MessageLookupByLibrary.simpleMessage(
      "This user account has been disabled.",
    ),
    "userNotFound": MessageLookupByLibrary.simpleMessage(
      "No user found for that email.",
    ),
    "verify": MessageLookupByLibrary.simpleMessage("Verify"),
    "wadiJalil": MessageLookupByLibrary.simpleMessage("Wadi Jalil"),
    "waitingForVerification": MessageLookupByLibrary.simpleMessage(
      "Waiting for email verification...",
    ),
    "weakPassword": MessageLookupByLibrary.simpleMessage(
      "The password provided is too weak.",
    ),
    "welcomeToLabbaik": MessageLookupByLibrary.simpleMessage(
      "Welcome to Labbaik",
    ),
    "welcomeToLabbaikAssistant": MessageLookupByLibrary.simpleMessage(
      "Welcome to Labbaik Assistant",
    ),
    "weveSentACodeTo": m9,
    "womensIhramGarments": MessageLookupByLibrary.simpleMessage(
      "Women\'s Ihram Garments",
    ),
    "womensIhramGarmentsDescription": MessageLookupByLibrary.simpleMessage(
      "It is permissible for a woman to wear stitched clothing when entering ihram, and she may choose any type of garment in any color or style. However, her clothing must be **loose-fitting**, **provide full coverage**, allow ease of movement, and **<red>not include visible adornment that may attract attention.</red>**\n**<gold>The Prophet ﷺ guided those entering ihram, saying:</gold>**\n\"A woman should not wear the niqab (face veil) nor gloves while in ihram.\"",
    ),
    "wrongPassword": MessageLookupByLibrary.simpleMessage(
      "Wrong password provided.",
    ),
    "year": MessageLookupByLibrary.simpleMessage("year"),
    "yearShort": MessageLookupByLibrary.simpleMessage("y"),
    "years": MessageLookupByLibrary.simpleMessage("years"),
    "yearsShort": MessageLookupByLibrary.simpleMessage("y"),
    "yesCompleted": MessageLookupByLibrary.simpleMessage("Yes, I completed it"),
    "yourHajjJourney": MessageLookupByLibrary.simpleMessage(
      "Your Hajj Journey",
    ),
    "yourLabbaikJourneyAwaitsLogInToReconnectWithYourGuidance":
        MessageLookupByLibrary.simpleMessage(
          "Your Labbaik journey awaits, log in to reconnect with your guidance",
        ),
  };
}
