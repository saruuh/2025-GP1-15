// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ar locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'ar';

  static String m0(completedSteps, totalSteps, stepsCount) =>
      "${completedSteps}/${totalSteps} ${Intl.plural(stepsCount, one: 'خطوة', other: 'خطوات')}";

  static String m1(stepName) => "هل أنت متأكد من أنك أكملت ${stepName}؟";

  static String m2(value) =>
      "${Intl.plural(value, zero: 'الآن', one: 'قبل يوم', two: 'قبل يومين', few: 'قبل ${value} أيام', many: 'قبل ${value} يومًا', other: 'قبل ${value} يوم')}";

  static String m3(value) =>
      "${Intl.plural(value, zero: 'الآن', one: 'قبل ساعة', two: 'قبل ساعتين', few: 'قبل ${value} ساعات', many: 'قبل ${value} ساعة', other: 'قبل ${value} ساعة')}";

  static String m4(value) =>
      "${Intl.plural(value, zero: 'الآن', one: 'قبل دقيقة', two: 'قبل دقيقتين', few: 'قبل ${value} دقائق', many: 'قبل ${value} دقيقة', other: 'قبل ${value} دقيقة')}";

  static String m5(value) =>
      "${Intl.plural(value, zero: 'الآن', one: 'قبل شهر', two: 'قبل شهرين', few: 'قبل ${value} أشهر', many: 'قبل ${value} شهرًا', other: 'قبل ${value} شهر')}";

  static String m6(value) =>
      "${Intl.plural(value, zero: 'الآن', one: 'قبل ثانية', two: 'قبل ثانيتين', few: 'قبل ${value} ثوانٍ', many: 'قبل ${value} ثانية', other: 'قبل ${value} ثانية')}";

  static String m7(value, unitShort) => "${value}${unitShort}";

  static String m8(value) =>
      "${Intl.plural(value, zero: 'الآن', one: 'قبل سنة', two: 'قبل سنتين', few: 'قبل ${value} سنوات', many: 'قبل ${value} سنة', other: 'قبل ${value} سنة')}";

  static String m9(email) => "لقد أرسلنا رابط التحقق إلى ${email}";

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
    "account": MessageLookupByLibrary.simpleMessage("الحساب"),
    "active": MessageLookupByLibrary.simpleMessage("نشط"),
    "addressInvalid": MessageLookupByLibrary.simpleMessage("العنوان غير صالح"),
    "addressLength": MessageLookupByLibrary.simpleMessage(
      "العنوان يجب أن يكون أطول من 3 أحرف",
    ),
    "addressRequired": MessageLookupByLibrary.simpleMessage("العنوان مطلوب"),
    "ago": MessageLookupByLibrary.simpleMessage("منذ"),
    "alMuqayti": MessageLookupByLibrary.simpleMessage("المقيطي"),
    "alUsaylah": MessageLookupByLibrary.simpleMessage("العسيلة"),
    "album": MessageLookupByLibrary.simpleMessage("الألبوم"),
    "all": MessageLookupByLibrary.simpleMessage("الكل"),
    "alreadyHaveAnAccount": MessageLookupByLibrary.simpleMessage("لديك حساب؟"),
    "app": MessageLookupByLibrary.simpleMessage("التطبيق"),
    "appLanguage": MessageLookupByLibrary.simpleMessage("لغة التطبيق"),
    "arabic": MessageLookupByLibrary.simpleMessage("العربية"),
    "askMeAnythingAboutUmrah": MessageLookupByLibrary.simpleMessage(
      "اسألني أي شيء عن العمرة",
    ),
    "asr": MessageLookupByLibrary.simpleMessage("العصر"),
    "backToLogin": MessageLookupByLibrary.simpleMessage("العودة لتسجيل الدخول"),
    "backToLoginQuestion": MessageLookupByLibrary.simpleMessage(
      "ليس لديك حساب؟",
    ),
    "badRequestException": MessageLookupByLibrary.simpleMessage("خطأ في الطلب"),
    "bathaQuraish": MessageLookupByLibrary.simpleMessage("بطحاء قريش"),
    "beginning": MessageLookupByLibrary.simpleMessage("بداية"),
    "cacheException": MessageLookupByLibrary.simpleMessage(
      "خطأ في التخزين المؤقت",
    ),
    "calendar": MessageLookupByLibrary.simpleMessage("التقويم"),
    "cancel": MessageLookupByLibrary.simpleMessage("إلغاء"),
    "cancelException": MessageLookupByLibrary.simpleMessage("تم الإلغاء"),
    "changePassword": MessageLookupByLibrary.simpleMessage("تغيير كلمة المرور"),
    "clickTheLinkInYourEmail": MessageLookupByLibrary.simpleMessage(
      "انقر على رابط التحقق في بريدك الإلكتروني للتحقق من حسابك",
    ),
    "complete": MessageLookupByLibrary.simpleMessage("مكتمل"),
    "completed": MessageLookupByLibrary.simpleMessage("مكتمل"),
    "confirmNewPassword": MessageLookupByLibrary.simpleMessage(
      "تأكيد كلمة المرور الجديدة",
    ),
    "confirmPassword": MessageLookupByLibrary.simpleMessage(
      "تأكيد كلمة المرور",
    ),
    "confirmPasswordNotMatch": MessageLookupByLibrary.simpleMessage(
      "كلمة المرور غير مطابقة",
    ),
    "currentPassword": MessageLookupByLibrary.simpleMessage(
      "كلمة المرور الحالية",
    ),
    "darkMode": MessageLookupByLibrary.simpleMessage("الوضع الداكن"),
    "dataNotCompleted": MessageLookupByLibrary.simpleMessage(
      "البيانات غير مكتملة",
    ),
    "dateOfBirth": MessageLookupByLibrary.simpleMessage("تاريخ الميلاد"),
    "dateOfBirthRequired": MessageLookupByLibrary.simpleMessage(
      "تاريخ الميلاد مطلوب",
    ),
    "day": MessageLookupByLibrary.simpleMessage("يوم"),
    "day1": MessageLookupByLibrary.simpleMessage("اليوم 1"),
    "day2": MessageLookupByLibrary.simpleMessage("اليوم 2"),
    "day3To5": MessageLookupByLibrary.simpleMessage("الأيام 3 - 5"),
    "dayOfArafah": MessageLookupByLibrary.simpleMessage("يوم عرفة"),
    "dayOfNahr": MessageLookupByLibrary.simpleMessage("يوم النحر"),
    "dayOfTarwiyah": MessageLookupByLibrary.simpleMessage("يوم التروية"),
    "dayShort": MessageLookupByLibrary.simpleMessage("ي"),
    "days": MessageLookupByLibrary.simpleMessage("أيام"),
    "daysOfTashreeq": MessageLookupByLibrary.simpleMessage("أيام التشريق"),
    "daysShort": MessageLookupByLibrary.simpleMessage("ي"),
    "deleteComment": MessageLookupByLibrary.simpleMessage("حذف التعليق"),
    "deleteCommentMsg": MessageLookupByLibrary.simpleMessage(
      "هل أنت متأكد من حذف التعليق؟",
    ),
    "description": MessageLookupByLibrary.simpleMessage("الوصف"),
    "dhuhr": MessageLookupByLibrary.simpleMessage("الظهر"),
    "doNotShowAgain": MessageLookupByLibrary.simpleMessage(
      "لا تظهر هذه الرسالة مرة أخرى",
    ),
    "donTworryItHappensPleaseEnterTheEmailAssociatedWithYourAccount":
        MessageLookupByLibrary.simpleMessage(
          "لا تقلق! يحدث هذا. يرجى إدخال البريد الإلكتروني المرتبط بحسابك.",
        ),
    "downloadedSuccessfully": MessageLookupByLibrary.simpleMessage(
      "تم التحميل بنجاح",
    ),
    "eighthDhulHijjah": MessageLookupByLibrary.simpleMessage(
      "الثامن من ذي الحجة",
    ),
    "elevensToThirteenthDhulHijjah": MessageLookupByLibrary.simpleMessage(
      "من 11 إلى 13 ذي الحجة",
    ),
    "email": MessageLookupByLibrary.simpleMessage("البريد الإلكتروني"),
    "emailAlreadyInUse": MessageLookupByLibrary.simpleMessage(
      "يوجد حساب بالفعل لهذا البريد الإلكتروني.",
    ),
    "emailInvalid": MessageLookupByLibrary.simpleMessage(
      "البريد الإلكتروني غير صالح",
    ),
    "emailRequired": MessageLookupByLibrary.simpleMessage(
      "البريد الإلكتروني مطلوب",
    ),
    "english": MessageLookupByLibrary.simpleMessage("الانجليزية"),
    "enterCode": MessageLookupByLibrary.simpleMessage("أدخل الرمز"),
    "enterYourEmail": MessageLookupByLibrary.simpleMessage(
      "أدخل عنوان بريدك الإلكتروني وسنرسل لك رابط إعادة تعيين كلمة المرور",
    ),
    "enteringIhramAtMiqat": MessageLookupByLibrary.simpleMessage(
      "الدخول في الإحرام عند الميقات",
    ),
    "enteringIhramAtMiqatDescription": MessageLookupByLibrary.simpleMessage(
      "عند الوصول إلى الميقات، ينوي المعتمر الدخول في النسك بقلبه. وتكون النية عند محاذاة الميقات أو قبله بقليل. ثم يتلفظ بالنية قائلاً: \"لبيك عمرة\"، ويشرع في التلبية.\n<gold>من سنن الإحرام:</gold>\n• الاغتسال والتنظف (للرجال والنساء).\n• التطيب في البدن قبل لبس الإحرام (للرجال). <red>أما بعد الإحرام فيحرم الطيب.</red>\n\nاشتراط المحرم\nإذا **خشي المحرم ألا يتمكن من إتمام نسكه** لمرض أو نحوه، يسن له أن **يشترط** عند إحرامه فيقول بعد التلبية: \"فإن حبسني حابس فمحلي حيث حبستني\". وفائدة هذا الاشتراط أنه لو طرأ عليه ما يمنعه من إتمام النسك، جاز له التحلل ولا شيء عليه.",
    ),
    "enteringIhramFromAirplane": MessageLookupByLibrary.simpleMessage(
      "الدخول في الإحرام من الطائرة",
    ),
    "enteringIhramFromAirplaneDescription": MessageLookupByLibrary.simpleMessage(
      "من سافر بالطائرة وأراد العمرة، فإنه يحرم **إذا حاذى الميقات وهو في الجو**. ويجب عليه أن يتهيأ لذلك بالاغتسال ولبس ثياب الإحرام قبل ركوب الطائرة أو في الطائرة قبل محاذاة الميقات، حتى لا يتجاوز الميقات إلا وهو محرم.",
    ),
    "error": MessageLookupByLibrary.simpleMessage("خطأ"),
    "errorOccurred": MessageLookupByLibrary.simpleMessage(
      "حدث خطأ. يرجى المحاولة مرة أخرى.",
    ),
    "fName": MessageLookupByLibrary.simpleMessage("الاسم الأول"),
    "fNameInvalid": MessageLookupByLibrary.simpleMessage(
      "الاسم الأول غير صالح",
    ),
    "fNameRequired": MessageLookupByLibrary.simpleMessage("الاسم الأول مطلوب"),
    "failedToResendEmail": MessageLookupByLibrary.simpleMessage(
      "فشل إعادة إرسال البريد الإلكتروني",
    ),
    "failedToResetProgress": MessageLookupByLibrary.simpleMessage(
      "فشل إعادة تعيين التقدم. يرجى المحاولة مرة أخرى.",
    ),
    "failedToSaveProgress": MessageLookupByLibrary.simpleMessage(
      "فشل حفظ التقدم. يرجى المحاولة مرة أخرى.",
    ),
    "failedToSendVerificationEmail": MessageLookupByLibrary.simpleMessage(
      "فشل إرسال بريد التحقق. يرجى المحاولة مرة أخرى.",
    ),
    "failedToSignOut": MessageLookupByLibrary.simpleMessage(
      "فشل تسجيل الخروج. يرجى المحاولة مرة أخرى.",
    ),
    "fajr": MessageLookupByLibrary.simpleMessage("الفجر"),
    "fatwaChatbot": MessageLookupByLibrary.simpleMessage("مسـاعـد الفتوى"),
    "fieldRequired": MessageLookupByLibrary.simpleMessage("الحقل مطلوب"),
    "findYourLocationAndNavigate": MessageLookupByLibrary.simpleMessage(
      "ابحث عن موقعك وتنقل إلى الأماكن المهمة",
    ),
    "forbiddenException": MessageLookupByLibrary.simpleMessage("خطأ في الإذن"),
    "forgotPassword": MessageLookupByLibrary.simpleMessage(
      "هل نسيت كلمة المرور؟",
    ),
    "formatException": MessageLookupByLibrary.simpleMessage("خطأ في التنسيق"),
    "general": MessageLookupByLibrary.simpleMessage("عام"),
    "getStartedNow": MessageLookupByLibrary.simpleMessage("ابدأ الآن"),
    "hajj": MessageLookupByLibrary.simpleMessage("حج"),
    "hajjAlIfradDescription": MessageLookupByLibrary.simpleMessage(
      "أحرم بنية الحج فقط، وتقول:\n\"لبيك اللهم حجاً\"\nأي يا الله، أستجيب لك لأداء الحج.\nلا يطلب منك ذبح هدي في هذا النوع من الحج.\nولكن إن رغبت في تقديم هدي تطوعي، يمكنك ذلك —\nفقط تأكد من ترتيبه مسبقاً من خلال قسيمة هدي أو خدمة رسمية معتمدة.",
    ),
    "hajjAlIfradTitle": MessageLookupByLibrary.simpleMessage("حج الإفراد"),
    "hajjAlQiranDescription": MessageLookupByLibrary.simpleMessage(
      "يؤدي هذا النوع من الحج من ينوي الحج والعمرة معاً بإحرام واحد، فيقول:\n\"لبيك اللهم حجاً وعمرة\"\nأي، يا الله، أستجيب لك لأداء الحج والعمرة!\nتظل محرماً حتى تكمل الحج والعمرة معاً.\nوتقوم بنفس أعمال حج الإفراد.\nلكن في هذا النوع يجب عليك ذبح الهدي.\nفلا تنس ترتيب ذلك مسبقاً من خلال قسيمة هدي أو خدمة رسمية معتمدة.",
    ),
    "hajjAlQiranTitle": MessageLookupByLibrary.simpleMessage("حج القران"),
    "hajjAlTamattuDescription": MessageLookupByLibrary.simpleMessage(
      "أحرم للعمرة فقط، وتقول:\n\"لبيك اللهم عمرة\"\nأي، يا الله، أستجيب لك لأداء العمرة!\nثم تؤدي العمرة كاملة — بالطواف، والسعي، وقص أو حلق الشعر — وتحلل من الإحرام.\nوعندما يأتي وقت الحج (في اليوم الثامن من ذي الحجة)، تحرم مرة أخرى من مكة للحج.\nيُعد هذا النوع أفضل أنواع الحج، ويتطلب ذبح هدي واجب.\nفلا تنس ترتيب ذلك مسبقاً من خلال قسيمة هدي أو خدمة رسمية معتمدة.\n\nوقت الإحرام لحج التمتع يقتصر على أشهر الحج:\nشوال، وذو القعدة، وأول عشرة أيام من ذي الحجة.",
    ),
    "hajjAlTamattuTitle": MessageLookupByLibrary.simpleMessage("حج التمتع"),
    "hajjDay10Description": MessageLookupByLibrary.simpleMessage(
      "في يوم النحر، تتوجه إلى منى لرمي جمرة العقبة، وذبح هديك، وتطوف طواف الإفاضة، وتتحلل من الإحرام (التحلل الأكبر). بعد ذلك تعود إلى منى للمبيت ليالي التشريق. هذا هو الترتيب الأفضل (السنة)، لكن يمكن أداء المناسك بترتيب مختلف عند الحاجة. لقول النبي ﷺ: «ما سئل يومئذ عن شيء قدم ولا أخر إلا قال: افعل ولا حرج».",
    ),
    "hajjDay11_13Description": MessageLookupByLibrary.simpleMessage(
      "أيام التشريق (11، 12، 13 ذو الحجة). يقضي الحجاج هذه الأيام في منى، ويرمون الجمرات الثلاث (الصغرى، الوسطى، الكبرى) كل يوم بعد الزوال. من تعجل غادر منى في اليوم الثاني عشر قبل الغروب، ومن تأخر بقي لليوم الثالث عشر.",
    ),
    "hajjDay8Description": MessageLookupByLibrary.simpleMessage(
      "يوم التروية (8 ذي الحجة): يُسن للحاج أن يُحرم بالحج (للمتمتع) ويتوجه إلى منى، ويصلي فيها الظهر والعصر والمغرب والعشاء والفجر، قصراً للصلاة الرباعية دون جمع.",
    ),
    "hajjDay9Description": MessageLookupByLibrary.simpleMessage(
      "يعد يوم عرفة من أعظم الأيام عند المسلمين. وقد ذكره الله تعالى في سورة المائدة: (اليوم أكملت لكم دينكم وأتممت عليكم نعمتي ورضيت لكم الإسلام ديناً). قال النبي ﷺ: (ما من يوم أكثر من أن يعتق الله فيه عبداً من النار من يوم عرفة، وإنه ليدنو ثم يباهي بهم الملائكة فيقول: ما أراد هؤلاء؟).",
    ),
    "hajjStepAlHady": MessageLookupByLibrary.simpleMessage("الهدي"),
    "hajjStepAlHadyDescription": MessageLookupByLibrary.simpleMessage(
      "الهدي: واجب على المتمتع والقارن، ومستحب للمفرد. ووقته من يوم النحر إلى آخر أيام التشريق.",
    ),
    "hajjStepAlHadySubStep1": MessageLookupByLibrary.simpleMessage(
      "شراء الهدي",
    ),
    "hajjStepAlHadySubStep2": MessageLookupByLibrary.simpleMessage(
      "ذبح الهدي وتوزيعه",
    ),
    "hajjStepArafat": MessageLookupByLibrary.simpleMessage("عرفات"),
    "hajjStepArafatDescription": MessageLookupByLibrary.simpleMessage(
      "الوقوف بعرفة: هو الحج كله، لقول النبي ﷺ \"الحج عرفة\". وقته من زوال الشمس يوم التاسع إلى طلوع فجر يوم النحر. والسنة الجمع بين الظهر والعصر تقديماً وقصراً.",
    ),
    "hajjStepArafatSubStep1": MessageLookupByLibrary.simpleMessage(
      "توجه إلى عرفة وصل الظهر والعصر جمع تقديم في وقت الظهر",
    ),
    "hajjStepArafatSubStep2": MessageLookupByLibrary.simpleMessage(
      "في هذا اليوم تلقى خطبة عرفة الرسمية من مسجد نمرة. فاحرص على الاستماع إليها إن أمكن. وقد توفر مجموعتك ترجمة فورية إن احتجت.",
    ),
    "hajjStepArafatSubStep3": MessageLookupByLibrary.simpleMessage(
      "ابق في عرفة حتى غروب الشمس",
    ),
    "hajjStepArafatSubStep4": MessageLookupByLibrary.simpleMessage(
      "خصص هذا اليوم للعبادة والدعاء. واجعل قلبك حاضراً مع الله، وأكثر من الدعاء لنفسك وأهلك ولجميع المسلمين.",
    ),
    "hajjStepArafatSubStep5": MessageLookupByLibrary.simpleMessage(
      "خير الدعاء دعاء يوم عرفة، وخير ما قلت أنا والنبيون من قبلي: لا إله إلا الله وحده لا شريك له، له الملك وله الحمد، يحيي ويميت، وهو على كل شيء قدير.",
    ),
    "hajjStepIhram": MessageLookupByLibrary.simpleMessage("الإحرام"),
    "hajjStepIhramDescription": MessageLookupByLibrary.simpleMessage(
      "الإهلال بالحج: ينوي الدخول في النسك قائلاً \"لبيك اللهم حجاً\". ويسن الاغتسال والتطيب (في البدن) قبل الإحرام.",
    ),
    "hajjStepJamarat": MessageLookupByLibrary.simpleMessage("رمي الجمرات"),
    "hajjStepJamaratDescription": MessageLookupByLibrary.simpleMessage(
      "يتم رمي الجمرات في أيام التشريق (11 و 12 و 13). ويتضمن رمي سبع حصيات على كل جمرة من الجمرات الثلاث، بدءاً من الصغرى، ثم الوسطى، ثم الكبرى (العقبة).",
    ),
    "hajjStepJamaratSubStep1": MessageLookupByLibrary.simpleMessage(
      "اجمع ٢١ حصاة صغيرة، بحجم حصى الخذف تقريباً (بحجم نواة التمر).\nيُستحب أن تجمع بعض الحصى الإضافية تحسباً لسقوط بعضها أو عدم إصابة الهدف — فالأفضل أن يكون لديك فائض بدل أن ينقص عليك العدد.\n**إذا كنت قد جمعت الحصى مسبقاً من مزدلفة، فلن تحتاج لجمع أي حصى جديدة هنا.**",
    ),
    "hajjStepJamaratSubStep2": MessageLookupByLibrary.simpleMessage(
      "**بعد زوال الشمس** (دخول وقت الظهر)، توجّه إلى الجمرات.\nواستمر في الذكر والتلبية حتى تبدأ الرمي.\nيجوز الرمي قبل الزوال في هذا اليوم فقط عند شدة الزحام أو الضرورة.\nويمكنك العمل بهذا القول **إذا كان هناك ازدحام شديد عند الجمرات.**",
    ),
    "hajjStepJamaratSubStep3": MessageLookupByLibrary.simpleMessage(
      "ابدأ بالجمرة الصغرى (الأقرب إلى مسجد الخيف).\nارم ٧ حصيات، واحدة تلو الأخرى، وكبر مع كل حصاة قائلاً \"الله أكبر\".\nتأكد من سقوط الحصاة داخل الحوض المخصص للرمي.\n\n<gold>بعد الانتهاء من الرمي، تقدم قليلاً، واستقبل القبلة، واجعل الجمرة عن يسارك، ثم ادعُ الله طويلاً.</gold>",
    ),
    "hajjStepJamaratSubStep4": MessageLookupByLibrary.simpleMessage(
      "ثم انتقل إلى الجمرة الوسطى.\nارم ٧ حصيات، واحدة تلو الأخرى، وكبر مع كل حصاة قائلاً \"الله أكبر\".\n\n<gold>بعد الانتهاء من الرمي، تنحَّ جانباً، واستقبل القبلة، واجعل الجمرة عن يمينك، وأطل الدعاء.</gold>",
    ),
    "hajjStepJamaratSubStep5": MessageLookupByLibrary.simpleMessage(
      "ثم انتقل إلى الجمرة الكبرى (جمرة العقبة).\nارم ٧ حصيات، واحدة تلو الأخرى، وكبر مع كل حصاة قائلاً \"الله أكبر\".\n**لا تقف للدعاء بعد الجمرة الثالثة، بل استمر في السير مع الحشود.**",
    ),
    "hajjStepJamaratSubStep6": MessageLookupByLibrary.simpleMessage(
      "كرر هذه العملية نفسها في كل يوم من أيام التشريق (اليوم ١١ و ١٢، وكذلك ١٣ لمن يتأخر).\n\n<red>لا تتعجل في أداء الرمي. الجهات المنظمة للحج غالباً تحدد أوقاتاً لمجموعات الحجاج لتجنب الازدحام والمحافظة على السلامة. اتبع الجدول الزمني لمجموعتك.</red>\n\n<red>لا ترم النعال أو الأغراض الثمينة غضباً — فالجمرة ليست الشيطان، وإتلاف ممتلكاتك لا فائدة منه.</red>\n\n**إذا رغبت في مغادرة منى مبكراً (في اليوم ١٢ من ذي الحجة)، فيجب أن تغادر قبل غروب الشمس.** وإن غربت الشمس وأنت ما زلت في منى، فيجب عليك البقاء ليلة إضافية والرمي في اليوم التالي.",
    ),
    "hajjStepMina": MessageLookupByLibrary.simpleMessage("منى"),
    "hajjStepMinaDescription": MessageLookupByLibrary.simpleMessage(
      "المبيت بمنى ليلة التاسع: سنة مؤكدة. يصلي فيها الصلوات الخمس قصراً بلا جمع.",
    ),
    "hajjStepMinaJamratAlAqabahDescription":
        MessageLookupByLibrary.simpleMessage(
          "رمي جمرة العقبة الكبرى بسبع حصيات.",
        ),
    "hajjStepMinaJamratAlAqabahSubStep1": MessageLookupByLibrary.simpleMessage(
      "التوجه إلى منى",
    ),
    "hajjStepMinaJamratAlAqabahSubStep2": MessageLookupByLibrary.simpleMessage(
      "رمي جمرة العقبة الكبرى",
    ),
    "hajjStepMinaJamratAlAqabahSubStep3": MessageLookupByLibrary.simpleMessage(
      "التكبير مع كل حصاة",
    ),
    "hajjStepMuzdalifah": MessageLookupByLibrary.simpleMessage("مزدلفة"),
    "hajjStepMuzdalifahDescription": MessageLookupByLibrary.simpleMessage(""),
    "hajjStepMuzdalifahSubStep1": MessageLookupByLibrary.simpleMessage(
      "بعد غروب الشمس، غادر عرفة وتوجه إلى مزدلفة. وعند وصولك، صل المغرب والعشاء جمع تأخير. فتصلي المغرب ثلاث ركعات كالمعتاد، ثم العشاء ركعتين. عن عبد الله بن عمر رضي الله عنهما قال: «جمع النبي ﷺ بين المغرب والعشاء في مزدلفة، لكل واحدة إقامة، ولم يصل بينهما ولا بعدهما شيئاً».",
    ),
    "hajjStepMuzdalifahSubStep2": MessageLookupByLibrary.simpleMessage(
      "يمكنك جمع حصى الجمار (الرمي في الأيام التالية من الحج). يستحب أن تكون الحصى صغيرة بحجم نواة التمر. ستحتاج إلى:\n• ٤٩ حصاة إذا كنت ستبقى في منى يومين فقط (العاشر والحادي عشر، وتغادر بعد الرمي في اليوم الثاني عشر).\n• ٧٠ حصاة إذا كنت ستبقى في منى ثلاثة أيام (رمي في الأيام العشرة، الحادي عشر، والثاني عشر).\nويستحب جمع بعض الحصى الإضافية احتياطاً في حال سقطت أو أخطأت الهدف.\nويمكنك أيضاً جمع الحصى لاحقاً من منى إذا رغبت.",
    ),
    "hajjStepMuzdalifahSubStep3": MessageLookupByLibrary.simpleMessage(
      "بت في مزدلفة بعد وصولك. ويمكنك الراحة أو الانشغال بالذكر والعبادة بهدوء. وقد نام النبي ﷺ في مزدلفة حتى قبيل الفجر (رواه مسلم). لذا احرص على الراحة الجيدة استعداداً ليوم مهم قادم.\n\nيجوز للحجاج مغادرة مزدلفة بعد منتصف الليل، كما أذن النبي ﷺ للنساء والضعفاء ومن يرافقهم بذلك. أما الرجال الذين لا يرافقون عائلاتهم، فالأفضل أن يبقوا في مزدلفة حتى صلاة الفجر، وينشغلوا بذكر الله والدعاء اقتداء بسنة النبي ﷺ.",
    ),
    "hajjStepStayingInMina": MessageLookupByLibrary.simpleMessage(
      "المبيت بمنى",
    ),
    "hajjStepStayingInMinaDescription": MessageLookupByLibrary.simpleMessage(
      "المبيت بمنى ليالي التشريق: واجب عند الجمهور. ورمي الجمرات الثلاث في أيام التشريق بعد الزوال.",
    ),
    "hajjStepStayingInMinaSubStep1": MessageLookupByLibrary.simpleMessage(
      "العودة إلى منى للمبيت",
    ),
    "hajjStepStayingInMinaSubStep2": MessageLookupByLibrary.simpleMessage(
      "رمي الجمرات في أيام التشريق",
    ),
    "hajjStepTahallul": MessageLookupByLibrary.simpleMessage("التحلل"),
    "hajjStepTahallulDescription": MessageLookupByLibrary.simpleMessage(
      "التحلل: التحلل الأول يحصل باثنين من ثلاثة (رمي جمرة العقبة، الحلق/التقصير، طواف الإفاضة). والتحلل الثاني يحصل بفعل الثلاثة كلها.",
    ),
    "hajjStepTahallulSubStep1": MessageLookupByLibrary.simpleMessage(
      "حلق الرأس (للرجال)",
    ),
    "hajjStepTahallulSubStep2": MessageLookupByLibrary.simpleMessage(
      "تقصير الشعر (للنساء والرجال)",
    ),
    "hajjStepTawafAlIfadah": MessageLookupByLibrary.simpleMessage(
      "طواف الإفاضة",
    ),
    "hajjStepTawafAlIfadahDescription": MessageLookupByLibrary.simpleMessage(
      "طواف الإفاضة: ركن لا يصح الحج بدونه. وقته يبدأ من منتصف ليلة النحر.",
    ),
    "hajjStepTawafAlIfadahSubStep1": MessageLookupByLibrary.simpleMessage(
      "التوجه إلى مكة",
    ),
    "hajjStepTawafAlIfadahSubStep2": MessageLookupByLibrary.simpleMessage(
      "طواف الإفاضة",
    ),
    "hajjStepTawafAlIfadahSubStep3": MessageLookupByLibrary.simpleMessage(
      "السعي بين الصفا والمروة",
    ),
    "hajjStepTawafAlQudum": MessageLookupByLibrary.simpleMessage("طواف القدوم"),
    "hajjStepTawafAlQudumDescription": MessageLookupByLibrary.simpleMessage(
      "طواف القدوم: هو تحية البيت للقادم إلى مكة. وهو سنة عند الجمهور. يطوف سبعة أشواط، ويرمل في الثلاثة الأولى، ويضطبع في جميعها (للرجال).",
    ),
    "hajjStepTawafAlWada": MessageLookupByLibrary.simpleMessage("طواف الوداع"),
    "hajjStepTawafAlWadaDescription": MessageLookupByLibrary.simpleMessage(
      "آخر أعمال الحج، وهو واجب على كل حاج إلا الحائض والنفساء.",
    ),
    "hajjStepTawafAlWadaSubStep1": MessageLookupByLibrary.simpleMessage(
      "أد طواف الوداع (٧ أشواط).",
    ),
    "hajjStepTawafAlWadaSubStep2": MessageLookupByLibrary.simpleMessage(
      "صل ركعتين خلف مقام إبراهيم.",
    ),
    "hajjStepTawafAlWadaSubStep3": MessageLookupByLibrary.simpleMessage(
      "اشرب من ماء زمزم.",
    ),
    "hajjStepTawafAlWadaSubStep4": MessageLookupByLibrary.simpleMessage(
      "وجه إلى الملتزم وادع دعاءك الأخير قبل المغادرة.",
    ),
    "hello": MessageLookupByLibrary.simpleMessage("مرحبا"),
    "hijjGuidance": MessageLookupByLibrary.simpleMessage("إرشادات الحج"),
    "historicSites": MessageLookupByLibrary.simpleMessage("المواقع التاريخية"),
    "hotels": MessageLookupByLibrary.simpleMessage("الفنادق"),
    "hour": MessageLookupByLibrary.simpleMessage("ساعة"),
    "hourShort": MessageLookupByLibrary.simpleMessage("س"),
    "hours": MessageLookupByLibrary.simpleMessage("ساعات"),
    "hoursShort": MessageLookupByLibrary.simpleMessage("س"),
    "httpException": MessageLookupByLibrary.simpleMessage(
      "خطأ في الاتصال بالخادم",
    ),
    "iconAndIconDataCannotBeNull": MessageLookupByLibrary.simpleMessage(
      "الأيقونة وبيانات الأيقونة لا يمكن أن تكون فارغة",
    ),
    "ihram": MessageLookupByLibrary.simpleMessage("الإحرام"),
    "invalidEmail": MessageLookupByLibrary.simpleMessage(
      "عنوان البريد الإلكتروني غير صالح.",
    ),
    "isha": MessageLookupByLibrary.simpleMessage("العشاء"),
    "kaaba": MessageLookupByLibrary.simpleMessage("الكعبة"),
    "lName": MessageLookupByLibrary.simpleMessage("الاسم الأخير"),
    "lNameInvalid": MessageLookupByLibrary.simpleMessage(
      "الاسم الأخير غير صالح",
    ),
    "lNameRequired": MessageLookupByLibrary.simpleMessage("الاسم الأخير مطلوب"),
    "loadingMap": MessageLookupByLibrary.simpleMessage("جاري تحميل الخريطة..."),
    "location": MessageLookupByLibrary.simpleMessage("الموقع"),
    "login": MessageLookupByLibrary.simpleMessage("تسجيل الدخول"),
    "logout": MessageLookupByLibrary.simpleMessage("تسجيل الخروج"),
    "maghrib": MessageLookupByLibrary.simpleMessage("المغرب"),
    "main": MessageLookupByLibrary.simpleMessage("الرئيسية"),
    "manageCompanions": MessageLookupByLibrary.simpleMessage("إدارة المرافق"),
    "map": MessageLookupByLibrary.simpleMessage("الخريطة"),
    "meccaSaudiArabia": MessageLookupByLibrary.simpleMessage(
      "مكة المكرمة، المملكة العربية السعودية",
    ),
    "medinaSaudiArabia": MessageLookupByLibrary.simpleMessage(
      "المدينة المنورة، المملكة العربية السعودية",
    ),
    "mensIhramGarments": MessageLookupByLibrary.simpleMessage(
      "ملابس الإحرام للرجال",
    ),
    "mensIhramGarmentsDescription": MessageLookupByLibrary.simpleMessage(
      "يحرم على الرجل المحرم **<red>لبس المخيط</red>** وهو كل ما فُصّل على قدر العضو، كالقميص والسراويل والجوارب. كما يحرم عليه **<red>تغطية الرأس</red>** بملاصق كالعمامة أو الطاقية. ويحرم عليه **<red>لبس الحذاء الذي يغطي الكعبين</red>**. والسنة أن يلبس إزاراً ورداءً أبيضين نظيفين، ونعلين.",
    ),
    "millionShort": MessageLookupByLibrary.simpleMessage("م"),
    "mina": MessageLookupByLibrary.simpleMessage("منى"),
    "minuteShort": MessageLookupByLibrary.simpleMessage("د"),
    "minutesShort": MessageLookupByLibrary.simpleMessage("د"),
    "month": MessageLookupByLibrary.simpleMessage("شهر"),
    "monthShort": MessageLookupByLibrary.simpleMessage("ش"),
    "months": MessageLookupByLibrary.simpleMessage("أشهر"),
    "monthsShort": MessageLookupByLibrary.simpleMessage("ش"),
    "mosques": MessageLookupByLibrary.simpleMessage("المساجد"),
    "museums": MessageLookupByLibrary.simpleMessage("المتاحف"),
    "mustBeAtLeast8CharactersLong": MessageLookupByLibrary.simpleMessage(
      "يجب أن تكون 8 أحرف على الأقل",
    ),
    "mustIncludeAtLeastOneDigit": MessageLookupByLibrary.simpleMessage(
      "يجب أن تحتوي على رقم واحد على الأقل (0–9)",
    ),
    "mustIncludeAtLeastOneLowercaseLetter":
        MessageLookupByLibrary.simpleMessage(
          "يجب أن تحتوي على حرف صغير واحد على الأقل (a–z)",
        ),
    "mustIncludeAtLeastOneSpecialCharacter":
        MessageLookupByLibrary.simpleMessage(
          "يجب أن تحتوي على رمز خاص واحد على الأقل (!@#\$%^&*()_+)",
        ),
    "mustIncludeAtLeastOneUppercaseLetter":
        MessageLookupByLibrary.simpleMessage(
          "يجب أن تحتوي على حرف كبير واحد على الأقل (A–Z)",
        ),
    "mustNotContainSpaces": MessageLookupByLibrary.simpleMessage(
      "يجب ألا تحتوي على مسافات",
    ),
    "muzdalifa": MessageLookupByLibrary.simpleMessage("مزدلفة"),
    "name": MessageLookupByLibrary.simpleMessage("الاسم"),
    "nameInvalid": MessageLookupByLibrary.simpleMessage("الاسم غير صالح"),
    "nameRequired": MessageLookupByLibrary.simpleMessage("الاسم مطلوب"),
    "newPassword": MessageLookupByLibrary.simpleMessage("كلمة مرور جديدة"),
    "newPasswordMustBeDifferent": MessageLookupByLibrary.simpleMessage(
      "يجب أن تكون كلمة المرور الجديدة مختلفة عن كلمة المرور الحالية",
    ),
    "ninthDhulHijjah": MessageLookupByLibrary.simpleMessage(
      "التاسع من ذي الحجة",
    ),
    "noNotYet": MessageLookupByLibrary.simpleMessage("لا، ليس بعد"),
    "none": MessageLookupByLibrary.simpleMessage("لا شيء"),
    "notFoundException": MessageLookupByLibrary.simpleMessage(
      "الصفحة غير موجودة",
    ),
    "openMap": MessageLookupByLibrary.simpleMessage("فتح الخريطة"),
    "operationNotAllowed": MessageLookupByLibrary.simpleMessage(
      "العملية غير مسموحة.",
    ),
    "pageNotFoundMsg": MessageLookupByLibrary.simpleMessage(
      "الصفحة غير موجودة",
    ),
    "password": MessageLookupByLibrary.simpleMessage("كلمة المرور"),
    "passwordChanged": MessageLookupByLibrary.simpleMessage(
      "تم تغيير كلمة المرور",
    ),
    "passwordChangedSuccessfully": MessageLookupByLibrary.simpleMessage(
      "تم تغيير كلمة المرور بنجاح",
    ),
    "passwordDoesNotMeetAllRequirements": MessageLookupByLibrary.simpleMessage(
      "كلمة المرور لا تلبي جميع المتطلبات",
    ),
    "passwordLength": MessageLookupByLibrary.simpleMessage(
      "كلمة المرور يجب أن تكون أطول من 8 أحرف",
    ),
    "passwordRequired": MessageLookupByLibrary.simpleMessage(
      "كلمة المرور مطلوبة",
    ),
    "passwordRequirements": MessageLookupByLibrary.simpleMessage(
      "متطلبات كلمة المرور",
    ),
    "pending": MessageLookupByLibrary.simpleMessage("قيد الانتظار"),
    "phoneLength": MessageLookupByLibrary.simpleMessage(
      "رقم الهاتف يجب أن يكون أطول من 10 أرقام",
    ),
    "phoneNumber": MessageLookupByLibrary.simpleMessage("رقم الهاتف"),
    "phoneNumberInvalid": MessageLookupByLibrary.simpleMessage(
      "رقم الهاتف غير صالح",
    ),
    "phoneNumberLength": MessageLookupByLibrary.simpleMessage(
      "يجب أن يكون رقم الهاتف أطول من 10 أحرف",
    ),
    "phoneNumberRequired": MessageLookupByLibrary.simpleMessage(
      "رقم الهاتف مطلوب",
    ),
    "pleaseCheckYourEmail": MessageLookupByLibrary.simpleMessage(
      "يرجى التحقق من بريدك الإلكتروني",
    ),
    "pleaseTypeSomethingYoullRemember": MessageLookupByLibrary.simpleMessage(
      "يرجى كتابة شيء تتذكره",
    ),
    "pleaseVerifyYourEmailFirst": MessageLookupByLibrary.simpleMessage(
      "يرجى التحقق من بريدك الإلكتروني أولاً",
    ),
    "profile": MessageLookupByLibrary.simpleMessage("الملف الشخصي"),
    "progress": MessageLookupByLibrary.simpleMessage("التقدم"),
    "progressDescription": m0,
    "progressResetSuccessfully": MessageLookupByLibrary.simpleMessage(
      "تم إعادة تعيين التقدم بنجاح",
    ),
    "prohibitionApplyingPerfume": MessageLookupByLibrary.simpleMessage(
      "استعمال الطيب",
    ),
    "prohibitionCoveringHead": MessageLookupByLibrary.simpleMessage(
      "تغطية الرأس (للرجال)",
    ),
    "prohibitionCuttingNails": MessageLookupByLibrary.simpleMessage(
      "تقليم الأظافر",
    ),
    "prohibitionHunting": MessageLookupByLibrary.simpleMessage("صيد البر"),
    "prohibitionMarriageContract": MessageLookupByLibrary.simpleMessage(
      "عقد النكاح",
    ),
    "prohibitionNiqabGloves": MessageLookupByLibrary.simpleMessage(
      "لبس النقاب والقفازين (للنساء)",
    ),
    "prohibitionSexualIntercourse": MessageLookupByLibrary.simpleMessage(
      "الجماع",
    ),
    "prohibitionShavingHair": MessageLookupByLibrary.simpleMessage(
      "حلق الشعر أو قصه",
    ),
    "prohibitionWearingStitchedClothing": MessageLookupByLibrary.simpleMessage(
      "لبس المخيط (للرجال)",
    ),
    "prohibitionsOfIhram": MessageLookupByLibrary.simpleMessage(
      "محظورات الإحرام",
    ),
    "prophetsMosque": MessageLookupByLibrary.simpleMessage("المسجد النبوي"),
    "rateUs": MessageLookupByLibrary.simpleMessage("قيمنا"),
    "register": MessageLookupByLibrary.simpleMessage("تسجيل حساب جديد"),
    "remaining": MessageLookupByLibrary.simpleMessage("المتبقي"),
    "rememberMe": MessageLookupByLibrary.simpleMessage("تذكرني"),
    "rememberPasswordQuestion": MessageLookupByLibrary.simpleMessage(
      "تذكر كلمة المرور؟",
    ),
    "resendCode": MessageLookupByLibrary.simpleMessage("إعادة إرسال الرمز"),
    "resendLink": MessageLookupByLibrary.simpleMessage("إعادة إرسال الرابط"),
    "reset": MessageLookupByLibrary.simpleMessage("إعادة تعيين"),
    "resetLinkSent": MessageLookupByLibrary.simpleMessage(
      "تم إرسال رابط إعادة التعيين",
    ),
    "resetLinkSentMessage": MessageLookupByLibrary.simpleMessage(
      "يرجى التحقق من بريدك الإلكتروني لإعادة تعيين كلمة المرور",
    ),
    "resetPassword": MessageLookupByLibrary.simpleMessage(
      "إعادة تعيين كلمة المرور",
    ),
    "resetProgress": MessageLookupByLibrary.simpleMessage("إعادة تعيين التقدم"),
    "resetProgressConfirmation": MessageLookupByLibrary.simpleMessage(
      "هل أنت متأكد من أنك تريد إعادة تعيين كل التقدم؟",
    ),
    "retry": MessageLookupByLibrary.simpleMessage("إعادة المحاولة"),
    "ritualGuidance": MessageLookupByLibrary.simpleMessage("توجيه للمناسك"),
    "ritualSites": MessageLookupByLibrary.simpleMessage("مواقع الطقوس"),
    "saee": MessageLookupByLibrary.simpleMessage("السعي"),
    "saeeSubDesc1": MessageLookupByLibrary.simpleMessage(
      "اصعد على الصفا، ثم اتجه نحو المروة. يسن للرجل **الهرولة** (الإسراع) بين العلمين الأخضرين.",
    ),
    "saeeSubDesc2": MessageLookupByLibrary.simpleMessage(
      "عندما تصل إلى المروة، تكتمل دورة واحدة.",
    ),
    "saeeSubDesc3": MessageLookupByLibrary.simpleMessage(
      "ارجع إلى الصفا للدورة الثانية، مستمراً بهذه الطريقة حتى إتمام سبع دورات، تنتهي عند المروة.",
    ),
    "saeeSubDesc4": MessageLookupByLibrary.simpleMessage(
      "يجوز لمن لا يستطيع المشي، أو من يشعر بالإرهاق أو المرض أو الضعف، أن يؤدي السعي وهو محمول أو منقول. ومع ذلك، يجب أن يبقى مستيقظاً ومنتبهاً، لأن السعي عبادة، ويجب أن يستغل وقته بالدعاء والتوجه إلى الله بتواضع.",
    ),
    "search": MessageLookupByLibrary.simpleMessage("بحث"),
    "secondShort": MessageLookupByLibrary.simpleMessage("ث"),
    "secondsShort": MessageLookupByLibrary.simpleMessage("ث"),
    "sendCode": MessageLookupByLibrary.simpleMessage("إرسال الرمز"),
    "sendResetLink": MessageLookupByLibrary.simpleMessage(
      "إرسال رابط إعادة التعيين",
    ),
    "services": MessageLookupByLibrary.simpleMessage("الخدمات"),
    "settings": MessageLookupByLibrary.simpleMessage("الإعدادات"),
    "shareApp": MessageLookupByLibrary.simpleMessage("شارك التطبيق"),
    "showLess": MessageLookupByLibrary.simpleMessage("عرض أقل"),
    "showMore": MessageLookupByLibrary.simpleMessage("عرض المزيد"),
    "signIn": MessageLookupByLibrary.simpleMessage("تسجيل الدخول"),
    "signInFailed": MessageLookupByLibrary.simpleMessage("فشل تسجيل الدخول"),
    "signInToYourAccount": MessageLookupByLibrary.simpleMessage(
      "تسجيل الدخول إلى حسابك",
    ),
    "signUp": MessageLookupByLibrary.simpleMessage("تسجيل حساب جديد"),
    "signUpFailed": MessageLookupByLibrary.simpleMessage("فشل التسجيل"),
    "socketException": MessageLookupByLibrary.simpleMessage(
      "خطأ في الاتصال بالشبكة",
    ),
    "someResourcesAreDownException": MessageLookupByLibrary.simpleMessage(
      "بعض الموارد غير متوفرة",
    ),
    "startYourPathTowardHajjAndUmrahWithPersonalizedGuidance":
        MessageLookupByLibrary.simpleMessage(
          "ابدأ رحلتك نحو الحج والعمرة بالتوجيه الشخصي",
        ),
    "step": MessageLookupByLibrary.simpleMessage("خطوة"),
    "step1Description": MessageLookupByLibrary.simpleMessage(
      "يدخل المسلم في حالة الإحرام من المكان المحدد له شرعاً، ويمتنع عن المحظورات التي يحرم عليه فعلها أثناء الإحرام.",
    ),
    "step1GuidanceDescription": MessageLookupByLibrary.simpleMessage(
      "يدخل المسلم في حالة الإحرام من المكان المحدد له شرعاً، ويمتنع عن المحظورات التي يحرم عليه فعلها أثناء الإحرام.",
    ),
    "step2Description": MessageLookupByLibrary.simpleMessage(
      "عبادة يقوم بها المسلم بالطواف حول الكعبة **سبع مرات**، متعبداً ومتقرباً إلى الله.",
    ),
    "step2GuidanceDescription": MessageLookupByLibrary.simpleMessage(
      "الطواف هو أول عبادة يؤديها الحاج في حالة الإحرام. إنه حركة دائرية حول الكعبة، تُؤدى عكس اتجاه عقارب الساعة، بدءاً من الحجر الأسود (حجر الأسود).",
    ),
    "step3Description": MessageLookupByLibrary.simpleMessage(
      "في هذه الشعيرة، يتعبد الحاج لله بالمشي بين الصفا والمروة سبع مرات، متبعاً سنة النبي الكريم ﷺ. يجوز أداء السعي بدون وضوء ولا إثم في ذلك. وإن كان الأفضل أن يكون على طهارة إن أمكن.",
    ),
    "step4Description": MessageLookupByLibrary.simpleMessage(
      "التحلل من الإحرام هو شعيرة واجبة لإتمام العمرة. يتم أداؤها بعد الانتهاء من السعي بين الصفا والمروة بقص جزء من الشعر أو حلقه. وبهذا يخرج المعتمر من حالة الإحرام ويحل له ما كان محظوراً عليه.\n\nبالنسبة للرجال، الحلق أفضل وأعظم أجراً من التقصير، لحديث النبي ﷺ: <gold>\"اللهم اغفر للمحلقين\"</gold> قالوا: <gold>\"وللمقصرين؟\"</gold> قال: <gold>\"اللهم اغفر للمحلقين\"</gold> قالوا: <gold>\"وللمقصرين؟\"</gold> قال: <gold>\"اللهم اغفر للمحلقين\"</gold> قالوا: <gold>\"وللمقصرين؟\"</gold> قال: <gold>\"وللمقصرين\"</gold>.",
    ),
    "stepCompletedConfirmation": MessageLookupByLibrary.simpleMessage(
      "تأكيد إكمال الخطوة",
    ),
    "stepCompletedConfirmationMessage": m1,
    "stepMarkedAsCompleted": MessageLookupByLibrary.simpleMessage(
      "تم تحديد الخطوة كمكتملة",
    ),
    "steps": MessageLookupByLibrary.simpleMessage("خطوات"),
    "success": MessageLookupByLibrary.simpleMessage("نجاح"),
    "sunrise": MessageLookupByLibrary.simpleMessage("الشروق"),
    "tahallul": MessageLookupByLibrary.simpleMessage("التحلل"),
    "tawaf": MessageLookupByLibrary.simpleMessage("الطواف"),
    "tawafSubDesc1": MessageLookupByLibrary.simpleMessage(
      " ابدأ الطواف مع الكعبة على يسارك\n ابدأ من الحجر الأسود، مواجهاً له، وقل \"بسم الله، الله أكبر\" عند بدء دورتك الأولى.",
    ),
    "tawafSubDesc2": MessageLookupByLibrary.simpleMessage(
      "عندما تصل إلى الركن اليماني، إذا استطعت لمسه بيدك اليمنى، افعل ذلك وقل: \"بسم الله، الله أكبر.\" <red>لا تقبل أو تشير إلى الركن اليماني، فهذا ليس من السنة.</red>",
    ),
    "tawafSubDesc3": MessageLookupByLibrary.simpleMessage(
      "عندما تصل إلى الحجر الأسود، المسه وقبله إن أمكن. إذا لم يكن ذلك ممكناً، أشر إليه بيدك مرة واحدة وقل \"الله أكبر.\"",
    ),
    "tawafSubDesc4": MessageLookupByLibrary.simpleMessage(
      "انشغل بالدعاء والذكر، لا يوجد دعاء محدد مطلوب لكل دورة.",
    ),
    "tawafSubDesc5": MessageLookupByLibrary.simpleMessage(
      "يسن للرجل **الرمل** (الإسراع في المشي مع تقارب الخطى) في الأشواط الثلاثة الأولى من طواف القدوم.",
    ),
    "tawafSubDesc6": MessageLookupByLibrary.simpleMessage(
      "يسن للرجل **الاضطباع** (كشف الكتف الأيمن) في جميع أشواط طواف القدوم.",
    ),
    "tawafSubDesc7": MessageLookupByLibrary.simpleMessage(
      "<gold>كان النبي ﷺ يفعل:</gold> يقرأ الدعاء:\n\"ربنا آتنا في الدنيا حسنة، وفي الآخرة حسنة، وقنا عذاب النار.\" بين الركن اليماني والحجر الأسود",
    ),
    "technicalSupport": MessageLookupByLibrary.simpleMessage("الدعم الفني"),
    "tenthDhulHijjah": MessageLookupByLibrary.simpleMessage(
      "العاشر من ذي الحجة",
    ),
    "tenthToTwelfthDhulHijjah": MessageLookupByLibrary.simpleMessage(
      "10 - 12 ذو الحجة",
    ),
    "thourCave": MessageLookupByLibrary.simpleMessage("غار ثور"),
    "thousandShort": MessageLookupByLibrary.simpleMessage("ألف"),
    "timeAgoDays": m2,
    "timeAgoHours": m3,
    "timeAgoMinutes": m4,
    "timeAgoMonths": m5,
    "timeAgoSeconds": m6,
    "timeAgoShort": m7,
    "timeAgoYears": m8,
    "timeOutException": MessageLookupByLibrary.simpleMessage("خطأ في الوقت"),
    "tooManyRequests": MessageLookupByLibrary.simpleMessage(
      "طلبات كثيرة جداً. يرجى المحاولة مرة أخرى لاحقاً.",
    ),
    "tooManyRequestsException": MessageLookupByLibrary.simpleMessage(
      "طلبات العديد",
    ),
    "typeYourMessage": MessageLookupByLibrary.simpleMessage("اكتب رسالتك..."),
    "umrah": MessageLookupByLibrary.simpleMessage("العمرة"),
    "umrahGuidance": MessageLookupByLibrary.simpleMessage("إرشادات العمرة"),
    "unAuthorized": MessageLookupByLibrary.simpleMessage("غير مصرح لك"),
    "underMaintenanceException": MessageLookupByLibrary.simpleMessage(
      "تحت الصيانة",
    ),
    "unexpectedErrorOccurred": MessageLookupByLibrary.simpleMessage(
      "حدث خطأ غير متوقع. يرجى المحاولة مرة أخرى.",
    ),
    "unit_day": MessageLookupByLibrary.simpleMessage("يوم"),
    "unit_hour": MessageLookupByLibrary.simpleMessage("ساعة"),
    "unit_hourShort": MessageLookupByLibrary.simpleMessage("س"),
    "unit_minute": MessageLookupByLibrary.simpleMessage("دقيقة"),
    "unit_minuteShort": MessageLookupByLibrary.simpleMessage("د"),
    "unit_month": MessageLookupByLibrary.simpleMessage("شهر"),
    "unit_monthShort": MessageLookupByLibrary.simpleMessage("ش"),
    "unit_second": MessageLookupByLibrary.simpleMessage("ثانية"),
    "unit_secondShort": MessageLookupByLibrary.simpleMessage("ث"),
    "unit_year": MessageLookupByLibrary.simpleMessage("سنة"),
    "unit_yearShort": MessageLookupByLibrary.simpleMessage("س"),
    "uploading": MessageLookupByLibrary.simpleMessage("يتم الرفع"),
    "userDisabled": MessageLookupByLibrary.simpleMessage(
      "تم تعطيل حساب المستخدم هذا.",
    ),
    "userNotFound": MessageLookupByLibrary.simpleMessage(
      "لم يتم العثور على مستخدم لهذا البريد الإلكتروني.",
    ),
    "verify": MessageLookupByLibrary.simpleMessage("تحقق"),
    "wadiJalil": MessageLookupByLibrary.simpleMessage("وادي جليل"),
    "waitingForVerification": MessageLookupByLibrary.simpleMessage(
      "في انتظار التحقق من البريد الإلكتروني...",
    ),
    "weakPassword": MessageLookupByLibrary.simpleMessage(
      "كلمة المرور المقدمة ضعيفة جداً.",
    ),
    "welcomeToLabbaik": MessageLookupByLibrary.simpleMessage(
      "مرحبا بك في Labbaik",
    ),
    "welcomeToLabbaikAssistant": MessageLookupByLibrary.simpleMessage(
      "مرحباً بك في مساعد لبيك",
    ),
    "weveSentACodeTo": m9,
    "womensIhramGarments": MessageLookupByLibrary.simpleMessage(
      "ملابس الإحرام للنساء",
    ),
    "womensIhramGarmentsDescription": MessageLookupByLibrary.simpleMessage(
      "تلبس المرأة ما شاءت من الثياب المباحة، الساترة، غير المتبرجة بزينة، ولا تتقيد بلون معين. ولكن يحرم عليها في الإحرام **<red>لبس النقاب والقفازين</red>**، لقول النبي ﷺ: \"لا تنتقب المرأة ولا تلبس القفازين\". وتغطي وجهها عند مرور الرجال الأجانب.",
    ),
    "wrongPassword": MessageLookupByLibrary.simpleMessage(
      "كلمة المرور المقدمة خاطئة.",
    ),
    "year": MessageLookupByLibrary.simpleMessage("سنة"),
    "yearShort": MessageLookupByLibrary.simpleMessage("ع"),
    "years": MessageLookupByLibrary.simpleMessage("سنوات"),
    "yearsShort": MessageLookupByLibrary.simpleMessage("ع"),
    "yesCompleted": MessageLookupByLibrary.simpleMessage("نعم، أكملتها"),
    "yourHajjJourney": MessageLookupByLibrary.simpleMessage("رحلة حجك"),
    "yourLabbaikJourneyAwaitsLogInToReconnectWithYourGuidance":
        MessageLookupByLibrary.simpleMessage(
          "رحلتك المبكرة في لاببايك تنتظرك، تسجيل الدخول لإعادة الاتصال بالتوجيه الشخصي",
        ),
  };
}
