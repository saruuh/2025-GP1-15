// GENERATED CODE - DO NOT MODIFY BY HAND
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'intl/messages_all.dart';

// **************************************************************************
// Generator: Flutter Intl IDE plugin
// Made by Localizely
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, lines_longer_than_80_chars
// ignore_for_file: join_return_with_assignment, prefer_final_in_for_each
// ignore_for_file: avoid_redundant_argument_values, avoid_escaping_inner_quotes

class S {
  S();

  static S? _current;

  static S get current {
    assert(
      _current != null,
      'No instance of S was loaded. Try to initialize the S delegate before accessing S.current.',
    );
    return _current!;
  }

  static const AppLocalizationDelegate delegate = AppLocalizationDelegate();

  static Future<S> load(Locale locale) {
    final name = (locale.countryCode?.isEmpty ?? false)
        ? locale.languageCode
        : locale.toString();
    final localeName = Intl.canonicalizedLocale(name);
    return initializeMessages(localeName).then((_) {
      Intl.defaultLocale = localeName;
      final instance = S();
      S._current = instance;

      return instance;
    });
  }

  static S of(BuildContext context) {
    final instance = S.maybeOf(context);
    assert(
      instance != null,
      'No instance of S present in the widget tree. Did you add S.delegate in localizationsDelegates?',
    );
    return instance!;
  }

  static S? maybeOf(BuildContext context) {
    return Localizations.of<S>(context, S);
  }

  /// `Hello`
  String get hello {
    return Intl.message(
      'Hello',
      name: 'hello',
      desc: 'A greeting to the user',
      args: [],
    );
  }

  /// `Server connection error`
  String get httpException {
    return Intl.message(
      'Server connection error',
      name: 'httpException',
      desc: 'An error occurred while connecting to the server',
      args: [],
    );
  }

  /// `Cache error`
  String get cacheException {
    return Intl.message(
      'Cache error',
      name: 'cacheException',
      desc: 'An error occurred while caching',
      args: [],
    );
  }

  /// `Format error`
  String get formatException {
    return Intl.message(
      'Format error',
      name: 'formatException',
      desc: 'An error occurred while formatting',
      args: [],
    );
  }

  /// `Operation cancelled`
  String get cancelException {
    return Intl.message(
      'Operation cancelled',
      name: 'cancelException',
      desc: 'The operation was cancelled',
      args: [],
    );
  }

  /// `Socket connection error`
  String get socketException {
    return Intl.message(
      'Socket connection error',
      name: 'socketException',
      desc: 'An error occurred while connecting to the socket',
      args: [],
    );
  }

  /// `Data not completed`
  String get dataNotCompleted {
    return Intl.message(
      'Data not completed',
      name: 'dataNotCompleted',
      desc: 'The data is not complete',
      args: [],
    );
  }

  /// `Error`
  String get error {
    return Intl.message(
      'Error',
      name: 'error',
      desc: 'An error occurred',
      args: [],
    );
  }

  /// `Success`
  String get success {
    return Intl.message(
      'Success',
      name: 'success',
      desc: 'The operation was successful',
      args: [],
    );
  }

  /// `Bad request error`
  String get badRequestException {
    return Intl.message(
      'Bad request error',
      name: 'badRequestException',
      desc: 'An error occurred while making a request',
      args: [],
    );
  }

  /// `Unauthorized`
  String get unAuthorized {
    return Intl.message(
      'Unauthorized',
      name: 'unAuthorized',
      desc: 'The user is not authorized to access this resource',
      args: [],
    );
  }

  /// `Under maintenance`
  String get underMaintenanceException {
    return Intl.message(
      'Under maintenance',
      name: 'underMaintenanceException',
      desc: 'The system is under maintenance',
      args: [],
    );
  }

  /// `Too many requests`
  String get tooManyRequestsException {
    return Intl.message(
      'Too many requests',
      name: 'tooManyRequestsException',
      desc: 'The user has made too many requests',
      args: [],
    );
  }

  /// `Downloaded successfully`
  String get downloadedSuccessfully {
    return Intl.message(
      'Downloaded successfully',
      name: 'downloadedSuccessfully',
      desc: 'The file was downloaded successfully',
      args: [],
    );
  }

  /// `Uploading`
  String get uploading {
    return Intl.message(
      'Uploading',
      name: 'uploading',
      desc: 'The file is being uploaded',
      args: [],
    );
  }

  /// `Album`
  String get album {
    return Intl.message(
      'Album',
      name: 'album',
      desc: 'The album name',
      args: [],
    );
  }

  /// `All`
  String get all {
    return Intl.message('All', name: 'all', desc: 'All', args: []);
  }

  /// `Timeout exception`
  String get timeOutException {
    return Intl.message(
      'Timeout exception',
      name: 'timeOutException',
      desc: 'An error occurred while timing out',
      args: [],
    );
  }

  /// `Forbidden exception`
  String get forbiddenException {
    return Intl.message(
      'Forbidden exception',
      name: 'forbiddenException',
      desc: 'An error occurred while forbidden',
      args: [],
    );
  }

  /// `Not found exception`
  String get notFoundException {
    return Intl.message(
      'Not found exception',
      name: 'notFoundException',
      desc: 'The page was not found',
      args: [],
    );
  }

  /// `Some resources are down exception`
  String get someResourcesAreDownException {
    return Intl.message(
      'Some resources are down exception',
      name: 'someResourcesAreDownException',
      desc: 'Some resources are down',
      args: [],
    );
  }

  /// `Email required`
  String get emailRequired {
    return Intl.message(
      'Email required',
      name: 'emailRequired',
      desc: 'The email is required',
      args: [],
    );
  }

  /// `Email invalid`
  String get emailInvalid {
    return Intl.message(
      'Email invalid',
      name: 'emailInvalid',
      desc: 'The email is invalid',
      args: [],
    );
  }

  /// `Password required`
  String get passwordRequired {
    return Intl.message(
      'Password required',
      name: 'passwordRequired',
      desc: 'The password is required',
      args: [],
    );
  }

  /// `Password length must be longer than 8 characters`
  String get passwordLength {
    return Intl.message(
      'Password length must be longer than 8 characters',
      name: 'passwordLength',
      desc: 'The password must be longer than 8 characters',
      args: [],
    );
  }

  /// `Confirm password does not match`
  String get confirmPasswordNotMatch {
    return Intl.message(
      'Confirm password does not match',
      name: 'confirmPasswordNotMatch',
      desc: 'The password does not match',
      args: [],
    );
  }

  /// `Phone number required`
  String get phoneNumberRequired {
    return Intl.message(
      'Phone number required',
      name: 'phoneNumberRequired',
      desc: 'The phone number is required',
      args: [],
    );
  }

  /// `Phone number invalid`
  String get phoneNumberInvalid {
    return Intl.message(
      'Phone number invalid',
      name: 'phoneNumberInvalid',
      desc: 'The phone number is invalid',
      args: [],
    );
  }

  /// `Name required`
  String get nameRequired {
    return Intl.message(
      'Name required',
      name: 'nameRequired',
      desc: 'The name is required',
      args: [],
    );
  }

  /// `Name invalid`
  String get nameInvalid {
    return Intl.message(
      'Name invalid',
      name: 'nameInvalid',
      desc: 'The name is invalid',
      args: [],
    );
  }

  /// `Do not show this message again`
  String get doNotShowAgain {
    return Intl.message(
      'Do not show this message again',
      name: 'doNotShowAgain',
      desc: 'Do not show this message again checkbox text',
      args: [],
    );
  }

  /// `First name required`
  String get fNameRequired {
    return Intl.message(
      'First name required',
      name: 'fNameRequired',
      desc: 'The first name is required',
      args: [],
    );
  }

  /// `First name invalid`
  String get fNameInvalid {
    return Intl.message(
      'First name invalid',
      name: 'fNameInvalid',
      desc: 'The first name is invalid',
      args: [],
    );
  }

  /// `Last name required`
  String get lNameRequired {
    return Intl.message(
      'Last name required',
      name: 'lNameRequired',
      desc: 'The last name is required',
      args: [],
    );
  }

  /// `Last name invalid`
  String get lNameInvalid {
    return Intl.message(
      'Last name invalid',
      name: 'lNameInvalid',
      desc: 'The last name is invalid',
      args: [],
    );
  }

  /// `Address required`
  String get addressRequired {
    return Intl.message(
      'Address required',
      name: 'addressRequired',
      desc: 'The address is required',
      args: [],
    );
  }

  /// `Address invalid`
  String get addressInvalid {
    return Intl.message(
      'Address invalid',
      name: 'addressInvalid',
      desc: 'The address is invalid',
      args: [],
    );
  }

  /// `Field required`
  String get fieldRequired {
    return Intl.message(
      'Field required',
      name: 'fieldRequired',
      desc: 'The field is required',
      args: [],
    );
  }

  /// `Phone number must be longer than 10 characters`
  String get phoneLength {
    return Intl.message(
      'Phone number must be longer than 10 characters',
      name: 'phoneLength',
      desc: 'The phone number must be longer than 10 characters',
      args: [],
    );
  }

  /// `Address must be longer than 3 characters`
  String get addressLength {
    return Intl.message(
      'Address must be longer than 3 characters',
      name: 'addressLength',
      desc: 'The address must be longer than 3 characters',
      args: [],
    );
  }

  /// `Phone number invalid`
  String get phoneInvalid {
    return Intl.message(
      'Phone number invalid',
      name: 'phoneInvalid',
      desc: 'The phone number is invalid',
      args: [],
    );
  }

  /// `Field invalid`
  String get fieldInvalid {
    return Intl.message(
      'Field invalid',
      name: 'fieldInvalid',
      desc: 'The field is invalid',
      args: [],
    );
  }

  /// `y`
  String get yearShort {
    return Intl.message('y', name: 'yearShort', desc: '', args: []);
  }

  /// `y`
  String get yearsShort {
    return Intl.message('y', name: 'yearsShort', desc: '', args: []);
  }

  /// `m`
  String get monthShort {
    return Intl.message('m', name: 'monthShort', desc: '', args: []);
  }

  /// `m`
  String get monthsShort {
    return Intl.message('m', name: 'monthsShort', desc: '', args: []);
  }

  /// `d`
  String get dayShort {
    return Intl.message('d', name: 'dayShort', desc: '', args: []);
  }

  /// `d`
  String get daysShort {
    return Intl.message('d', name: 'daysShort', desc: '', args: []);
  }

  /// `h`
  String get hourShort {
    return Intl.message('h', name: 'hourShort', desc: '', args: []);
  }

  /// `h`
  String get hoursShort {
    return Intl.message('h', name: 'hoursShort', desc: '', args: []);
  }

  /// `m`
  String get minuteShort {
    return Intl.message('m', name: 'minuteShort', desc: '', args: []);
  }

  /// `m`
  String get minutesShort {
    return Intl.message('m', name: 'minutesShort', desc: '', args: []);
  }

  /// `s`
  String get secondShort {
    return Intl.message('s', name: 'secondShort', desc: '', args: []);
  }

  /// `s`
  String get secondsShort {
    return Intl.message('s', name: 'secondsShort', desc: '', args: []);
  }

  /// `Delete Comment`
  String get deleteComment {
    return Intl.message(
      'Delete Comment',
      name: 'deleteComment',
      desc: '',
      args: [],
    );
  }

  /// `Are you sure you want to delete this comment?`
  String get deleteCommentMsg {
    return Intl.message(
      'Are you sure you want to delete this comment?',
      name: 'deleteCommentMsg',
      desc: '',
      args: [],
    );
  }

  /// `{value, plural, =0{now} =1{1 day ago} other{{value} days ago}}`
  String timeAgoDays(int value) {
    return Intl.plural(
      value,
      zero: 'now',
      one: '1 day ago',
      other: '$value days ago',
      name: 'timeAgoDays',
      desc: 'Time ago in days',
      args: [value],
    );
  }

  /// `{value, plural, =0{now} =1{1 month ago} other{{value} months ago}}`
  String timeAgoMonths(int value) {
    return Intl.plural(
      value,
      zero: 'now',
      one: '1 month ago',
      other: '$value months ago',
      name: 'timeAgoMonths',
      desc: 'Time ago in months',
      args: [value],
    );
  }

  /// `{value, plural, =0{now} =1{1 year ago} other{{value} years ago}}`
  String timeAgoYears(int value) {
    return Intl.plural(
      value,
      zero: 'now',
      one: '1 year ago',
      other: '$value years ago',
      name: 'timeAgoYears',
      desc: 'Time ago in years',
      args: [value],
    );
  }

  /// `{value, plural, =0{now} =1{1 hour ago} other{{value} hours ago}}`
  String timeAgoHours(int value) {
    return Intl.plural(
      value,
      zero: 'now',
      one: '1 hour ago',
      other: '$value hours ago',
      name: 'timeAgoHours',
      desc: 'Time ago in hours',
      args: [value],
    );
  }

  /// `{value, plural, =0{now} =1{1 minute ago} other{{value} minutes ago}}`
  String timeAgoMinutes(int value) {
    return Intl.plural(
      value,
      zero: 'now',
      one: '1 minute ago',
      other: '$value minutes ago',
      name: 'timeAgoMinutes',
      desc: 'Time ago in minutes',
      args: [value],
    );
  }

  /// `{value, plural, =0{now} =1{1 second ago} other{{value} seconds ago}}`
  String timeAgoSeconds(int value) {
    return Intl.plural(
      value,
      zero: 'now',
      one: '1 second ago',
      other: '$value seconds ago',
      name: 'timeAgoSeconds',
      desc: 'Time ago in seconds',
      args: [value],
    );
  }

  /// `{value}{unitShort}`
  String timeAgoShort(int value, String unitShort) {
    return Intl.message(
      '$value$unitShort',
      name: 'timeAgoShort',
      desc: 'Short time ago format',
      args: [value, unitShort],
    );
  }

  /// `year`
  String get unit_year {
    return Intl.message('year', name: 'unit_year', desc: '', args: []);
  }

  /// `month`
  String get unit_month {
    return Intl.message('month', name: 'unit_month', desc: '', args: []);
  }

  /// `mo`
  String get unit_monthShort {
    return Intl.message('mo', name: 'unit_monthShort', desc: '', args: []);
  }

  /// `day`
  String get unit_day {
    return Intl.message('day', name: 'unit_day', desc: '', args: []);
  }

  /// `hour`
  String get unit_hour {
    return Intl.message('hour', name: 'unit_hour', desc: '', args: []);
  }

  /// `minute`
  String get unit_minute {
    return Intl.message('minute', name: 'unit_minute', desc: '', args: []);
  }

  /// `second`
  String get unit_second {
    return Intl.message('second', name: 'unit_second', desc: '', args: []);
  }

  /// `y`
  String get unit_yearShort {
    return Intl.message('y', name: 'unit_yearShort', desc: '', args: []);
  }

  /// `d`
  String get unit_dayShort {
    return Intl.message('d', name: 'unit_dayShort', desc: '', args: []);
  }

  /// `h`
  String get unit_hourShort {
    return Intl.message('h', name: 'unit_hourShort', desc: '', args: []);
  }

  /// `m`
  String get unit_minuteShort {
    return Intl.message('m', name: 'unit_minuteShort', desc: '', args: []);
  }

  /// `s`
  String get unit_secondShort {
    return Intl.message('s', name: 'unit_secondShort', desc: '', args: []);
  }

  /// `{value, plural, =0{Just now} =1{1 {unit} ago} other{{value} {unit}s ago}}`
  String timeAgo(num value, Object unit) {
    return Intl.plural(
      value,
      zero: 'Just now',
      one: '1 $unit ago',
      other: '$value ${unit}s ago',
      name: 'timeAgo',
      desc: '',
      args: [value, unit],
    );
  }

  /// `ago`
  String get ago {
    return Intl.message('ago', name: 'ago', desc: 'The time ago', args: []);
  }

  /// `M`
  String get millionShort {
    return Intl.message(
      'M',
      name: 'millionShort',
      desc: 'The million short',
      args: [],
    );
  }

  /// `K`
  String get thousandShort {
    return Intl.message(
      'K',
      name: 'thousandShort',
      desc: 'The thousand short',
      args: [],
    );
  }

  /// `year`
  String get year {
    return Intl.message('year', name: 'year', desc: 'The year', args: []);
  }

  /// `years`
  String get years {
    return Intl.message('years', name: 'years', desc: 'The years', args: []);
  }

  /// `month`
  String get month {
    return Intl.message('month', name: 'month', desc: 'The month', args: []);
  }

  /// `months`
  String get months {
    return Intl.message('months', name: 'months', desc: 'The months', args: []);
  }

  /// `day`
  String get day {
    return Intl.message('day', name: 'day', desc: 'The day', args: []);
  }

  /// `days`
  String get days {
    return Intl.message('days', name: 'days', desc: 'The days', args: []);
  }

  /// `hour`
  String get hour {
    return Intl.message('hour', name: 'hour', desc: 'The hour', args: []);
  }

  /// `hours`
  String get hours {
    return Intl.message('hours', name: 'hours', desc: 'The hours', args: []);
  }

  /// `minute`
  String get minute {
    return Intl.message('minute', name: 'minute', desc: 'The minute', args: []);
  }

  /// `minutes`
  String get minutes {
    return Intl.message(
      'minutes',
      name: 'minutes',
      desc: 'The minutes',
      args: [],
    );
  }

  /// `second`
  String get second {
    return Intl.message('second', name: 'second', desc: 'The second', args: []);
  }

  /// `seconds`
  String get seconds {
    return Intl.message(
      'seconds',
      name: 'seconds',
      desc: 'The seconds',
      args: [],
    );
  }

  /// `Page not found`
  String get pageNotFoundMsg {
    return Intl.message(
      'Page not found',
      name: 'pageNotFoundMsg',
      desc: 'The page not found message',
      args: [],
    );
  }

  /// `Welcome to Labbaik`
  String get welcomeToLabbaik {
    return Intl.message(
      'Welcome to Labbaik',
      name: 'welcomeToLabbaik',
      desc: 'The welcome to labbaik message',
      args: [],
    );
  }

  /// `Sign in to your account`
  String get signInToYourAccount {
    return Intl.message(
      'Sign in to your account',
      name: 'signInToYourAccount',
      desc: 'The sign in to your account message',
      args: [],
    );
  }

  /// `Start your path toward Hajj and Umrah with personalized guidance`
  String get startYourPathTowardHajjAndUmrahWithPersonalizedGuidance {
    return Intl.message(
      'Start your path toward Hajj and Umrah with personalized guidance',
      name: 'startYourPathTowardHajjAndUmrahWithPersonalizedGuidance',
      desc:
          'The start your path toward hajj and umrah with personalized guidance message',
      args: [],
    );
  }

  /// `Your Labbaik journey awaits, log in to reconnect with your guidance`
  String get yourLabbaikJourneyAwaitsLogInToReconnectWithYourGuidance {
    return Intl.message(
      'Your Labbaik journey awaits, log in to reconnect with your guidance',
      name: 'yourLabbaikJourneyAwaitsLogInToReconnectWithYourGuidance',
      desc:
          'The your labbaik journey awaits log in to reconnect with your guidance message',
      args: [],
    );
  }

  /// `Get started now`
  String get getStartedNow {
    return Intl.message(
      'Get started now',
      name: 'getStartedNow',
      desc: 'The get started now message',
      args: [],
    );
  }

  /// `Sign in`
  String get signIn {
    return Intl.message(
      'Sign in',
      name: 'signIn',
      desc: 'The sign in message',
      args: [],
    );
  }

  /// `Sign up`
  String get signUp {
    return Intl.message(
      'Sign up',
      name: 'signUp',
      desc: 'The sign up message',
      args: [],
    );
  }

  /// `Email`
  String get email {
    return Intl.message('Email', name: 'email', desc: 'The email', args: []);
  }

  /// `Password`
  String get password {
    return Intl.message(
      'Password',
      name: 'password',
      desc: 'The password',
      args: [],
    );
  }

  /// `Remember me`
  String get rememberMe {
    return Intl.message(
      'Remember me',
      name: 'rememberMe',
      desc: 'The remember me message',
      args: [],
    );
  }

  /// `Forgot password?`
  String get forgotPassword {
    return Intl.message(
      'Forgot password?',
      name: 'forgotPassword',
      desc: 'The forgot password message',
      args: [],
    );
  }

  /// `First name`
  String get fName {
    return Intl.message(
      'First name',
      name: 'fName',
      desc: 'The first name',
      args: [],
    );
  }

  /// `Last name`
  String get lName {
    return Intl.message(
      'Last name',
      name: 'lName',
      desc: 'The last name',
      args: [],
    );
  }

  /// `Confirm password`
  String get confirmPassword {
    return Intl.message(
      'Confirm password',
      name: 'confirmPassword',
      desc: 'The confirm password',
      args: [],
    );
  }

  /// `Register`
  String get register {
    return Intl.message(
      'Register',
      name: 'register',
      desc: 'The register message',
      args: [],
    );
  }

  /// `Already have an account?`
  String get alreadyHaveAnAccount {
    return Intl.message(
      'Already have an account?',
      name: 'alreadyHaveAnAccount',
      desc: 'The already have an account message',
      args: [],
    );
  }

  /// `Date of birth`
  String get dateOfBirth {
    return Intl.message(
      'Date of birth',
      name: 'dateOfBirth',
      desc: 'The date of birth',
      args: [],
    );
  }

  /// `Phone number`
  String get phoneNumber {
    return Intl.message(
      'Phone number',
      name: 'phoneNumber',
      desc: 'The phone number',
      args: [],
    );
  }

  /// `Date of birth required`
  String get dateOfBirthRequired {
    return Intl.message(
      'Date of birth required',
      name: 'dateOfBirthRequired',
      desc: 'The date of birth is required',
      args: [],
    );
  }

  /// `Phone number must be longer than 10 characters`
  String get phoneNumberLength {
    return Intl.message(
      'Phone number must be longer than 10 characters',
      name: 'phoneNumberLength',
      desc: 'The phone number must be longer than 10 characters',
      args: [],
    );
  }

  /// `Enter your email address and we'll send you a link to reset your password`
  String get enterYourEmail {
    return Intl.message(
      'Enter your email address and we\'ll send you a link to reset your password',
      name: 'enterYourEmail',
      desc:
          'Enter your email address and we\'ll send you a link to reset your password',
      args: [],
    );
  }

  /// `Send Reset Link`
  String get sendResetLink {
    return Intl.message(
      'Send Reset Link',
      name: 'sendResetLink',
      desc: 'Send reset link',
      args: [],
    );
  }

  /// `Back to Login`
  String get backToLogin {
    return Intl.message(
      'Back to Login',
      name: 'backToLogin',
      desc: 'Back to login',
      args: [],
    );
  }

  /// `Reset link sent`
  String get resetLinkSent {
    return Intl.message(
      'Reset link sent',
      name: 'resetLinkSent',
      desc: 'Reset link has been sent',
      args: [],
    );
  }

  /// `Please check your email to reset your password`
  String get resetLinkSentMessage {
    return Intl.message(
      'Please check your email to reset your password',
      name: 'resetLinkSentMessage',
      desc: 'Reset link sent message',
      args: [],
    );
  }

  /// `Don't worry! It happens. Please enter the email associated with your account.`
  String get donTworryItHappensPleaseEnterTheEmailAssociatedWithYourAccount {
    return Intl.message(
      'Don\'t worry! It happens. Please enter the email associated with your account.',
      name: 'donTworryItHappensPleaseEnterTheEmailAssociatedWithYourAccount',
      desc:
          'Don\'t worry! It happens. Please enter the email associated with your account.',
      args: [],
    );
  }

  /// `Remember password?`
  String get rememberPasswordQuestion {
    return Intl.message(
      'Remember password?',
      name: 'rememberPasswordQuestion',
      desc: 'The remember password question',
      args: [],
    );
  }

  /// `Don't have an account?`
  String get backToLoginQuestion {
    return Intl.message(
      'Don\'t have an account?',
      name: 'backToLoginQuestion',
      desc: 'The back to login question',
      args: [],
    );
  }

  /// `Login`
  String get login {
    return Intl.message(
      'Login',
      name: 'login',
      desc: 'The login message',
      args: [],
    );
  }

  /// `Please check your email`
  String get pleaseCheckYourEmail {
    return Intl.message(
      'Please check your email',
      name: 'pleaseCheckYourEmail',
      desc: 'The please check your email message',
      args: [],
    );
  }

  /// `We've sent a verification link to {email}`
  String weveSentACodeTo(String email) {
    return Intl.message(
      'We\'ve sent a verification link to $email',
      name: 'weveSentACodeTo',
      desc: 'We\'ve sent a verification link to {email}',
      args: [email],
    );
  }

  /// `Click the verification link in your email to verify your account`
  String get clickTheLinkInYourEmail {
    return Intl.message(
      'Click the verification link in your email to verify your account',
      name: 'clickTheLinkInYourEmail',
      desc: 'Instruction to click the verification link',
      args: [],
    );
  }

  /// `Resend link`
  String get resendLink {
    return Intl.message(
      'Resend link',
      name: 'resendLink',
      desc: 'Resend verification link',
      args: [],
    );
  }

  /// `Waiting for email verification...`
  String get waitingForVerification {
    return Intl.message(
      'Waiting for email verification...',
      name: 'waitingForVerification',
      desc: 'Waiting for email verification message',
      args: [],
    );
  }

  /// `Verify`
  String get verify {
    return Intl.message(
      'Verify',
      name: 'verify',
      desc: 'Verify button',
      args: [],
    );
  }

  /// `Resend code`
  String get resendCode {
    return Intl.message(
      'Resend code',
      name: 'resendCode',
      desc: 'Resend code',
      args: [],
    );
  }

  /// `Enter the code`
  String get enterCode {
    return Intl.message(
      'Enter the code',
      name: 'enterCode',
      desc: 'Enter the code message',
      args: [],
    );
  }

  /// `Send code`
  String get sendCode {
    return Intl.message(
      'Send code',
      name: 'sendCode',
      desc: 'Send code',
      args: [],
    );
  }

  /// `Password Requirements`
  String get passwordRequirements {
    return Intl.message(
      'Password Requirements',
      name: 'passwordRequirements',
      desc: 'Password requirements title',
      args: [],
    );
  }

  /// `Must be at least 8 characters long`
  String get mustBeAtLeast8CharactersLong {
    return Intl.message(
      'Must be at least 8 characters long',
      name: 'mustBeAtLeast8CharactersLong',
      desc: 'Password must be at least 8 characters long',
      args: [],
    );
  }

  /// `Must include at least one uppercase letter (A–Z)`
  String get mustIncludeAtLeastOneUppercaseLetter {
    return Intl.message(
      'Must include at least one uppercase letter (A–Z)',
      name: 'mustIncludeAtLeastOneUppercaseLetter',
      desc: 'Password must include at least one uppercase letter',
      args: [],
    );
  }

  /// `Must include at least one lowercase letter (a–z)`
  String get mustIncludeAtLeastOneLowercaseLetter {
    return Intl.message(
      'Must include at least one lowercase letter (a–z)',
      name: 'mustIncludeAtLeastOneLowercaseLetter',
      desc: 'Password must include at least one lowercase letter',
      args: [],
    );
  }

  /// `Must include at least one digit (0–9)`
  String get mustIncludeAtLeastOneDigit {
    return Intl.message(
      'Must include at least one digit (0–9)',
      name: 'mustIncludeAtLeastOneDigit',
      desc: 'Password must include at least one digit',
      args: [],
    );
  }

  /// `Must include at least one special character (!@#$%^&*()_+)`
  String get mustIncludeAtLeastOneSpecialCharacter {
    return Intl.message(
      'Must include at least one special character (!@#\$%^&*()_+)',
      name: 'mustIncludeAtLeastOneSpecialCharacter',
      desc: 'Password must include at least one special character',
      args: [],
    );
  }

  /// `Must not contain spaces`
  String get mustNotContainSpaces {
    return Intl.message(
      'Must not contain spaces',
      name: 'mustNotContainSpaces',
      desc: 'Password must not contain spaces',
      args: [],
    );
  }

  /// `Password does not meet all requirements`
  String get passwordDoesNotMeetAllRequirements {
    return Intl.message(
      'Password does not meet all requirements',
      name: 'passwordDoesNotMeetAllRequirements',
      desc: 'Password does not meet all requirements',
      args: [],
    );
  }

  /// `Reset password`
  String get resetPassword {
    return Intl.message(
      'Reset password',
      name: 'resetPassword',
      desc: 'Reset password',
      args: [],
    );
  }

  /// `Please type something you'll remember`
  String get pleaseTypeSomethingYoullRemember {
    return Intl.message(
      'Please type something you\'ll remember',
      name: 'pleaseTypeSomethingYoullRemember',
      desc: 'Please type something you\'ll remember',
      args: [],
    );
  }

  /// `New Password`
  String get newPassword {
    return Intl.message(
      'New Password',
      name: 'newPassword',
      desc: 'New Password',
      args: [],
    );
  }

  /// `Confirm New Password`
  String get confirmNewPassword {
    return Intl.message(
      'Confirm New Password',
      name: 'confirmNewPassword',
      desc: 'Confirm New Password',
      args: [],
    );
  }

  /// `Current Password`
  String get currentPassword {
    return Intl.message(
      'Current Password',
      name: 'currentPassword',
      desc: 'Current Password',
      args: [],
    );
  }

  /// `New password must be different from current password`
  String get newPasswordMustBeDifferent {
    return Intl.message(
      'New password must be different from current password',
      name: 'newPasswordMustBeDifferent',
      desc: 'New password must be different error message',
      args: [],
    );
  }

  /// `Password changed`
  String get passwordChanged {
    return Intl.message(
      'Password changed',
      name: 'passwordChanged',
      desc: 'Password changed title',
      args: [],
    );
  }

  /// `Your password has been changed successfully`
  String get passwordChangedSuccessfully {
    return Intl.message(
      'Your password has been changed successfully',
      name: 'passwordChangedSuccessfully',
      desc: 'Password changed success message',
      args: [],
    );
  }

  /// `General`
  String get general {
    return Intl.message(
      'General',
      name: 'general',
      desc: 'General title',
      args: [],
    );
  }

  /// `Manage companions`
  String get manageCompanions {
    return Intl.message(
      'Manage companions',
      name: 'manageCompanions',
      desc: 'Manage companions title',
      args: [],
    );
  }

  /// `Name`
  String get name {
    return Intl.message('Name', name: 'name', desc: 'Name title', args: []);
  }

  /// `Profile`
  String get profile {
    return Intl.message(
      'Profile',
      name: 'profile',
      desc: 'Profile title',
      args: [],
    );
  }

  /// `Settings`
  String get settings {
    return Intl.message(
      'Settings',
      name: 'settings',
      desc: 'Settings title',
      args: [],
    );
  }

  /// `Dark mode`
  String get darkMode {
    return Intl.message(
      'Dark mode',
      name: 'darkMode',
      desc: 'Dark mode setting',
      args: [],
    );
  }

  /// `Change password`
  String get changePassword {
    return Intl.message(
      'Change password',
      name: 'changePassword',
      desc: 'Change password setting',
      args: [],
    );
  }

  /// `Calendar`
  String get calendar {
    return Intl.message(
      'Calendar',
      name: 'calendar',
      desc: 'Calendar setting',
      args: [],
    );
  }

  /// `App language`
  String get appLanguage {
    return Intl.message(
      'App language',
      name: 'appLanguage',
      desc: 'App language setting',
      args: [],
    );
  }

  /// `Account`
  String get account {
    return Intl.message(
      'Account',
      name: 'account',
      desc: 'Account section header',
      args: [],
    );
  }

  /// `Services`
  String get services {
    return Intl.message(
      'Services',
      name: 'services',
      desc: 'Services section header',
      args: [],
    );
  }

  /// `App`
  String get app {
    return Intl.message(
      'App',
      name: 'app',
      desc: 'App section header',
      args: [],
    );
  }

  /// `Location`
  String get location {
    return Intl.message(
      'Location',
      name: 'location',
      desc: 'Location setting',
      args: [],
    );
  }

  /// `Rate Us`
  String get rateUs {
    return Intl.message(
      'Rate Us',
      name: 'rateUs',
      desc: 'Rate Us setting',
      args: [],
    );
  }

  /// `Technical Support`
  String get technicalSupport {
    return Intl.message(
      'Technical Support',
      name: 'technicalSupport',
      desc: 'Technical Support setting',
      args: [],
    );
  }

  /// `Share App`
  String get shareApp {
    return Intl.message(
      'Share App',
      name: 'shareApp',
      desc: 'Share App setting',
      args: [],
    );
  }

  /// `Umrah Guidance`
  String get umrahGuidance {
    return Intl.message(
      'Umrah Guidance',
      name: 'umrahGuidance',
      desc: 'Umrah Guidance screen title',
      args: [],
    );
  }

  /// `Step`
  String get step {
    return Intl.message('Step', name: 'step', desc: 'Step label', args: []);
  }

  /// `Ihram`
  String get ihram {
    return Intl.message(
      'Ihram',
      name: 'ihram',
      desc: 'Ihram step title',
      args: [],
    );
  }

  /// `Tawaf`
  String get tawaf {
    return Intl.message(
      'Tawaf',
      name: 'tawaf',
      desc: 'Tawaf step title',
      args: [],
    );
  }

  /// `Sa'ee`
  String get saee {
    return Intl.message(
      'Sa\'ee',
      name: 'saee',
      desc: 'Sa\'ee step title',
      args: [],
    );
  }

  /// `Tahallul`
  String get tahallul {
    return Intl.message(
      'Tahallul',
      name: 'tahallul',
      desc: 'Tahallul step title',
      args: [],
    );
  }

  /// `Logout`
  String get logout {
    return Intl.message(
      'Logout',
      name: 'logout',
      desc: 'Logout button',
      args: [],
    );
  }

  /// `Fajr`
  String get fajr {
    return Intl.message(
      'Fajr',
      name: 'fajr',
      desc: 'Fajr prayer title',
      args: [],
    );
  }

  /// `Sunrise`
  String get sunrise {
    return Intl.message(
      'Sunrise',
      name: 'sunrise',
      desc: 'Sunrise prayer title',
      args: [],
    );
  }

  /// `Dhuhr`
  String get dhuhr {
    return Intl.message(
      'Dhuhr',
      name: 'dhuhr',
      desc: 'Dhuhr prayer title',
      args: [],
    );
  }

  /// `Asr`
  String get asr {
    return Intl.message('Asr', name: 'asr', desc: 'Asr prayer title', args: []);
  }

  /// `Maghrib`
  String get maghrib {
    return Intl.message(
      'Maghrib',
      name: 'maghrib',
      desc: 'Maghrib prayer title',
      args: [],
    );
  }

  /// `Isha`
  String get isha {
    return Intl.message(
      'Isha',
      name: 'isha',
      desc: 'Isha prayer title',
      args: [],
    );
  }

  /// `Remaining`
  String get remaining {
    return Intl.message(
      'Remaining',
      name: 'remaining',
      desc: 'Remaining time title',
      args: [],
    );
  }

  /// `Icon and icon data cannot be null`
  String get iconAndIconDataCannotBeNull {
    return Intl.message(
      'Icon and icon data cannot be null',
      name: 'iconAndIconDataCannotBeNull',
      desc: 'Icon and icon data cannot be null',
      args: [],
    );
  }

  /// `English`
  String get english {
    return Intl.message(
      'English',
      name: 'english',
      desc: 'English language',
      args: [],
    );
  }

  /// `Arabic`
  String get arabic {
    return Intl.message(
      'Arabic',
      name: 'arabic',
      desc: 'Arabic language',
      args: [],
    );
  }

  /// `Progress`
  String get progress {
    return Intl.message(
      'Progress',
      name: 'progress',
      desc: 'Progress title',
      args: [],
    );
  }

  /// `Complete`
  String get complete {
    return Intl.message(
      'Complete',
      name: 'complete',
      desc: 'Complete title',
      args: [],
    );
  }

  /// `Description`
  String get description {
    return Intl.message(
      'Description',
      name: 'description',
      desc: 'Description label',
      args: [],
    );
  }

  /// `A Muslim enters into the state of Ihraam from the place specified for him by Islamic law, and he abstains from the prohibitions which he is prohibited from while in Ihraam.`
  String get step1Description {
    return Intl.message(
      'A Muslim enters into the state of Ihraam from the place specified for him by Islamic law, and he abstains from the prohibitions which he is prohibited from while in Ihraam.',
      name: 'step1Description',
      desc: 'Step 1 description for Ihram',
      args: [],
    );
  }

  /// `An act of worship in which a Muslim circumambulates around the Kaaba **seven times**, worshiping and drawing closer to Allah.`
  String get step2Description {
    return Intl.message(
      'An act of worship in which a Muslim circumambulates around the Kaaba **seven times**, worshiping and drawing closer to Allah.',
      name: 'step2Description',
      desc: 'Step 2 description for Tawaf',
      args: [],
    );
  }

  /// `During this ritual, the pilgrim worships Allah by walking between as-Safa and al-Marwah seven times, following the practice of the noble The Prophet ﷺ.  Performing sa'ee without wudu is permissible and carries no sin. Although being in a state of purity is preferable if possible.`
  String get step3Description {
    return Intl.message(
      'During this ritual, the pilgrim worships Allah by walking between as-Safa and al-Marwah seven times, following the practice of the noble The Prophet ﷺ.  Performing sa\'ee without wudu is permissible and carries no sin. Although being in a state of purity is preferable if possible.',
      name: 'step3Description',
      desc: 'Step 3 description for Sa\'ee',
      args: [],
    );
  }

  /// `Shortening the hair during Umrah is a required and essential ritual for completing the pilgrimage. It is performed after finishing the Sa'ee between Safa and Marwah by cutting a portion of the hair on the head. Through this act, the pilgrim exits the state of Ihram and is once again permitted to engage in the activities that were prohibited during Ihram.\n\nFor men, shaving the head is better and more rewarding than simply shortening , as <gold>The Prophet ﷺ supplicated three times for those who shave and only once for those who shorten.</gold> \n\n<gold>"O Allah! Forgive those who get their heads shaved."</gold> The people asked. <gold>"Also those who get their hair cut short?"</gold> <gold>The Prophet (ﷺ) said, "O Allah! Forgive those who have their heads shaved."</gold> The people said, <gold>"Also those who get their hair cut short?"</gold> <gold>The Prophet (invoke Allah for those who have their heads shaved and) at the third time said, "also (forgive) those who get their hair cut short."</gold> —Sahih al-Bukhari 1728 Book 25, Hadith 206`
  String get step4Description {
    return Intl.message(
      'Shortening the hair during Umrah is a required and essential ritual for completing the pilgrimage. It is performed after finishing the Sa\'ee between Safa and Marwah by cutting a portion of the hair on the head. Through this act, the pilgrim exits the state of Ihram and is once again permitted to engage in the activities that were prohibited during Ihram.\n\nFor men, shaving the head is better and more rewarding than simply shortening , as <gold>The Prophet ﷺ supplicated three times for those who shave and only once for those who shorten.</gold> \n\n<gold>"O Allah! Forgive those who get their heads shaved."</gold> The people asked. <gold>"Also those who get their hair cut short?"</gold> <gold>The Prophet (ﷺ) said, "O Allah! Forgive those who have their heads shaved."</gold> The people said, <gold>"Also those who get their hair cut short?"</gold> <gold>The Prophet (invoke Allah for those who have their heads shaved and) at the third time said, "also (forgive) those who get their hair cut short."</gold> —Sahih al-Bukhari 1728 Book 25, Hadith 206',
      name: 'step4Description',
      desc: 'Step 4 description for Tahallul',
      args: [],
    );
  }

  /// `A Muslim enters into the state of Ihraam from the place specified for him by Islamic law, and he abstains from the prohibitions which he is prohibited from while in Ihraam.`
  String get step1GuidanceDescription {
    return Intl.message(
      'A Muslim enters into the state of Ihraam from the place specified for him by Islamic law, and he abstains from the prohibitions which he is prohibited from while in Ihraam.',
      name: 'step1GuidanceDescription',
      desc: 'Step 1 guidance description for Ihram',
      args: [],
    );
  }

  /// `Entering Ihram at Miqat`
  String get enteringIhramAtMiqat {
    return Intl.message(
      'Entering Ihram at Miqat',
      name: 'enteringIhramAtMiqat',
      desc: 'Sub-step title for entering Ihram at Miqat',
      args: [],
    );
  }

  /// `Upon arriving at the miqat, the pilgrim makes the intention in the heart to perform ʿUmrah. This intention must be made at or before crossing the miqat. After forming the intention internally, the pilgrim verbally declares: "Labbayka Umrah", and then begins reciting the Talbiyah.\n<gold>The Prophet ﷺ used to:</gold>\nPerform ghusl (bath) and clean yourself.\n\t•\tRecommended for both men and women.\n\t•\tIf not possible at the miqāt, it's permissible to delay; bathing on arrival\n•Apply perfume to the body before putting on the ihram garments. <red>After entering ihram, applying perfume is forbidden.</red>\n\nMaking a Condition in Ihram\nIf a pilgrim **fears that they may not be able to complete their ʿUmrah** due to illness or any legitimate obstacle, it is permissible to **make a condition** when entering ihram. After declaring: "Labbayka ʿUmrah," the pilgrim says: "If I am prevented by anything, then my place of release is where I am held up." If something occurs that prevents the pilgrim from completing the ʿUmrah, they may exit the state of ihram and stop the pilgrimage without any sin or penalty.`
  String get enteringIhramAtMiqatDescription {
    return Intl.message(
      'Upon arriving at the miqat, the pilgrim makes the intention in the heart to perform ʿUmrah. This intention must be made at or before crossing the miqat. After forming the intention internally, the pilgrim verbally declares: "Labbayka Umrah", and then begins reciting the Talbiyah.\n<gold>The Prophet ﷺ used to:</gold>\nPerform ghusl (bath) and clean yourself.\n\t•\tRecommended for both men and women.\n\t•\tIf not possible at the miqāt, it\'s permissible to delay; bathing on arrival\n•Apply perfume to the body before putting on the ihram garments. <red>After entering ihram, applying perfume is forbidden.</red>\n\nMaking a Condition in Ihram\nIf a pilgrim **fears that they may not be able to complete their ʿUmrah** due to illness or any legitimate obstacle, it is permissible to **make a condition** when entering ihram. After declaring: "Labbayka ʿUmrah," the pilgrim says: "If I am prevented by anything, then my place of release is where I am held up." If something occurs that prevents the pilgrim from completing the ʿUmrah, they may exit the state of ihram and stop the pilgrimage without any sin or penalty.',
      name: 'enteringIhramAtMiqatDescription',
      desc: 'Description for entering Ihram at Miqat',
      args: [],
    );
  }

  /// `Entering Ihram from an Airplane`
  String get enteringIhramFromAirplane {
    return Intl.message(
      'Entering Ihram from an Airplane',
      name: 'enteringIhramFromAirplane',
      desc: 'Sub-step title for entering Ihram from airplane',
      args: [],
    );
  }

  /// `A pilgrim traveling by plane may enter the state of **ihram while still on the aircraft**, before reaching the city of Jeddah, when the plane reaches the vicinity of the miqat. Anyone intending to perform Umrah should be **ready with the ihram garments** and **avoid the prohibitions of ihram** before the announcement, allowing sufficient time to enter the state properly.`
  String get enteringIhramFromAirplaneDescription {
    return Intl.message(
      'A pilgrim traveling by plane may enter the state of **ihram while still on the aircraft**, before reaching the city of Jeddah, when the plane reaches the vicinity of the miqat. Anyone intending to perform Umrah should be **ready with the ihram garments** and **avoid the prohibitions of ihram** before the announcement, allowing sufficient time to enter the state properly.',
      name: 'enteringIhramFromAirplaneDescription',
      desc: 'Description for entering Ihram from airplane',
      args: [],
    );
  }

  /// `Men's Ihram Garments`
  String get mensIhramGarments {
    return Intl.message(
      'Men\'s Ihram Garments',
      name: 'mensIhramGarments',
      desc: 'Sub-step title for men\'s Ihram garments',
      args: [],
    );
  }

  /// `A man is **<red>prohibited from wearing stitched clothing</red>** when entering ihram. He must remove his usual clothes, including head coverings such as hats or turbans, and any tailored clothing that fits the body, such as shirts, pants, socks, gloves, or anything similar. He also **<red>must not wear shoes that cover the entire foot</red>** including the heel.  A man should wear an izar (lower wrap) covering the lower body and a rida (upper wrap) covering the upper body. It is recommended that these garments be white. Sandals that do not cover the entire foot are permissible.`
  String get mensIhramGarmentsDescription {
    return Intl.message(
      'A man is **<red>prohibited from wearing stitched clothing</red>** when entering ihram. He must remove his usual clothes, including head coverings such as hats or turbans, and any tailored clothing that fits the body, such as shirts, pants, socks, gloves, or anything similar. He also **<red>must not wear shoes that cover the entire foot</red>** including the heel.  A man should wear an izar (lower wrap) covering the lower body and a rida (upper wrap) covering the upper body. It is recommended that these garments be white. Sandals that do not cover the entire foot are permissible.',
      name: 'mensIhramGarmentsDescription',
      desc: 'Description for men\'s Ihram garments',
      args: [],
    );
  }

  /// `Women's Ihram Garments`
  String get womensIhramGarments {
    return Intl.message(
      'Women\'s Ihram Garments',
      name: 'womensIhramGarments',
      desc: 'Sub-step title for women\'s Ihram garments',
      args: [],
    );
  }

  /// `It is permissible for a woman to wear stitched clothing when entering ihram, and she may choose any type of garment in any color or style. However, her clothing must be **loose-fitting**, **provide full coverage**, allow ease of movement, and **<red>not include visible adornment that may attract attention.</red>**\n**<gold>The Prophet ﷺ guided those entering ihram, saying:</gold>**\n"A woman should not wear the niqab (face veil) nor gloves while in ihram."`
  String get womensIhramGarmentsDescription {
    return Intl.message(
      'It is permissible for a woman to wear stitched clothing when entering ihram, and she may choose any type of garment in any color or style. However, her clothing must be **loose-fitting**, **provide full coverage**, allow ease of movement, and **<red>not include visible adornment that may attract attention.</red>**\n**<gold>The Prophet ﷺ guided those entering ihram, saying:</gold>**\n"A woman should not wear the niqab (face veil) nor gloves while in ihram."',
      name: 'womensIhramGarmentsDescription',
      desc: 'Description for women\'s Ihram garments',
      args: [],
    );
  }

  /// `Prohibitions of Ihram`
  String get prohibitionsOfIhram {
    return Intl.message(
      'Prohibitions of Ihram',
      name: 'prohibitionsOfIhram',
      desc: 'Sub-step title for prohibitions of Ihram',
      args: [],
    );
  }

  /// `Wearing stitched clothing (for men)`
  String get prohibitionWearingStitchedClothing {
    return Intl.message(
      'Wearing stitched clothing (for men)',
      name: 'prohibitionWearingStitchedClothing',
      desc: '',
      args: [],
    );
  }

  /// `Covering the head (for men)`
  String get prohibitionCoveringHead {
    return Intl.message(
      'Covering the head (for men)',
      name: 'prohibitionCoveringHead',
      desc: '',
      args: [],
    );
  }

  /// `Shaving or cutting hair during Ihram`
  String get prohibitionShavingHair {
    return Intl.message(
      'Shaving or cutting hair during Ihram',
      name: 'prohibitionShavingHair',
      desc: '',
      args: [],
    );
  }

  /// `Hunting`
  String get prohibitionHunting {
    return Intl.message(
      'Hunting',
      name: 'prohibitionHunting',
      desc: '',
      args: [],
    );
  }

  /// `Cutting nails`
  String get prohibitionCuttingNails {
    return Intl.message(
      'Cutting nails',
      name: 'prohibitionCuttingNails',
      desc: '',
      args: [],
    );
  }

  /// `Applying perfume`
  String get prohibitionApplyingPerfume {
    return Intl.message(
      'Applying perfume',
      name: 'prohibitionApplyingPerfume',
      desc: '',
      args: [],
    );
  }

  /// `Wearing the niqab or gloves (for women)`
  String get prohibitionNiqabGloves {
    return Intl.message(
      'Wearing the niqab or gloves (for women)',
      name: 'prohibitionNiqabGloves',
      desc: '',
      args: [],
    );
  }

  /// `Marriage contract (nikah)`
  String get prohibitionMarriageContract {
    return Intl.message(
      'Marriage contract (nikah)',
      name: 'prohibitionMarriageContract',
      desc: '',
      args: [],
    );
  }

  /// `Sexual intercourse`
  String get prohibitionSexualIntercourse {
    return Intl.message(
      'Sexual intercourse',
      name: 'prohibitionSexualIntercourse',
      desc: '',
      args: [],
    );
  }

  /// `Tawaf is the first act of worship performed by a pilgrim in the state of ihram. It is a circular movement around the Kaaba, performed counterclockwise, starting from the Black Stone (Hajar al-Aswad).`
  String get step2GuidanceDescription {
    return Intl.message(
      'Tawaf is the first act of worship performed by a pilgrim in the state of ihram. It is a circular movement around the Kaaba, performed counterclockwise, starting from the Black Stone (Hajar al-Aswad).',
      name: 'step2GuidanceDescription',
      desc: 'Step 2 guidance description for Tawaf',
      args: [],
    );
  }

  /// ` Begin tawaf with the Kaaba on your Left\n start at the Black Stone, facing it, and say "Bismillah, Allahu Akbar" as you begin your first circuit.`
  String get tawafSubDesc1 {
    return Intl.message(
      ' Begin tawaf with the Kaaba on your Left\n start at the Black Stone, facing it, and say "Bismillah, Allahu Akbar" as you begin your first circuit.',
      name: 'tawafSubDesc1',
      desc: '',
      args: [],
    );
  }

  /// `When you reach the Yemeni corner, If you can touch it with your right hand, do so and say: "Bismillah, Allahu Akbar." <red>Don't kiss or point at the Yemeni corner it's not from the Sunnah.</red>`
  String get tawafSubDesc2 {
    return Intl.message(
      'When you reach the Yemeni corner, If you can touch it with your right hand, do so and say: "Bismillah, Allahu Akbar." <red>Don\'t kiss or point at the Yemeni corner it\'s not from the Sunnah.</red>',
      name: 'tawafSubDesc2',
      desc: '',
      args: [],
    );
  }

  /// `When you reach the Black Stone touch and kiss it if possible. If not, point toward it with your hand once and say "Allahu Akbar."`
  String get tawafSubDesc3 {
    return Intl.message(
      'When you reach the Black Stone touch and kiss it if possible. If not, point toward it with your hand once and say "Allahu Akbar."',
      name: 'tawafSubDesc3',
      desc: '',
      args: [],
    );
  }

  /// `Engage in Duaa and Thikr, There is no specific dua required for each round.`
  String get tawafSubDesc4 {
    return Intl.message(
      'Engage in Duaa and Thikr, There is no specific dua required for each round.',
      name: 'tawafSubDesc4',
      desc: '',
      args: [],
    );
  }

  /// `Walk briskly with short quick steps during the first three rounds of Tawaf, specific to men`
  String get tawafSubDesc5 {
    return Intl.message(
      'Walk briskly with short quick steps during the first three rounds of Tawaf, specific to men',
      name: 'tawafSubDesc5',
      desc: '',
      args: [],
    );
  }

  /// `Keep the right shoulder uncovered by placing the middle of the upper garment under the right arm and the ends over the left shoulder during all rounds of Tawaf al-Qudum.`
  String get tawafSubDesc6 {
    return Intl.message(
      'Keep the right shoulder uncovered by placing the middle of the upper garment under the right arm and the ends over the left shoulder during all rounds of Tawaf al-Qudum.',
      name: 'tawafSubDesc6',
      desc: '',
      args: [],
    );
  }

  /// `<gold>The Prophet ﷺ used to:</gold> Recite the dua:\n"Rabbana ātinā fid-dunyā ḥasanah, wa fil-ākhirati ḥasanah, wa qinā 'adhāban-nār." Between the Yemeni Corner and the Black Stone`
  String get tawafSubDesc7 {
    return Intl.message(
      '<gold>The Prophet ﷺ used to:</gold> Recite the dua:\n"Rabbana ātinā fid-dunyā ḥasanah, wa fil-ākhirati ḥasanah, wa qinā \'adhāban-nār." Between the Yemeni Corner and the Black Stone',
      name: 'tawafSubDesc7',
      desc: '',
      args: [],
    );
  }

  /// `Proceed to as-Safa, where the sa'ee begins toward al-Marwah. <gold>The Prophet ﷺ used to:</gold> jog between the two green markers during Sa'ee, this Sunnah is specific to men.`
  String get saeeSubDesc1 {
    return Intl.message(
      'Proceed to as-Safa, where the sa\'ee begins toward al-Marwah. <gold>The Prophet ﷺ used to:</gold> jog between the two green markers during Sa\'ee, this Sunnah is specific to men.',
      name: 'saeeSubDesc1',
      desc: '',
      args: [],
    );
  }

  /// `When the you reach al-Marwah, one round is completed.`
  String get saeeSubDesc2 {
    return Intl.message(
      'When the you reach al-Marwah, one round is completed.',
      name: 'saeeSubDesc2',
      desc: '',
      args: [],
    );
  }

  /// `Return to as-Safa for the second round, continuing in this manner until completing seven rounds, ending at al-Marwah.`
  String get saeeSubDesc3 {
    return Intl.message(
      'Return to as-Safa for the second round, continuing in this manner until completing seven rounds, ending at al-Marwah.',
      name: 'saeeSubDesc3',
      desc: '',
      args: [],
    );
  }

  /// `It is permissible for someone who is unable to walk, or who feels exhausted, ill, or weak, to perform sa'ee while being carried or transported. However, they must remain awake and attentive, as sa'ee is an act of worship, and they should make use of their time by supplicating and turning to Allah with humility.`
  String get saeeSubDesc4 {
    return Intl.message(
      'It is permissible for someone who is unable to walk, or who feels exhausted, ill, or weak, to perform sa\'ee while being carried or transported. However, they must remain awake and attentive, as sa\'ee is an act of worship, and they should make use of their time by supplicating and turning to Allah with humility.',
      name: 'saeeSubDesc4',
      desc: '',
      args: [],
    );
  }

  /// `{completedSteps}/{totalSteps} {stepsCount, plural, one {step} other {steps}}`
  String progressDescription(
    int completedSteps,
    int totalSteps,
    int stepsCount,
  ) {
    return Intl.message(
      '$completedSteps/$totalSteps ${Intl.plural(stepsCount, one: 'step', other: 'steps')}',
      name: 'progressDescription',
      desc: 'Progress description',
      args: [completedSteps, totalSteps, stepsCount],
    );
  }

  /// `Steps`
  String get steps {
    return Intl.message('Steps', name: 'steps', desc: 'Steps title', args: []);
  }

  /// `Sign in failed`
  String get signInFailed {
    return Intl.message(
      'Sign in failed',
      name: 'signInFailed',
      desc: 'Sign in failed error message',
      args: [],
    );
  }

  /// `Sign up failed`
  String get signUpFailed {
    return Intl.message(
      'Sign up failed',
      name: 'signUpFailed',
      desc: 'Sign up failed error message',
      args: [],
    );
  }

  /// `An unexpected error occurred. Please try again.`
  String get unexpectedErrorOccurred {
    return Intl.message(
      'An unexpected error occurred. Please try again.',
      name: 'unexpectedErrorOccurred',
      desc: 'Unexpected error occurred message',
      args: [],
    );
  }

  /// `Failed to send verification email. Please try again.`
  String get failedToSendVerificationEmail {
    return Intl.message(
      'Failed to send verification email. Please try again.',
      name: 'failedToSendVerificationEmail',
      desc: 'Failed to send verification email message',
      args: [],
    );
  }

  /// `Failed to sign out. Please try again.`
  String get failedToSignOut {
    return Intl.message(
      'Failed to sign out. Please try again.',
      name: 'failedToSignOut',
      desc: 'Failed to sign out message',
      args: [],
    );
  }

  /// `Failed to resend email`
  String get failedToResendEmail {
    return Intl.message(
      'Failed to resend email',
      name: 'failedToResendEmail',
      desc: 'Failed to resend email message',
      args: [],
    );
  }

  /// `Please verify your email first`
  String get pleaseVerifyYourEmailFirst {
    return Intl.message(
      'Please verify your email first',
      name: 'pleaseVerifyYourEmailFirst',
      desc: 'Please verify your email first message',
      args: [],
    );
  }

  /// `The password provided is too weak.`
  String get weakPassword {
    return Intl.message(
      'The password provided is too weak.',
      name: 'weakPassword',
      desc: 'Weak password error message',
      args: [],
    );
  }

  /// `An account already exists for that email.`
  String get emailAlreadyInUse {
    return Intl.message(
      'An account already exists for that email.',
      name: 'emailAlreadyInUse',
      desc: 'Email already in use error message',
      args: [],
    );
  }

  /// `The email address is invalid.`
  String get invalidEmail {
    return Intl.message(
      'The email address is invalid.',
      name: 'invalidEmail',
      desc: 'Invalid email error message',
      args: [],
    );
  }

  /// `This user account has been disabled.`
  String get userDisabled {
    return Intl.message(
      'This user account has been disabled.',
      name: 'userDisabled',
      desc: 'User disabled error message',
      args: [],
    );
  }

  /// `No user found for that email.`
  String get userNotFound {
    return Intl.message(
      'No user found for that email.',
      name: 'userNotFound',
      desc: 'User not found error message',
      args: [],
    );
  }

  /// `Wrong password provided.`
  String get wrongPassword {
    return Intl.message(
      'Wrong password provided.',
      name: 'wrongPassword',
      desc: 'Wrong password error message',
      args: [],
    );
  }

  /// `Too many requests. Please try again later.`
  String get tooManyRequests {
    return Intl.message(
      'Too many requests. Please try again later.',
      name: 'tooManyRequests',
      desc: 'Too many requests error message',
      args: [],
    );
  }

  /// `Operation not allowed.`
  String get operationNotAllowed {
    return Intl.message(
      'Operation not allowed.',
      name: 'operationNotAllowed',
      desc: 'Operation not allowed error message',
      args: [],
    );
  }

  /// `An error occurred. Please try again.`
  String get errorOccurred {
    return Intl.message(
      'An error occurred. Please try again.',
      name: 'errorOccurred',
      desc: 'Generic error occurred message',
      args: [],
    );
  }

  /// `Open Map`
  String get openMap {
    return Intl.message(
      'Open Map',
      name: 'openMap',
      desc: 'Open map button text',
      args: [],
    );
  }

  /// `Find your location and navigate to important places`
  String get findYourLocationAndNavigate {
    return Intl.message(
      'Find your location and navigate to important places',
      name: 'findYourLocationAndNavigate',
      desc: 'Map tab description',
      args: [],
    );
  }

  /// `Kaaba`
  String get kaaba {
    return Intl.message(
      'Kaaba',
      name: 'kaaba',
      desc: 'Kaaba location name',
      args: [],
    );
  }

  /// `Mecca, Saudi Arabia`
  String get meccaSaudiArabia {
    return Intl.message(
      'Mecca, Saudi Arabia',
      name: 'meccaSaudiArabia',
      desc: 'Mecca location',
      args: [],
    );
  }

  /// `Prophet's Mosque`
  String get prophetsMosque {
    return Intl.message(
      'Prophet\'s Mosque',
      name: 'prophetsMosque',
      desc: 'Prophet\'s Mosque location name',
      args: [],
    );
  }

  /// `Medina, Saudi Arabia`
  String get medinaSaudiArabia {
    return Intl.message(
      'Medina, Saudi Arabia',
      name: 'medinaSaudiArabia',
      desc: 'Medina location',
      args: [],
    );
  }

  /// `Welcome to Labbaik Assistant`
  String get welcomeToLabbaikAssistant {
    return Intl.message(
      'Welcome to Labbaik Assistant',
      name: 'welcomeToLabbaikAssistant',
      desc: 'Chatbot welcome message',
      args: [],
    );
  }

  /// `Ask me anything about Umrah`
  String get askMeAnythingAboutUmrah {
    return Intl.message(
      'Ask me anything about Umrah',
      name: 'askMeAnythingAboutUmrah',
      desc: 'Chatbot subtitle',
      args: [],
    );
  }

  /// `Type your message...`
  String get typeYourMessage {
    return Intl.message(
      'Type your message...',
      name: 'typeYourMessage',
      desc: 'Chatbot input placeholder',
      args: [],
    );
  }

  /// `Retry`
  String get retry {
    return Intl.message(
      'Retry',
      name: 'retry',
      desc: 'Retry button text',
      args: [],
    );
  }

  /// `Loading map...`
  String get loadingMap {
    return Intl.message(
      'Loading map...',
      name: 'loadingMap',
      desc: 'Loading map message',
      args: [],
    );
  }

  /// `Search`
  String get search {
    return Intl.message(
      'Search',
      name: 'search',
      desc: 'Search placeholder text',
      args: [],
    );
  }

  /// `Mosques`
  String get mosques {
    return Intl.message(
      'Mosques',
      name: 'mosques',
      desc: 'Mosques category filter',
      args: [],
    );
  }

  /// `Ritual Sites`
  String get ritualSites {
    return Intl.message(
      'Ritual Sites',
      name: 'ritualSites',
      desc: 'Ritual Sites category filter',
      args: [],
    );
  }

  /// `Historic Sites`
  String get historicSites {
    return Intl.message(
      'Historic Sites',
      name: 'historicSites',
      desc: 'Historic Sites category filter',
      args: [],
    );
  }

  /// `Museums`
  String get museums {
    return Intl.message(
      'Museums',
      name: 'museums',
      desc: 'Museums category filter',
      args: [],
    );
  }

  /// `Hotels`
  String get hotels {
    return Intl.message(
      'Hotels',
      name: 'hotels',
      desc: 'Hotels category filter',
      args: [],
    );
  }

  /// `Thour Cave`
  String get thourCave {
    return Intl.message(
      'Thour Cave',
      name: 'thourCave',
      desc: 'Thour Cave location name',
      args: [],
    );
  }

  /// `Mina`
  String get mina {
    return Intl.message(
      'Mina',
      name: 'mina',
      desc: 'Mina location name',
      args: [],
    );
  }

  /// `Muzdalifa`
  String get muzdalifa {
    return Intl.message(
      'Muzdalifa',
      name: 'muzdalifa',
      desc: 'Muzdalifa location name',
      args: [],
    );
  }

  /// `Wadi Jalil`
  String get wadiJalil {
    return Intl.message(
      'Wadi Jalil',
      name: 'wadiJalil',
      desc: 'Wadi Jalil location name',
      args: [],
    );
  }

  /// `Batha Quraish`
  String get bathaQuraish {
    return Intl.message(
      'Batha Quraish',
      name: 'bathaQuraish',
      desc: 'Batha Quraish location name',
      args: [],
    );
  }

  /// `Reset Progress`
  String get resetProgress {
    return Intl.message(
      'Reset Progress',
      name: 'resetProgress',
      desc: 'Reset progress button text',
      args: [],
    );
  }

  /// `Are you sure you want to reset your Umrah progress? This action cannot be undone.`
  String get resetProgressConfirmation {
    return Intl.message(
      'Are you sure you want to reset your Umrah progress? This action cannot be undone.',
      name: 'resetProgressConfirmation',
      desc: 'Reset progress confirmation message',
      args: [],
    );
  }

  /// `Reset`
  String get reset {
    return Intl.message(
      'Reset',
      name: 'reset',
      desc: 'Reset button text',
      args: [],
    );
  }

  /// `Cancel`
  String get cancel {
    return Intl.message(
      'Cancel',
      name: 'cancel',
      desc: 'Cancel button text',
      args: [],
    );
  }

  /// `Have you completed this step?`
  String get stepCompletedConfirmation {
    return Intl.message(
      'Have you completed this step?',
      name: 'stepCompletedConfirmation',
      desc: 'Step completion confirmation question',
      args: [],
    );
  }

  /// `Did you complete the {stepName} step?`
  String stepCompletedConfirmationMessage(String stepName) {
    return Intl.message(
      'Did you complete the $stepName step?',
      name: 'stepCompletedConfirmationMessage',
      desc: 'Step completion confirmation message with step name',
      args: [stepName],
    );
  }

  /// `Yes, I completed it`
  String get yesCompleted {
    return Intl.message(
      'Yes, I completed it',
      name: 'yesCompleted',
      desc: 'Yes, I completed the step button text',
      args: [],
    );
  }

  /// `No, not yet`
  String get noNotYet {
    return Intl.message(
      'No, not yet',
      name: 'noNotYet',
      desc: 'No, not yet button text',
      args: [],
    );
  }

  /// `Progress reset successfully`
  String get progressResetSuccessfully {
    return Intl.message(
      'Progress reset successfully',
      name: 'progressResetSuccessfully',
      desc: 'Progress reset success message',
      args: [],
    );
  }

  /// `Step marked as completed`
  String get stepMarkedAsCompleted {
    return Intl.message(
      'Step marked as completed',
      name: 'stepMarkedAsCompleted',
      desc: 'Step marked as completed success message',
      args: [],
    );
  }

  /// `Failed to save progress. Please try again.`
  String get failedToSaveProgress {
    return Intl.message(
      'Failed to save progress. Please try again.',
      name: 'failedToSaveProgress',
      desc: 'Failed to save progress error message',
      args: [],
    );
  }

  /// `Failed to reset progress. Please try again.`
  String get failedToResetProgress {
    return Intl.message(
      'Failed to reset progress. Please try again.',
      name: 'failedToResetProgress',
      desc: 'Failed to reset progress error message',
      args: [],
    );
  }

  /// `Hajj`
  String get hajj {
    return Intl.message('Hajj', name: 'hajj', desc: 'Hajj title', args: []);
  }

  /// `Umrah`
  String get umrah {
    return Intl.message('Umrah', name: 'umrah', desc: 'Umrah title', args: []);
  }

  /// `Hijj guidance`
  String get hijjGuidance {
    return Intl.message(
      'Hijj guidance',
      name: 'hijjGuidance',
      desc: 'Hijj guidance title',
      args: [],
    );
  }

  /// `Beginning`
  String get beginning {
    return Intl.message(
      'Beginning',
      name: 'beginning',
      desc: 'Beginning title',
      args: [],
    );
  }

  /// `Your Hajj Journey`
  String get yourHajjJourney {
    return Intl.message(
      'Your Hajj Journey',
      name: 'yourHajjJourney',
      desc: 'Your Hajj Journey title',
      args: [],
    );
  }

  /// `Hajj al-Ifrad`
  String get hajjAlIfradTitle {
    return Intl.message(
      'Hajj al-Ifrad',
      name: 'hajjAlIfradTitle',
      desc: 'Hajj al-Ifrad title',
      args: [],
    );
  }

  /// `You enter ihram with the intention of Hajj only, saying: “Labbaik Allahumma Hajjan” (O Allah, I respond to You for Hajj). You are **not required** to offer a sacrificial animal (hady) in this type of Hajj.\nHowever, if you wish to offer a **voluntary Hady**, you may do so —**<green>just make sure to arrange it in advance through a Hady coupon or an official authorized service.</green>**`
  String get hajjAlIfradDescription {
    return Intl.message(
      'You enter ihram with the intention of Hajj only, saying: “Labbaik Allahumma Hajjan” (O Allah, I respond to You for Hajj). You are **not required** to offer a sacrificial animal (hady) in this type of Hajj.\nHowever, if you wish to offer a **voluntary Hady**, you may do so —**<green>just make sure to arrange it in advance through a Hady coupon or an official authorized service.</green>**',
      name: 'hajjAlIfradDescription',
      desc: 'Hajj al-Ifrad description',
      args: [],
    );
  }

  /// `Hajj al-Qiran`
  String get hajjAlQiranTitle {
    return Intl.message(
      'Hajj al-Qiran',
      name: 'hajjAlQiranTitle',
      desc: 'Hajj al-Qiran title',
      args: [],
    );
  }

  /// `For those performing both Hajj and Umrah in one ihram. You make the intention for both together, saying: “Labbaik Allahumma Hajjan wa ‘Umrah” (O Allah, I respond to You for Hajj and Umrah). You remain in ihram until both are completed, and you perform the same actions as in Hajj al-Ifrad, but **you are required** to offer a sacrificial animal — **<green>so don’t forget to arrange it in advance through a Hady coupon or an authorized service.</green>**`
  String get hajjAlQiranDescription {
    return Intl.message(
      'For those performing both Hajj and Umrah in one ihram. You make the intention for both together, saying: “Labbaik Allahumma Hajjan wa ‘Umrah” (O Allah, I respond to You for Hajj and Umrah). You remain in ihram until both are completed, and you perform the same actions as in Hajj al-Ifrad, but **you are required** to offer a sacrificial animal — **<green>so don’t forget to arrange it in advance through a Hady coupon or an authorized service.</green>**',
      name: 'hajjAlQiranDescription',
      desc: 'Hajj al-Qiran description',
      args: [],
    );
  }

  /// `Hajj al-Tamattu`
  String get hajjAlTamattuTitle {
    return Intl.message(
      'Hajj al-Tamattu',
      name: 'hajjAlTamattuTitle',
      desc: 'Hajj al-Tamattu title',
      args: [],
    );
  }

  /// `You enter ihram for Umrah only, saying: “Labbaik Allahumma ‘Umrah” (O Allah, I respond to You for Umrah). You then perform your Umrah completely — by doing tawaf, sa’ee, trimming or shaving your hair, and exiting ihram. When the time for Hajj comes (on the 8th of Dhul Hijjah), you enter ihram again from Makkah for Hajj. This type is considered the best form of Hajj and **requires** a sacrificial animal (hady) — **<green>so don’t forget to arrange it in advance through a Hady coupon or an authorized service.</green>**\n\nThe time for entering Ihram for Hajj al-Tamattu is limited to the months of Hajj: Shawwal, Dhul Qadah, and the first ten days of Dhul Hijjah.`
  String get hajjAlTamattuDescription {
    return Intl.message(
      'You enter ihram for Umrah only, saying: “Labbaik Allahumma ‘Umrah” (O Allah, I respond to You for Umrah). You then perform your Umrah completely — by doing tawaf, sa’ee, trimming or shaving your hair, and exiting ihram. When the time for Hajj comes (on the 8th of Dhul Hijjah), you enter ihram again from Makkah for Hajj. This type is considered the best form of Hajj and **requires** a sacrificial animal (hady) — **<green>so don’t forget to arrange it in advance through a Hady coupon or an authorized service.</green>**\n\nThe time for entering Ihram for Hajj al-Tamattu is limited to the months of Hajj: Shawwal, Dhul Qadah, and the first ten days of Dhul Hijjah.',
      name: 'hajjAlTamattuDescription',
      desc: 'Hajj al-Tamattu description',
      args: [],
    );
  }

  /// `Completed`
  String get completed {
    return Intl.message(
      'Completed',
      name: 'completed',
      desc: 'Completed title',
      args: [],
    );
  }

  /// `Active`
  String get active {
    return Intl.message(
      'Active',
      name: 'active',
      desc: 'Active title',
      args: [],
    );
  }

  /// `Pending`
  String get pending {
    return Intl.message(
      'Pending',
      name: 'pending',
      desc: 'Pending title',
      args: [],
    );
  }

  /// `None`
  String get none {
    return Intl.message('None', name: 'none', desc: 'None title', args: []);
  }

  /// `Ninth Dhul Hijjah`
  String get ninthDhulHijjah {
    return Intl.message(
      'Ninth Dhul Hijjah',
      name: 'ninthDhulHijjah',
      desc: 'Ninth Dhul Hijjah title',
      args: [],
    );
  }

  /// `Tenth Dhul Hijjah`
  String get tenthDhulHijjah {
    return Intl.message(
      'Tenth Dhul Hijjah',
      name: 'tenthDhulHijjah',
      desc: 'Tenth Dhul Hijjah title',
      args: [],
    );
  }

  /// `Tenth To Twelfth Dhul Hijjah`
  String get tenthToTwelfthDhulHijjah {
    return Intl.message(
      'Tenth To Twelfth Dhul Hijjah',
      name: 'tenthToTwelfthDhulHijjah',
      desc: 'Tenth To Twelfth Dhul Hijjah title',
      args: [],
    );
  }

  /// `Day 1`
  String get day1 {
    return Intl.message('Day 1', name: 'day1', desc: 'Day 1 title', args: []);
  }

  /// `Day 2`
  String get day2 {
    return Intl.message('Day 2', name: 'day2', desc: 'Day 2 title', args: []);
  }

  /// `Day 3 To 5`
  String get day3To5 {
    return Intl.message(
      'Day 3 To 5',
      name: 'day3To5',
      desc: 'Day 3 To 5 title',
      args: [],
    );
  }

  /// `Day of Arafah`
  String get dayOfArafah {
    return Intl.message(
      'Day of Arafah',
      name: 'dayOfArafah',
      desc: 'Day of Arafah title',
      args: [],
    );
  }

  /// `Day of Nahr`
  String get dayOfNahr {
    return Intl.message(
      'Day of Nahr',
      name: 'dayOfNahr',
      desc: 'Day of Nahr title',
      args: [],
    );
  }

  /// `Days of Tashreeq`
  String get daysOfTashreeq {
    return Intl.message(
      'Days of Tashreeq',
      name: 'daysOfTashreeq',
      desc: 'Days of Tashreeq title',
      args: [],
    );
  }

  /// `Day of Tarwiyah`
  String get dayOfTarwiyah {
    return Intl.message(
      'Day of Tarwiyah',
      name: 'dayOfTarwiyah',
      desc: 'Day of Tarwiyah title',
      args: [],
    );
  }

  /// `Eighth Dhul Hijjah`
  String get eighthDhulHijjah {
    return Intl.message(
      'Eighth Dhul Hijjah',
      name: 'eighthDhulHijjah',
      desc: 'Eighth Dhul Hijjah title',
      args: [],
    );
  }

  /// `On the **Day of Tarwiyah**, you will enter ihram, perform Tawaf al-Qudum, then head to Mina to spend the night there both **Sunnah practices of The Prophet ﷺ**.`
  String get hajjDay8Description {
    return Intl.message(
      'On the **Day of Tarwiyah**, you will enter ihram, perform Tawaf al-Qudum, then head to Mina to spend the night there both **Sunnah practices of The Prophet ﷺ**.',
      name: 'hajjDay8Description',
      desc: '',
      args: [],
    );
  }

  /// `On the **Day of Arafah** you will go from Mina to Arafah after sunrise, make duaa, and pray Dhuhr and Asr shortened and combined. You will stay there until sunset. After sunset, you will head to Muzdalifah, pray Maghrib and 'Isha together, rest, and collect your pebbles for Rami.`
  String get hajjDay9Description {
    return Intl.message(
      'On the **Day of Arafah** you will go from Mina to Arafah after sunrise, make duaa, and pray Dhuhr and Asr shortened and combined. You will stay there until sunset. After sunset, you will head to Muzdalifah, pray Maghrib and \'Isha together, rest, and collect your pebbles for Rami.',
      name: 'hajjDay9Description',
      desc: '',
      args: [],
    );
  }

  /// `On the **Day of Nahr**, you will go to Mina to stone Jamrat al-Aqabah, offer your Hady, perform Tawaf al-Ifadah, and exit Ihram (Tahallul). After this, you return to Mina to spend the Nights of Tashreeq. **This sequence is the preferred Sunnah order, though the steps may be done in a different order if needed**, as The Prophet ﷺ said: 'No one was asked on that day about what they did first or last except that he said: Do it, and there is no harm.'`
  String get hajjDay10Description {
    return Intl.message(
      'On the **Day of Nahr**, you will go to Mina to stone Jamrat al-Aqabah, offer your Hady, perform Tawaf al-Ifadah, and exit Ihram (Tahallul). After this, you return to Mina to spend the Nights of Tashreeq. **This sequence is the preferred Sunnah order, though the steps may be done in a different order if needed**, as The Prophet ﷺ said: \'No one was asked on that day about what they did first or last except that he said: Do it, and there is no harm.\'',
      name: 'hajjDay10Description',
      desc: '',
      args: [],
    );
  }

  /// `On the **Days of Tashreeq**, you will stone the three Jamarat after midday. At the end of Hajj, you will perform Tawaf al-Wada' before departing.`
  String get hajjDay11_13Description {
    return Intl.message(
      'On the **Days of Tashreeq**, you will stone the three Jamarat after midday. At the end of Hajj, you will perform Tawaf al-Wada\' before departing.',
      name: 'hajjDay11_13Description',
      desc: '',
      args: [],
    );
  }

  /// `Ihram`
  String get hajjStepIhram {
    return Intl.message('Ihram', name: 'hajjStepIhram', desc: '', args: []);
  }

  /// `Tawaf al-Qudum`
  String get hajjStepTawafAlQudum {
    return Intl.message(
      'Tawaf al-Qudum',
      name: 'hajjStepTawafAlQudum',
      desc: '',
      args: [],
    );
  }

  /// `Mina`
  String get hajjStepMina {
    return Intl.message('Mina', name: 'hajjStepMina', desc: '', args: []);
  }

  /// `Arafat`
  String get hajjStepArafat {
    return Intl.message('Arafat', name: 'hajjStepArafat', desc: '', args: []);
  }

  /// `Muzdalifah`
  String get hajjStepMuzdalifah {
    return Intl.message(
      'Muzdalifah',
      name: 'hajjStepMuzdalifah',
      desc: '',
      args: [],
    );
  }

  /// `Al-Hady`
  String get hajjStepAlHady {
    return Intl.message('Al-Hady', name: 'hajjStepAlHady', desc: '', args: []);
  }

  /// `Tahallul Awwal & Thani`
  String get hajjStepTahallul {
    return Intl.message(
      'Tahallul Awwal & Thani',
      name: 'hajjStepTahallul',
      desc: '',
      args: [],
    );
  }

  /// `Tawaf al-Ifadah`
  String get hajjStepTawafAlIfadah {
    return Intl.message(
      'Tawaf al-Ifadah',
      name: 'hajjStepTawafAlIfadah',
      desc: '',
      args: [],
    );
  }

  /// `Staying in Mina`
  String get hajjStepStayingInMina {
    return Intl.message(
      'Staying in Mina',
      name: 'hajjStepStayingInMina',
      desc: '',
      args: [],
    );
  }

  /// `Jamarat`
  String get hajjStepJamarat {
    return Intl.message('Jamarat', name: 'hajjStepJamarat', desc: '', args: []);
  }

  /// `Tawaf al-Wada'`
  String get hajjStepTawafAlWada {
    return Intl.message(
      'Tawaf al-Wada\'',
      name: 'hajjStepTawafAlWada',
      desc: '',
      args: [],
    );
  }

  /// `It is Sunnah to enter the state of ihram on the Day of Tarwiyah from the place specified by Islamic law. However, it may also be done **earlier or postponed until reaching Arafah** – both are permissible according to one's situation. When entering Ihram, a Muslim must avoid all the prohibitions that apply during this sacred state.`
  String get hajjStepIhramDescription {
    return Intl.message(
      'It is Sunnah to enter the state of ihram on the Day of Tarwiyah from the place specified by Islamic law. However, it may also be done **earlier or postponed until reaching Arafah** – both are permissible according to one\'s situation. When entering Ihram, a Muslim must avoid all the prohibitions that apply during this sacred state.',
      name: 'hajjStepIhramDescription',
      desc: '',
      args: [],
    );
  }

  /// `When **The Prophet ﷺ** arrived in Makkah he performed Tawaf al-Qudum, it is Sunnah. After this tawaf, the Sa'ee may be performed immediately or postponed until after Tawaf al-Ifadah, but **The Prophet ﷺ** performed Sa'ee right after Tawaf al-Qudum.\n\nPerform **seven counter-clockwise circuits around the Kaaba**, beginning at the Hajar al-Aswad (Black Stone) and completing each round by returning to the same point, **while remaining in a state of wuduu.**\n\n**After completing the Tawaf**, perform two rak'ahs of prayer. You may pray anywhere in the mosque, though it is recommended to pray behind Maqam Ibrahim if possible.`
  String get hajjStepTawafAlQudumDescription {
    return Intl.message(
      'When **The Prophet ﷺ** arrived in Makkah he performed Tawaf al-Qudum, it is Sunnah. After this tawaf, the Sa\'ee may be performed immediately or postponed until after Tawaf al-Ifadah, but **The Prophet ﷺ** performed Sa\'ee right after Tawaf al-Qudum.\n\nPerform **seven counter-clockwise circuits around the Kaaba**, beginning at the Hajar al-Aswad (Black Stone) and completing each round by returning to the same point, **while remaining in a state of wuduu.**\n\n**After completing the Tawaf**, perform two rak\'ahs of prayer. You may pray anywhere in the mosque, though it is recommended to pray behind Maqam Ibrahim if possible.',
      name: 'hajjStepTawafAlQudumDescription',
      desc: '',
      args: [],
    );
  }

  /// `You should head to Mina at dawn on the 8th day of Dhul-Hijjah and **stay there in your allocated tent until the dawn of the 9th day.** The Prophet ﷺ **used to:** Spend the night in Mina on the Day of Tarwiyah, it is a Sunnah, not an obligation. If you choose to go directly to Arafah on the 9th day, you are allowed to do so.\n\nHere you will pray: Dhuhr, Asr, Maghrib, 'Isha, and Fajr, **shortening your four-unit prayers to two units each (qasr), <red>without combining them (jam')</red>**, following how the Prophet ﷺ performed these prayers on the 8th of Dhul-Hijjah in Mina.`
  String get hajjStepMinaDescription {
    return Intl.message(
      'You should head to Mina at dawn on the 8th day of Dhul-Hijjah and **stay there in your allocated tent until the dawn of the 9th day.** The Prophet ﷺ **used to:** Spend the night in Mina on the Day of Tarwiyah, it is a Sunnah, not an obligation. If you choose to go directly to Arafah on the 9th day, you are allowed to do so.\n\nHere you will pray: Dhuhr, Asr, Maghrib, \'Isha, and Fajr, **shortening your four-unit prayers to two units each (qasr), <red>without combining them (jam\')</red>**, following how the Prophet ﷺ performed these prayers on the 8th of Dhul-Hijjah in Mina.',
      name: 'hajjStepMinaDescription',
      desc: '',
      args: [],
    );
  }

  /// `The Day of 'Arafah is **one of the most important days** for Muslims around the world. Allah (SWT) refers to this day in Surah Al-Ma'idah as the day on which He perfected His religion, completed His favors upon the Prophet Muhammad ﷺ , and approved Islam as a way of life.\n\n**The Prophet ﷺ said:** "There is no day on which Allah frees more people from the Fire than the Day of 'Arafah. He draws close to them, then He says to the angels: 'What are these people seeking?'" (Hadith, Muslim).`
  String get hajjStepArafatDescription {
    return Intl.message(
      'The Day of \'Arafah is **one of the most important days** for Muslims around the world. Allah (SWT) refers to this day in Surah Al-Ma\'idah as the day on which He perfected His religion, completed His favors upon the Prophet Muhammad ﷺ , and approved Islam as a way of life.\n\n**The Prophet ﷺ said:** "There is no day on which Allah frees more people from the Fire than the Day of \'Arafah. He draws close to them, then He says to the angels: \'What are these people seeking?\'" (Hadith, Muslim).',
      name: 'hajjStepArafatDescription',
      desc: '',
      args: [],
    );
  }

  /// `You should head to Arafah, pray **Dhuhr and Asr together**, performing Asr early along with Dhuhr (Jam' Taqdim).`
  String get hajjStepArafatSubStep1 {
    return Intl.message(
      'You should head to Arafah, pray **Dhuhr and Asr together**, performing Asr early along with Dhuhr (Jam\' Taqdim).',
      name: 'hajjStepArafatSubStep1',
      desc: '',
      args: [],
    );
  }

  /// `On this day, the official Khutbah of 'Arafah will be delivered **from Masjid al-Nimrah**. Try to listen to the sermon if possible. Your group may also facilitate an English translation.`
  String get hajjStepArafatSubStep2 {
    return Intl.message(
      'On this day, the official Khutbah of \'Arafah will be delivered **from Masjid al-Nimrah**. Try to listen to the sermon if possible. Your group may also facilitate an English translation.',
      name: 'hajjStepArafatSubStep2',
      desc: '',
      args: [],
    );
  }

  /// `You should remain in **Arafah until sunset**.`
  String get hajjStepArafatSubStep3 {
    return Intl.message(
      'You should remain in **Arafah until sunset**.',
      name: 'hajjStepArafatSubStep3',
      desc: '',
      args: [],
    );
  }

  /// `**Dedicate this entire day to worship and supplication.** Stand on the plains of 'Arafah, focus your heart on Allah, and make plenty of duaa. **Ask for forgiveness, mercy, and blessings for yourself, your family, and all Muslims.**`
  String get hajjStepArafatSubStep4 {
    return Intl.message(
      '**Dedicate this entire day to worship and supplication.** Stand on the plains of \'Arafah, focus your heart on Allah, and make plenty of duaa. **Ask for forgiveness, mercy, and blessings for yourself, your family, and all Muslims.**',
      name: 'hajjStepArafatSubStep4',
      desc: '',
      args: [],
    );
  }

  /// `Try to recite comprehensive prophetic supplications, as **The Prophet ﷺ said:**\n"The best supplication is the supplication on the Day of Arafah, and the best of what I and the prophets before me have said is: **La ilaha illallahu wahdahu la sharika lahu, lahul-mulku wa lahul-hamdu, yuhyi wa yumitu, wa huwa 'ala kulli shay'in qadir.**`
  String get hajjStepArafatSubStep5 {
    return Intl.message(
      'Try to recite comprehensive prophetic supplications, as **The Prophet ﷺ said:**\n"The best supplication is the supplication on the Day of Arafah, and the best of what I and the prophets before me have said is: **La ilaha illallahu wahdahu la sharika lahu, lahul-mulku wa lahul-hamdu, yuhyi wa yumitu, wa huwa \'ala kulli shay\'in qadir.**',
      name: 'hajjStepArafatSubStep5',
      desc: '',
      args: [],
    );
  }

  /// `After sunset, leave Arafah and head to Muzdalifah. Upon arrival, pray Maghrib and Isha combined (delayed). Pray Maghrib as three Rak'ahs as usual, then Isha as two Rak'ahs. Abdullah bin Umar (may Allah be pleased with them) said: 'The Prophet ﷺ combined Maghrib and Isha in Muzdalifah, with one Iqamah for each, and did not pray anything between them or after them.'`
  String get hajjStepMuzdalifahDescription {
    return Intl.message(
      'After sunset, leave Arafah and head to Muzdalifah. Upon arrival, pray Maghrib and Isha combined (delayed). Pray Maghrib as three Rak\'ahs as usual, then Isha as two Rak\'ahs. Abdullah bin Umar (may Allah be pleased with them) said: \'The Prophet ﷺ combined Maghrib and Isha in Muzdalifah, with one Iqamah for each, and did not pray anything between them or after them.\'',
      name: 'hajjStepMuzdalifahDescription',
      desc: '',
      args: [],
    );
  }

  /// `You can collect pebbles for Jamarat (stoning in the following days of Hajj). It is recommended that the pebbles be small, about the size of a date stone. You will need:\n• 49 pebbles if you stay in Mina for only two days.\n• 70 pebbles if you stay in Mina for three days.\nIt is recommended to collect some extra pebbles in case you miss the target. You can also collect pebbles later from Mina if you wish.`
  String get hajjStepMuzdalifahSubStep1 {
    return Intl.message(
      'You can collect pebbles for Jamarat (stoning in the following days of Hajj). It is recommended that the pebbles be small, about the size of a date stone. You will need:\n• 49 pebbles if you stay in Mina for only two days.\n• 70 pebbles if you stay in Mina for three days.\nIt is recommended to collect some extra pebbles in case you miss the target. You can also collect pebbles later from Mina if you wish.',
      name: 'hajjStepMuzdalifahSubStep1',
      desc: '',
      args: [],
    );
  }

  /// `You can collect pebbles for Jamarat (stoning in the following days of Hajj). It is recommended that the pebbles be small, about the size of a date stone. You will need:\n• 49 pebbles if you stay in Mina for only two days.\n• 70 pebbles if you stay in Mina for three days.\nIt is recommended to collect some extra pebbles in case you miss the target. You can also collect pebbles later from Mina if you wish.`
  String get hajjStepMuzdalifahSubStep2 {
    return Intl.message(
      'You can collect pebbles for Jamarat (stoning in the following days of Hajj). It is recommended that the pebbles be small, about the size of a date stone. You will need:\n• 49 pebbles if you stay in Mina for only two days.\n• 70 pebbles if you stay in Mina for three days.\nIt is recommended to collect some extra pebbles in case you miss the target. You can also collect pebbles later from Mina if you wish.',
      name: 'hajjStepMuzdalifahSubStep2',
      desc: '',
      args: [],
    );
  }

  /// `Stay overnight in Muzdalifah. You can rest or engage in dhikr and worship quietly. The Prophet ﷺ slept in Muzdalifah until shortly before Fajr. So ensure you get good rest in preparation for the important day ahead.\n\nIt is permissible for pilgrims to leave Muzdalifah after midnight, as the Prophet ﷺ permitted women and the weak. For men not accompanying families, it is better to stay until Fajr prayer.`
  String get hajjStepMuzdalifahSubStep3 {
    return Intl.message(
      'Stay overnight in Muzdalifah. You can rest or engage in dhikr and worship quietly. The Prophet ﷺ slept in Muzdalifah until shortly before Fajr. So ensure you get good rest in preparation for the important day ahead.\n\nIt is permissible for pilgrims to leave Muzdalifah after midnight, as the Prophet ﷺ permitted women and the weak. For men not accompanying families, it is better to stay until Fajr prayer.',
      name: 'hajjStepMuzdalifahSubStep3',
      desc: '',
      args: [],
    );
  }

  /// `Depart Muzdalifah and go back towards Mina. Remember to continuously recite the Talbiyah.`
  String get hajjStepMinaJamratAlAqabahDescription {
    return Intl.message(
      'Depart Muzdalifah and go back towards Mina. Remember to continuously recite the Talbiyah.',
      name: 'hajjStepMinaJamratAlAqabahDescription',
      desc: '',
      args: [],
    );
  }

  /// `When you arrive to Mina, collect 7 small pebbles, about the size of date stones. It's recommended to carry a few extra in case one falls or misses the target — it's better to have more than to run short. **If you already collected yours in Muzdalifah, you will not need to collect any more here.**`
  String get hajjStepMinaJamratAlAqabahSubStep1 {
    return Intl.message(
      'When you arrive to Mina, collect 7 small pebbles, about the size of date stones. It\'s recommended to carry a few extra in case one falls or misses the target — it\'s better to have more than to run short. **If you already collected yours in Muzdalifah, you will not need to collect any more here.**',
      name: 'hajjStepMinaJamratAlAqabahSubStep1',
      desc: '',
      args: [],
    );
  }

  /// `Walk toward Jamarat al-Aqabah, the largest pillar. Today, you will only stone this one pillar.`
  String get hajjStepMinaJamratAlAqabahSubStep2 {
    return Intl.message(
      'Walk toward Jamarat al-Aqabah, the largest pillar. Today, you will only stone this one pillar.',
      name: 'hajjStepMinaJamratAlAqabahSubStep2',
      desc: '',
      args: [],
    );
  }

  /// `Throw seven pebbles, one at a time, saying "Allahu Akbar" with each throw and making sure each pebble lands inside the stoning area.\n\n**Do not rush to perform Rami.** The Hajj authorities often assign specific time slots for groups to reduce overcrowding and maintain safety. Follow your group's schedule.\n\n**<red>Do not throw sandals or valuables out of anger</red>** – the pillar does not contain Shaytan, and harming your belongings has no benefit.`
  String get hajjStepMinaJamratAlAqabahSubStep3 {
    return Intl.message(
      'Throw seven pebbles, one at a time, saying "Allahu Akbar" with each throw and making sure each pebble lands inside the stoning area.\n\n**Do not rush to perform Rami.** The Hajj authorities often assign specific time slots for groups to reduce overcrowding and maintain safety. Follow your group\'s schedule.\n\n**<red>Do not throw sandals or valuables out of anger</red>** – the pillar does not contain Shaytan, and harming your belongings has no benefit.',
      name: 'hajjStepMinaJamratAlAqabahSubStep3',
      desc: '',
      args: [],
    );
  }

  /// `The sacrificial offering (Hady) is **required for pilgrims performing Hajj Tamattu' or Hajj Qiran.** Those performing Hajj al-Ifrad are **not obligated** to offer the hady but are highly recommended to do so. The sacrifice for those who are required to do it must be performed **between the 10th, and 13th** of Dhul Hijjah, after stoning the pillars. If done on the 13th, it must be completed before sunset.`
  String get hajjStepAlHadyDescription {
    return Intl.message(
      'The sacrificial offering (Hady) is **required for pilgrims performing Hajj Tamattu\' or Hajj Qiran.** Those performing Hajj al-Ifrad are **not obligated** to offer the hady but are highly recommended to do so. The sacrifice for those who are required to do it must be performed **between the 10th, and 13th** of Dhul Hijjah, after stoning the pillars. If done on the 13th, it must be completed before sunset.',
      name: 'hajjStepAlHadyDescription',
      desc: '',
      args: [],
    );
  }

  /// `After you complete **Rami al-Aqabah**, your Hady will be slaughtered on your behalf through the service you arranged. If you used a coupon or an official program, the sacrifice is carried out automatically, and you may receive a confirmation message. **<red>You do not need to be present at the slaughter site,</red>** as the entire process is handled for you.`
  String get hajjStepAlHadySubStep1 {
    return Intl.message(
      'After you complete **Rami al-Aqabah**, your Hady will be slaughtered on your behalf through the service you arranged. If you used a coupon or an official program, the sacrifice is carried out automatically, and you may receive a confirmation message. **<red>You do not need to be present at the slaughter site,</red>** as the entire process is handled for you.',
      name: 'hajjStepAlHadySubStep1',
      desc: '',
      args: [],
    );
  }

  /// `Once your sacrifice is completed, the meat is distributed to the poor and needy. **The official Hady program manages this distribution** so that it reaches those who need it most. **<red>You are not required to collect or handle any of the meat yourself.</red>**`
  String get hajjStepAlHadySubStep2 {
    return Intl.message(
      'Once your sacrifice is completed, the meat is distributed to the poor and needy. **The official Hady program manages this distribution** so that it reaches those who need it most. **<red>You are not required to collect or handle any of the meat yourself.</red>**',
      name: 'hajjStepAlHadySubStep2',
      desc: '',
      args: [],
    );
  }

  /// `During Hajj, pilgrims **exit the state of ihram** in two stages: **Tahallul Awwal** (the first release) and **Tahallul Thani** (the final release). Each stage becomes valid after completing specific rites of the Day of 'Eid. Understanding these two levels helps the pilgrim know **what becomes permissible at each point** and when full release from ihram is achieved.`
  String get hajjStepTahallulDescription {
    return Intl.message(
      'During Hajj, pilgrims **exit the state of ihram** in two stages: **Tahallul Awwal** (the first release) and **Tahallul Thani** (the final release). Each stage becomes valid after completing specific rites of the Day of \'Eid. Understanding these two levels helps the pilgrim know **what becomes permissible at each point** and when full release from ihram is achieved.',
      name: 'hajjStepTahallulDescription',
      desc: '',
      args: [],
    );
  }

  /// `**Tahallul Awwal** happens when you **complete any two** of the following three actions on the Day of 'Eid (10th of Dhul Hijjah):\n• Stoning Jamarat al-'Aqabah\n• Shaving or trimming your hair\n• Performing Tawaf al-Ifadah and Sa'i (if Sa'i is required)\n\nThis means that if you:\n• stone **and** shave, or\n• stone **and** perform Tawaf/Sa'i, or\n• perform Tawaf/Sa'i **and** shave,\n**you will enter Tahallul Awwal.**\n\nAfter this first release, **you may wear normal clothes, apply perfume, and resume all normal activities—<red>except marital relations, which remain prohibited until you complete Tahallul Thani.</red>**\n\n**This is supported by narrations such as the hadith from Aisha (RA), where the Prophet ﷺ said:** "When he [the pilgrim] has thrown the Jamrah and shaved his head, then everything becomes lawful for him except women." (Hadith, Bukhari)`
  String get hajjStepTahallulSubStep1 {
    return Intl.message(
      '**Tahallul Awwal** happens when you **complete any two** of the following three actions on the Day of \'Eid (10th of Dhul Hijjah):\n• Stoning Jamarat al-\'Aqabah\n• Shaving or trimming your hair\n• Performing Tawaf al-Ifadah and Sa\'i (if Sa\'i is required)\n\nThis means that if you:\n• stone **and** shave, or\n• stone **and** perform Tawaf/Sa\'i, or\n• perform Tawaf/Sa\'i **and** shave,\n**you will enter Tahallul Awwal.**\n\nAfter this first release, **you may wear normal clothes, apply perfume, and resume all normal activities—<red>except marital relations, which remain prohibited until you complete Tahallul Thani.</red>**\n\n**This is supported by narrations such as the hadith from Aisha (RA), where the Prophet ﷺ said:** "When he [the pilgrim] has thrown the Jamrah and shaved his head, then everything becomes lawful for him except women." (Hadith, Bukhari)',
      name: 'hajjStepTahallulSubStep1',
      desc: '',
      args: [],
    );
  }

  /// `**Tahallul Thani** occurs when you complete **all three actions**:\n• stoning Jamarat al-'Aqabah,\n• shaving or trimming,\n• and performing Tawaf al-Ifadah with Sa'i (if required).\n\nOnce these are done, the pilgrim achieves **full release** from ihram, and **everything—including marital relations—becomes permissible.**\n\n**This is the complete exit from Ihram** and fulfills all the main rites of the Day of Sacrifice following the practice of the Prophet ﷺ, who stoned, then sacrificed, then shaved, after which 'Aishah (RA) perfumed him — indicating he had completed his full release.`
  String get hajjStepTahallulSubStep2 {
    return Intl.message(
      '**Tahallul Thani** occurs when you complete **all three actions**:\n• stoning Jamarat al-\'Aqabah,\n• shaving or trimming,\n• and performing Tawaf al-Ifadah with Sa\'i (if required).\n\nOnce these are done, the pilgrim achieves **full release** from ihram, and **everything—including marital relations—becomes permissible.**\n\n**This is the complete exit from Ihram** and fulfills all the main rites of the Day of Sacrifice following the practice of the Prophet ﷺ, who stoned, then sacrificed, then shaved, after which \'Aishah (RA) perfumed him — indicating he had completed his full release.',
      name: 'hajjStepTahallulSubStep2',
      desc: '',
      args: [],
    );
  }

  /// `Head to the Haram to perform Tawaf al-Ifadah`
  String get hajjStepTawafAlIfadahDescription {
    return Intl.message(
      'Head to the Haram to perform Tawaf al-Ifadah',
      name: 'hajjStepTawafAlIfadahDescription',
      desc: '',
      args: [],
    );
  }

  /// `Perform tawaf by completing 7 circuits around the Kaaba.`
  String get hajjStepTawafAlIfadahSubStep1 {
    return Intl.message(
      'Perform tawaf by completing 7 circuits around the Kaaba.',
      name: 'hajjStepTawafAlIfadahSubStep1',
      desc: '',
      args: [],
    );
  }

  /// `After completing the tawaf, pray two rak'ahs behind Maqam Ibrahim, if possible.`
  String get hajjStepTawafAlIfadahSubStep2 {
    return Intl.message(
      'After completing the tawaf, pray two rak\'ahs behind Maqam Ibrahim, if possible.',
      name: 'hajjStepTawafAlIfadahSubStep2',
      desc: '',
      args: [],
    );
  }

  /// `Perform Sa'ee if you have not done it earlier. **If you already performed Sa'ee with Tawaf al-Qudum, you do not need to repeat it.**`
  String get hajjStepTawafAlIfadahSubStep3 {
    return Intl.message(
      'Perform Sa\'ee if you have not done it earlier. **If you already performed Sa\'ee with Tawaf al-Qudum, you do not need to repeat it.**',
      name: 'hajjStepTawafAlIfadahSubStep3',
      desc: '',
      args: [],
    );
  }

  /// `After completing Tawaf al-Ifadah, you should return to Mina to spend the nights of Tashreeq and stone the three Jamarat.`
  String get hajjStepStayingInMinaDescription {
    return Intl.message(
      'After completing Tawaf al-Ifadah, you should return to Mina to spend the nights of Tashreeq and stone the three Jamarat.',
      name: 'hajjStepStayingInMinaDescription',
      desc: '',
      args: [],
    );
  }

  /// `The overnight stay in Mina during these days starts from the evening of the 10th (the night of the 11th) until the evening of the 12th (the night of the 13th) of Dhul-Hijjah.`
  String get hajjStepStayingInMinaSubStep1 {
    return Intl.message(
      'The overnight stay in Mina during these days starts from the evening of the 10th (the night of the 11th) until the evening of the 12th (the night of the 13th) of Dhul-Hijjah.',
      name: 'hajjStepStayingInMinaSubStep1',
      desc: '',
      args: [],
    );
  }

  /// `During the Days of Tashreeq, it is Sunnah to frequently recite Takbeer, especially after the obligatory prayers.`
  String get hajjStepStayingInMinaSubStep2 {
    return Intl.message(
      'During the Days of Tashreeq, it is Sunnah to frequently recite Takbeer, especially after the obligatory prayers.',
      name: 'hajjStepStayingInMinaSubStep2',
      desc: '',
      args: [],
    );
  }

  /// `Stoning the Jamarat is performed on the days of Tashreeq (11th, 12th, and 13th). It involves throwing seven pebbles at each of the three pillars (Jamarat) starting from the Small, then Middle, then Large (Aqabah).`
  String get hajjStepJamaratDescription {
    return Intl.message(
      'Stoning the Jamarat is performed on the days of Tashreeq (11th, 12th, and 13th). It involves throwing seven pebbles at each of the three pillars (Jamarat) starting from the Small, then Middle, then Large (Aqabah).',
      name: 'hajjStepJamaratDescription',
      desc: 'Description for Jamarat step',
      args: [],
    );
  }

  /// `Collect 21 small pebbles, about the size of date stones. It's recommended to carry a few extra in case one falls or misses the target — it's better to have more than to run short.\n**If you already collected yours in Muzdalifah, you will not need to collect any more here.**`
  String get hajjStepJamaratSubStep1 {
    return Intl.message(
      'Collect 21 small pebbles, about the size of date stones. It\'s recommended to carry a few extra in case one falls or misses the target — it\'s better to have more than to run short.\n**If you already collected yours in Muzdalifah, you will not need to collect any more here.**',
      name: 'hajjStepJamaratSubStep1',
      desc: '',
      args: [],
    );
  }

  /// `**After the sun passes the zenith** (after Zawal), head toward the Jamarat.\nContinue making thikr and reciting the Talbiyah until you begin stoning.\n\nIt is permissible to perform the stoning before zawal on this day in cases of severe crowding. You may follow this opinion **if there is extreme congestion** at the Jamarat.`
  String get hajjStepJamaratSubStep2 {
    return Intl.message(
      '**After the sun passes the zenith** (after Zawal), head toward the Jamarat.\nContinue making thikr and reciting the Talbiyah until you begin stoning.\n\nIt is permissible to perform the stoning before zawal on this day in cases of severe crowding. You may follow this opinion **if there is extreme congestion** at the Jamarat.',
      name: 'hajjStepJamaratSubStep2',
      desc: '',
      args: [],
    );
  }

  /// `First start with the smallest Jamarah (closest to Masjid al-Khif).\nThrow 7 small pebbles, one at a time, saying "Allahu Akbar" with each throw and ensuring each pebble lands in the stoning area.\n\n<gold>After stoning, move slightly forward, face the Qiblah, keep the Jamarah on your left, and make a long du'aa.</gold>`
  String get hajjStepJamaratSubStep3 {
    return Intl.message(
      'First start with the smallest Jamarah (closest to Masjid al-Khif).\nThrow 7 small pebbles, one at a time, saying "Allahu Akbar" with each throw and ensuring each pebble lands in the stoning area.\n\n<gold>After stoning, move slightly forward, face the Qiblah, keep the Jamarah on your left, and make a long du\'aa.</gold>',
      name: 'hajjStepJamaratSubStep3',
      desc: '',
      args: [],
    );
  }

  /// `Then Proceed to the second Jamarah (the middle pillar).\nThrow 7 pebbles, one at a time, saying "Allahu Akbar" with each throw.\n\n<gold>After stoning, move aside, face the Qiblah, keep the Jamarah on your right, and make a long du'aa.</gold>`
  String get hajjStepJamaratSubStep4 {
    return Intl.message(
      'Then Proceed to the second Jamarah (the middle pillar).\nThrow 7 pebbles, one at a time, saying "Allahu Akbar" with each throw.\n\n<gold>After stoning, move aside, face the Qiblah, keep the Jamarah on your right, and make a long du\'aa.</gold>',
      name: 'hajjStepJamaratSubStep4',
      desc: '',
      args: [],
    );
  }

  /// `Then move to the third Jamarah (Jamarat al-'Aqabah).\nThrow 7 pebbles, one at a time, saying "Allahu Akbar" with each throw.\n\n**There is no du'ā after the third Jamarah, continue moving forward with the crowd.**`
  String get hajjStepJamaratSubStep5 {
    return Intl.message(
      'Then move to the third Jamarah (Jamarat al-\'Aqabah).\nThrow 7 pebbles, one at a time, saying "Allahu Akbar" with each throw.\n\n**There is no du\'ā after the third Jamarah, continue moving forward with the crowd.**',
      name: 'hajjStepJamaratSubStep5',
      desc: '',
      args: [],
    );
  }

  /// `Repeat this same process on each day (the 11th and the 12th, and also the 13th if you stay for the extra day).\n\n<red>Do not rush to perform Rami. The Hajj authorities often assign specific time slots for groups to reduce overcrowding and maintain safety. Follow your group's schedule.</red>\n\n<red>Do not throw sandals or valuables out of anger — the pillar does not contain Shaytan, and harming your belongings has no benefit.</red>\n\n**If you wish to leave Mina early (on the 12th of Dhul Hijjah), you must depart before sunset.** If sunset occurs and you are still in Mina, then **you must stay overnight and perform the stoning the next day.**`
  String get hajjStepJamaratSubStep6 {
    return Intl.message(
      'Repeat this same process on each day (the 11th and the 12th, and also the 13th if you stay for the extra day).\n\n<red>Do not rush to perform Rami. The Hajj authorities often assign specific time slots for groups to reduce overcrowding and maintain safety. Follow your group\'s schedule.</red>\n\n<red>Do not throw sandals or valuables out of anger — the pillar does not contain Shaytan, and harming your belongings has no benefit.</red>\n\n**If you wish to leave Mina early (on the 12th of Dhul Hijjah), you must depart before sunset.** If sunset occurs and you are still in Mina, then **you must stay overnight and perform the stoning the next day.**',
      name: 'hajjStepJamaratSubStep6',
      desc: '',
      args: [],
    );
  }

  /// `This is the final act of your Hajj journey. You should perform Tawaf al-Wada' and then depart directly afterward. Performing Tawaf al-Wada' is obligatory — **<red>if you skip it</red>**, you must offer a sacrificial animal. If a woman begins her menstrual period, she is excused from performing the Farewell Tawaf.`
  String get hajjStepTawafAlWadaDescription {
    return Intl.message(
      'This is the final act of your Hajj journey. You should perform Tawaf al-Wada\' and then depart directly afterward. Performing Tawaf al-Wada\' is obligatory — **<red>if you skip it</red>**, you must offer a sacrificial animal. If a woman begins her menstrual period, she is excused from performing the Farewell Tawaf.',
      name: 'hajjStepTawafAlWadaDescription',
      desc: '',
      args: [],
    );
  }

  /// `Perform the Farewell Tawaf (7 circuits).`
  String get hajjStepTawafAlWadaSubStep1 {
    return Intl.message(
      'Perform the Farewell Tawaf (7 circuits).',
      name: 'hajjStepTawafAlWadaSubStep1',
      desc: '',
      args: [],
    );
  }

  /// `Pray two rak'ahs behind Maqam Ibrahim.`
  String get hajjStepTawafAlWadaSubStep2 {
    return Intl.message(
      'Pray two rak\'ahs behind Maqam Ibrahim.',
      name: 'hajjStepTawafAlWadaSubStep2',
      desc: '',
      args: [],
    );
  }

  /// `Drink Zamzam water.`
  String get hajjStepTawafAlWadaSubStep3 {
    return Intl.message(
      'Drink Zamzam water.',
      name: 'hajjStepTawafAlWadaSubStep3',
      desc: '',
      args: [],
    );
  }

  /// `Make a final farewell Dua at the Multazam.`
  String get hajjStepTawafAlWadaSubStep4 {
    return Intl.message(
      'Make a final farewell Dua at the Multazam.',
      name: 'hajjStepTawafAlWadaSubStep4',
      desc: '',
      args: [],
    );
  }

  /// `Main`
  String get main {
    return Intl.message('Main', name: 'main', desc: '', args: []);
  }

  /// `Ritual Guidance`
  String get ritualGuidance {
    return Intl.message(
      'Ritual Guidance',
      name: 'ritualGuidance',
      desc: '',
      args: [],
    );
  }

  /// `Map`
  String get map {
    return Intl.message('Map', name: 'map', desc: '', args: []);
  }

  /// `Fatwa Chatbot`
  String get fatwaChatbot {
    return Intl.message(
      'Fatwa Chatbot',
      name: 'fatwaChatbot',
      desc: '',
      args: [],
    );
  }

  /// `Al Muqayti`
  String get alMuqayti {
    return Intl.message(
      'Al Muqayti',
      name: 'alMuqayti',
      desc: 'Al Muqayti location name',
      args: [],
    );
  }

  /// `AL'USAYLAH`
  String get alUsaylah {
    return Intl.message(
      'AL\'USAYLAH',
      name: 'alUsaylah',
      desc: 'AL\'USAYLAH location name',
      args: [],
    );
  }

  /// `Show More`
  String get showMore {
    return Intl.message(
      'Show More',
      name: 'showMore',
      desc: 'Show more text',
      args: [],
    );
  }

  /// `Show Less`
  String get showLess {
    return Intl.message(
      'Show Less',
      name: 'showLess',
      desc: 'Show less text',
      args: [],
    );
  }

  /// `from 11 to 13 Dhul-Hijjah`
  String get elevensToThirteenthDhulHijjah {
    return Intl.message(
      'from 11 to 13 Dhul-Hijjah',
      name: 'elevensToThirteenthDhulHijjah',
      desc: 'Elevens to thirteenth Dhul-Hijjah',
      args: [],
    );
  }
}

class AppLocalizationDelegate extends LocalizationsDelegate<S> {
  const AppLocalizationDelegate();

  List<Locale> get supportedLocales {
    return const <Locale>[
      Locale.fromSubtags(languageCode: 'en'),
      Locale.fromSubtags(languageCode: 'ar'),
    ];
  }

  @override
  bool isSupported(Locale locale) => _isSupported(locale);
  @override
  Future<S> load(Locale locale) => S.load(locale);
  @override
  bool shouldReload(AppLocalizationDelegate old) => false;

  bool _isSupported(Locale locale) {
    for (var supportedLocale in supportedLocales) {
      if (supportedLocale.languageCode == locale.languageCode) {
        return true;
      }
    }
    return false;
  }
}
