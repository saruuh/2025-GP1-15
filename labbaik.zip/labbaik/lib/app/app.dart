import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart'
    show
        GlobalMaterialLocalizations,
        GlobalWidgetsLocalizations,
        GlobalCupertinoLocalizations;
import 'package:flutter_quill/flutter_quill.dart'
    show FlutterQuillLocalizations;
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:showcaseview/showcaseview.dart';

import '../generated/l10n.dart' show S;

import '../core/resources/responsive.dart';
import '../core/resources/app_theme.dart';
import '../core/services/theme_service.dart';
import '../core/services/locale_service.dart';
import '../router/router.dart';

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with WidgetsBindingObserver {
  final ThemeService _themeService = ThemeService.instance;
  final LocaleService _localeService = LocaleService.instance;

  @override
  void initState() {
    super.initState();
    _themeService.init();
    _localeService.init();
  }

  @override
  Widget build(BuildContext context) {
    final dWidth = responsive.sWidth(context);
    final dHeight = responsive.sHeight(context);

    return GestureDetector(
      onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
      child: ScreenUtilInit(
        designSize: Size(dWidth, dHeight),
        minTextAdapt: true,
        splitScreenMode: true,
        // Use builder only if you need to use library outside ScreenUtilInit context
        builder: (_, child) {
          return ShowCaseWidget(
            onStart: (index, key) {
              log('onStart: $index, $key');
            },
            onComplete: (index, key) {
              log('onComplete: $index, $key');
            },
            blurValue: 1,
            autoPlayDelay: const Duration(seconds: 3),
            builder: (context) => ListenableBuilder(
              listenable: Listenable.merge([_themeService, _localeService]),
              builder: (context, child) => MaterialApp.router(
                routerConfig: KRouter.systemOwnerRouter,
                debugShowCheckedModeBanner: false,
                localeResolutionCallback: (currentLocal, supportedLocales) {
                  for (var locale in supportedLocales) {
                    if (currentLocal != null &&
                        currentLocal.languageCode == locale.languageCode) {
                      return currentLocal;
                    }
                  }

                  return supportedLocales.first;
                },
                locale: _localeService.locale,
                localizationsDelegates: const [
                  S.delegate,
                  GlobalMaterialLocalizations.delegate,
                  GlobalWidgetsLocalizations.delegate,
                  GlobalCupertinoLocalizations.delegate,
                  FlutterQuillLocalizations.delegate,
                ],
                supportedLocales: S.delegate.supportedLocales,
                theme: getLightTheme(),
                darkTheme: getDarkTheme(),
                themeMode: _themeService.themeMode,
              ),
            ),
          );
        },
      ),
    );
  }
}
