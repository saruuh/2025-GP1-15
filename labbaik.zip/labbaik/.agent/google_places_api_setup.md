# Google Places API Setup Guide

## Overview

The Map tab now uses **Google Places API** to search for real locations in Saudi Arabia. This requires a Google Cloud Platform API key.

## How to Get Your Google Places API Key

### Step 1: Go to Google Cloud Console

Visit: https://console.cloud.google.com/

### Step 2: Create or Select a Project

1. Click on the project dropdown (top left)
2. Click "New Project"
3. Name it something like "Labbaik App"
4. Click "Create"

### Step 3: Enable Required APIs

1. Go to "APIs & Services" > "Library"
2. Search for and enable these APIs:
   - **Places API**
   - **Maps SDK for Android** (if you're building for Android)
   - **Maps SDK for iOS** (if you're building for iOS)
   - **Geocoding API** (optional, for address lookups)

### Step 4: Create API Key

1. Go to "APIs & Services" > "Credentials"
2. Click "+ CREATE CREDENTIALS"
3. Select "API key"
4. Copy the generated API key

### Step 5: Restrict Your API Key (Important for Security!)

1. Click on your newly created API key to edit it
2. Under "Application restrictions":
   - For **Android**: Select "Android apps" and add your package name and SHA-1 fingerprint
   - For **iOS**: Select "iOS apps" and add your bundle identifier
3. Under "API restrictions":
   - Select "Restrict key"
   - Check: Places API, Maps SDK for Android, Maps SDK for iOS
4. Click "Save"

### Step 6: Add API Key to Your App

#### For the Dart code:

Open: `lib/features/home/presentation/widgets/map_tab_content.dart`

Find this line (around line 36):

```dart
static const String _googleApiKey = 'YOUR_GOOGLE_PLACES_API_KEY';
```

Replace with your actual key:

```dart
static const String _googleApiKey = 'AIzaSy...your-actual-key';
```

#### For Android:

1. Open: `android/app/src/main/AndroidManifest.xml`
2. Add inside the `<application>` tag:

```xml
<meta-data
    android:name="com.google.android.geo.API_KEY"
    android:value="YOUR_GOOGLE_MAPS_API_KEY"/>
```

#### For iOS:

1. Open: `ios/Runner/AppDelegate.swift`
2. Add at the top:

```swift
import GoogleMaps
```

3. Add inside `application` function:

```swift
GMSServices.provideAPIKey("YOUR_GOOGLE_MAPS_API_KEY")
```

## Important Security Notes

### NEVER commit your API key to version control!

**Option 1: Use environment variables** (Recommended)
Create a `.env` file (add to `.gitignore`):

```
GOOGLE_PLACES_API_KEY=your_key_here
```

Then use a package like `flutter_dotenv` to load it.

**Option 2: Use a separate config file**
Create `lib/config/api_keys.dart` (add to `.gitignore`):

```dart
class ApiKeys {
  static const String googlePlaces = 'your_key_here';
}
```

Then import and use it in your widget.

## Features Implemented

### 1. **Search by Text**

- Type any place name in the search bar
- Press Enter or tap the search button
- View results as markers on the map
- Example searches:
  - "Kaaba"
  - "Masjid Al-Haram"
  - "Hotels near Makkah"
  - "Restaurants in Makkah"

### 2. **Filter by Category**

- Tap category chips to filter places
- Categories use Google Places types:
  - **Mosques** → `mosque`
  - **Ritual Sites** → `tourist_attraction`
  - **Historic Sites** → `point_of_interest`
  - **Museums** → `museum`
  - **Hotels** → `lodging`

### 3. **Interactive Markers**

- Tap markers to see place details
- Info windows show name and address
- Camera automatically moves to search results

### 4. **Smart Search Radius**

- Searches within 10-15km of Makkah
- Focuses on Saudi Arabia region
- Can be adjusted in the code

## API Usage & Costs

### Free Tier

Google provides $200 free credit per month, which includes:

- **Text Search**: $32 per 1,000 requests
- **Nearby Search**: $32 per 1,000 requests
- **Places Details**: $17 per 1,000 requests

### Typical Usage

- Average user: ~10-20 searches per session
- Free tier easily covers: 5,000+ searches/month
- Most apps stay within free limits

### Cost Optimization Tips

1. **Cache results** - Don't search the same query twice
2. **Limit radius** - Smaller search area = faster & cheaper
3. **Debounce searches** - Wait for user to finish typing
4. **Use session tokens** for autocomplete (not implemented yet)

## Troubleshooting

### "Error searching places"

- Check your API key is correct
- Verify Places API is enabled in Google Cloud Console
- Check API key restrictions aren't blocking requests

### No results showing

- Verify you're searching in the Makkah region
- Try broader search terms
- Check internet connection

### "API key warning" message

- You haven't replaced the default API key
- Follow Step 6 above

## Next Steps (Optional Enhancements)

1. **Autocomplete Search** - Show suggestions as user types
2. **Place Details** - Show photos, ratings, reviews
3. **Directions** - Navigate to selected place
4. **Save Favorites** - Let users save places
5. **Offline Mode** - Cache frequent searches
6. **User Location** - Show "Places near me"

## Resources

- [Google Places API Documentation](https://developers.google.com/maps/documentation/places/web-service)
- [Google Cloud Console](https://console.cloud.google.com/)
- [Places API Pricing](https://developers.google.com/maps/billing-and-pricing/pricing)
- [Best Practices](https://developers.google.com/maps/documentation/places/web-service/best-practices)
